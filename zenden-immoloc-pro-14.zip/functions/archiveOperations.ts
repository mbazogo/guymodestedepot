import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { action, entityType, ids } = await req.json();

    if (!action || !entityType || !Array.isArray(ids) || ids.length === 0) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    const validEntities = ['Property', 'Tenant', 'Lease'];
    if (!validEntities.includes(entityType)) {
      return Response.json({ error: 'Invalid entity type' }, { status: 400 });
    }

    const entityMap = {
      'Property': base44.asServiceRole.entities.Property,
      'Tenant': base44.asServiceRole.entities.Tenant,
      'Lease': base44.asServiceRole.entities.Lease
    };
    
    const entity = entityMap[entityType];
    const isArchiving = action === 'archive';
    const results = [];

    for (const id of ids) {
      await entity.update(id, { archived: isArchiving });
      results.push({ id, success: true });
    }

    return Response.json({
      success: true,
      action: action,
      entityType: entityType,
      count: results.length,
      results: results
    });

  } catch (error) {
    console.error('Archive operation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});