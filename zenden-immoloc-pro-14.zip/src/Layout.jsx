import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard, Building2, Users, FileText, Wallet,
  BookOpen, Settings, Menu, X, ChevronDown,
  Home, CreditCard, LogOut, Bell, TrendingUp, MessageSquare, ClipboardList, PieChart, BarChart2, Archive, AlertTriangle, FolderOpen, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import NotificationCenter from "./components/notifications/NotificationCenter";
import ReceiptPrint from "./components/payments/ReceiptPrint";
import SendReceiptModal from "./components/notifications/SendReceiptModal";
import HelpGuide from "./pages/HelpGuide";

// Nav groups with section labels and colored icons
const navGroups = [
{
  label: null,
  items: [
  { name: "Tableau de bord", page: "Dashboard", icon: LayoutDashboard, color: "text-sky-400" },
  { name: "Biens immobiliers", page: "Properties", icon: Building2, color: "text-violet-400" }]

},
{
  label: "LOCATAIRES & CONTRATS",
  items: [
  {
    name: "Locataires",
    icon: Users,
    color: "text-amber-400",
    children: [
    { name: "Liste des locataires", page: "Tenants" },
    { name: "Courriers", page: "Messaging" }]

  },
  { name: "Baux", page: "Leases", icon: FileText, color: "text-emerald-400" },
  { name: "États des lieux (EDL)", page: "InventoryReports", icon: ClipboardList, color: "text-teal-400" },
  { name: "Appel à Loyer", page: "RentCall", icon: Bell, color: "text-orange-400" },
  { name: "Calendrier des baux", page: "CalendarView", icon: Calendar, color: "text-purple-400" }]

},
{
  label: "FINANCES",
  items: [
  {
    name: "Revenus",
    icon: Wallet,
    color: "text-green-400",
    children: [
    { name: "Paiements", page: "Payments" },
    { name: "Tableau des encaissements", page: "RevenueBoard" }]

  },
  {
    name: "Charges Exploit",
    icon: CreditCard,
    color: "text-red-400",
    children: [
    { name: "Saisie des charges", page: "Charges" }]

  },
  {
    name: "Comptabilité",
    icon: BookOpen,
    color: "text-blue-400",
    children: [
    { name: "Grand Livre & Balance", page: "Accounting" }]

  },
  { name: "Rentabilité", page: "Profitability", icon: TrendingUp, color: "text-pink-400" },
  { name: "Statistiques financières", page: "FinancialStats", icon: BarChart2, color: "text-cyan-400" },
  { name: "Répartition", page: "RevenueAllocation", icon: PieChart, color: "text-indigo-400" },
  { name: "Rapports", page: "Reports", icon: BarChart2, color: "text-violet-400" }]

},
{
  label: "AUTRES",
  items: [
  { name: "Impayés & Relances", page: "Unpaid", icon: AlertTriangle, color: "text-red-400" },
  { name: "Documents (GED)", page: "Documents", icon: FolderOpen, color: "text-indigo-400" },
  { name: "Rappels & Alertes", page: "Reminders", icon: Bell, color: "text-amber-400" },
  { name: "Règlement Intérieur", page: "InternalRules", icon: FileText, color: "text-indigo-400" },
  { name: "Archives", page: "Archives", icon: Archive, color: "text-slate-400" },
  { name: "Aide & Mode d'emploi", page: "HelpGuide", icon: FileText, color: "text-cyan-400" },
  { name: "Paramètres", page: "AppSettingsPage", icon: Settings, color: "text-slate-400" }]

}];


// Flat list for header lookup
const allNavItems = navGroups.flatMap((g) => g.items);

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState({});
  const [receiptPayment, setReceiptPayment] = useState(null);
  const [sendReceiptData, setSendReceiptData] = useState(null);

  const { data: payments = [] } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const toggleMenu = (name) => setExpandedMenus((prev) => ({ ...prev, [name]: !prev[name] }));
  const isActive = (page) => currentPageName === page;
  const isChildActive = (children) => children?.some((c) => isActive(c.page));

  const currentLabel =
  allNavItems.find((n) => n.page === currentPageName)?.name ||
  allNavItems.flatMap((n) => n.children || []).find((c) => c.page === currentPageName)?.name ||
  currentPageName;

  const renderItem = (item, index) => {
    if (item.children) {
      const active = isChildActive(item.children);
      const expanded = expandedMenus[item.name] ?? active;
      const IconComp = item.icon;
      return (
        <div key={index}>
          <button
            onClick={() => toggleMenu(item.name)}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 group ${
            active ? "bg-white/10 text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"}`
            }>

            <div className="flex items-center gap-2.5">
              <IconComp className={`w-4 h-4 shrink-0 ${item.color || "text-slate-400"} group-hover:scale-110 transition-transform`} />
              <span>{item.name}</span>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${expanded ? "rotate-0" : "-rotate-90"}`} />
          </button>
          {expanded &&
          <div className="ml-6 mt-0.5 mb-1 space-y-0.5 border-l border-white/10 pl-3">
              {item.children.map((child, ci) =>
            <Link
              key={ci}
              to={createPageUrl(child.page)}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all duration-150 ${
              isActive(child.page) ?
              "bg-emerald-500/15 text-emerald-300 font-semibold" :
              "text-slate-400 hover:bg-white/5 hover:text-slate-200"}`
              }>

                  <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isActive(child.page) ? "bg-emerald-400" : "bg-slate-600"}`} />
                  {child.name}
                </Link>
            )}
            </div>
          }
        </div>);

    }

    const IconComp = item.icon;
    const active = isActive(item.page);
    return (
      <Link
        key={index}
        to={createPageUrl(item.page)}
        onClick={() => setSidebarOpen(false)}
        className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 group ${
        active ?
        "bg-emerald-500/15 text-emerald-300" :
        "text-slate-400 hover:bg-white/5 hover:text-white"}`
        }>

        <motion.div
          key={active ? "active" : "inactive"}
          initial={active ? { scale: 0.5, rotate: -15, opacity: 0 } : false}
          animate={active ? { scale: 1, rotate: 0, opacity: 1 } : {}}
          transition={{ type: "spring", stiffness: 400, damping: 15 }}>

          <IconComp className={`w-4 h-4 shrink-0 ${active ? "text-emerald-400" : item.color || "text-slate-400"}`} />
        </motion.div>
        <span>{item.name}</span>
        {active &&
        <motion.span
          layoutId="activeIndicator"
          className="ml-auto w-1.5 h-5 bg-emerald-400 rounded-full"
          transition={{ type: "spring", stiffness: 400, damping: 30 }} />

        }
      </Link>);

  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Mobile overlay */}
      {sidebarOpen &&
      <div className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
      }

      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-60 flex flex-col transition-transform duration-300 ${
        sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`
        }
        style={{ background: "linear-gradient(160deg, #0a1f3c 0%, #0f2b4c 40%, #0b2240 100%)" }}>

        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-4 mx-3 mt-3 mb-1 rounded-xl border border-emerald-500/30" style={{ background: "linear-gradient(135deg, #0d3d2e 0%, #0f4d38 60%, #0a3d2e 100%)" }}>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-900/40">
              <Home className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-white text-lg font-bold tracking-tight leading-none">Zenden ImmoLoc</h1>
              <p className="text-[#c4b1b1] px-1 text-xs uppercase tracking-[0.15em]">GESTION LOCATIVE</p>
            </div>
          </div>
          <button className="lg:hidden text-slate-400 hover:text-white" onClick={() => setSidebarOpen(false)}>
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-2.5 py-3 space-y-4">
          {navGroups.map((group, gi) =>
          <div key={gi}>
              {group.label &&
            <div className="px-3 mb-1.5">
                  <span className="bg-transparent text-slate-200 font-bold uppercase tracking-[0.18em]">{group.label}</span>
                </div>
            }
              <div className="space-y-0.5">
                {group.items.map((item, ii) => renderItem(item, `${gi}-${ii}`))}
              </div>
            </div>
          )}
        </nav>

        {/* Footer */}
        <div className="px-2.5 py-3 border-t border-white/8">
          <button
            onClick={() => base44.auth.logout()}
            className="flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-xs text-slate-500 hover:bg-white/5 hover:text-rose-400 transition-all group">

            <LogOut className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
            <span className="text-amber-200">Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-13 bg-white border-b border-slate-100 flex items-center justify-between px-4 lg:px-6 shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-slate-500 hover:text-slate-900" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden lg:flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <h2 className="text-slate-700 text-base font-semibold">{currentLabel}</h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationCenter
              payments={payments}
              tenants={tenants}
              settings={settings}
              onViewReceipt={(pay) => setReceiptPayment(pay)}
              onSendReceipt={(pay, tenant) => setSendReceiptData({ pay, tenant })} />

            <span className="text-[11px] text-slate-500 font-semibold bg-slate-100 px-2.5 py-1 rounded-full tracking-wide">
              XAF
            </span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>

      <ReceiptPrint payment={receiptPayment} settings={settings} onClose={() => setReceiptPayment(null)} />
      <SendReceiptModal
        payment={sendReceiptData?.pay}
        tenant={sendReceiptData?.tenant}
        settings={settings}
        onClose={() => setSendReceiptData(null)} />

    </div>);

}