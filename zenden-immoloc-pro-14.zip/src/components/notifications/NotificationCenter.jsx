import React, { useState, useMemo } from "react";
import { Bell, X, AlertTriangle, Clock, CheckCircle, Mail, Printer, ChevronRight, Loader2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { generateAndSaveReceipt } from "@/components/payments/generateReceipt";
import { useQueryClient } from "@tanstack/react-query";

const MONTHS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

export default function NotificationCenter({ payments = [], tenants = [], onViewReceipt, onSendReceipt, settings }) {
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState([]);
  const [generatingIds, setGeneratingIds] = useState([]);
  const queryClient = useQueryClient();

  const handleAutoGenerate = async (pay) => {
    setGeneratingIds((ids) => [...ids, pay.id]);
    await generateAndSaveReceipt(pay, settings);
    await queryClient.invalidateQueries({ queryKey: ["payments"] });
    setGeneratingIds((ids) => ids.filter((i) => i !== pay.id));
    setDismissed((d) => [...d, `no-receipt-${pay.id}`]);
  };

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const notifications = useMemo(() => {
    const notifs = [];
    const activeTenants = tenants.filter((t) => t.status === "active" && !t.archived);

    activeTenants.forEach((tenant) => {
      const pay = payments.find((p) =>
      p.tenant_id === tenant.id &&
      p.period_month === currentMonth &&
      p.period_year === currentYear
      );

      // Pas d'appel de loyer ce mois
      if (!pay) {
        notifs.push({
          id: `no-call-${tenant.id}`,
          type: "no_call",
          severity: "warning",
          title: "Appel de loyer manquant",
          message: `Aucun appel de loyer pour ${tenant.first_name} ${tenant.last_name} — ${MONTHS_FR[currentMonth - 1]} ${currentYear}`,
          tenant,
          pay: null
        });
        return;
      }

      // En retard
      if (pay.status === "late" || pay.status === "pending") {
        const daysLate = pay.due_date ?
        Math.floor((now - new Date(pay.due_date)) / 86400000) :
        0;
        if (daysLate > 0) {
          notifs.push({
            id: `late-${pay.id}`,
            type: "late",
            severity: "danger",
            title: "Loyer en retard",
            message: `${tenant.first_name} ${tenant.last_name} — ${daysLate} jour(s) de retard`,
            tenant,
            pay
          });
        } else {
          notifs.push({
            id: `pending-${pay.id}`,
            type: "pending",
            severity: "info",
            title: "Paiement en attente",
            message: `${tenant.first_name} ${tenant.last_name} — ${MONTHS_FR[currentMonth - 1]} ${currentYear}`,
            tenant,
            pay
          });
        }
      }

      // Quittance non générée (payé mais pas de receipt_url)
      if ((pay.status === "paid" || pay.status === "partial") && !pay.receipt_url) {
        notifs.push({
          id: `no-receipt-${pay.id}`,
          type: "no_receipt",
          severity: "info",
          title: "Quittance non générée",
          message: `${tenant.first_name} ${tenant.last_name} — Loyer payé sans quittance`,
          tenant,
          pay
        });
      }
    });

    return notifs.filter((n) => !dismissed.includes(n.id));
  }, [payments, tenants, dismissed, currentMonth, currentYear]);

  const counts = {
    danger: notifications.filter((n) => n.severity === "danger").length,
    warning: notifications.filter((n) => n.severity === "warning").length,
    info: notifications.filter((n) => n.severity === "info").length
  };
  const total = notifications.length;

  const severityConfig = {
    danger: { bg: "bg-red-50", border: "border-red-200", icon: AlertTriangle, iconColor: "text-red-500", badge: "bg-red-100 text-red-700" },
    warning: { bg: "bg-amber-50", border: "border-amber-200", icon: Clock, iconColor: "text-amber-500", badge: "bg-amber-100 text-amber-700" },
    info: { bg: "bg-blue-50", border: "border-blue-200", icon: Bell, iconColor: "text-blue-500", badge: "bg-blue-100 text-blue-700" }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 hover:border-slate-300 shadow-sm transition-all text-sm text-slate-600 hover:text-slate-900">

        <Bell
          className={`w-4 h-4 ${total > 0 ? "text-red-500 animate-bell-ring" : ""}`}
        />
        {total > 0 &&
        <span
          className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center animate-badge-pulse">
            {total > 9 ? "9+" : total}
          </span>
        }
        <span
          className={`hidden sm:inline font-medium ${total > 0 ? "text-red-500 animate-alert-glow" : "text-slate-600"}`}>
          Alertes
        </span>
      </button>

      {open &&
      <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-96 max-h-[80vh] overflow-y-auto bg-white rounded-xl shadow-2xl border border-slate-200 z-40">
            <div className="sticky top-0 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-slate-800 text-sm">Centre de notifications</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {counts.danger > 0 && <span className="text-red-600 font-medium">{counts.danger} retard(s) </span>}
                  {counts.warning > 0 && <span className="text-amber-600 font-medium">{counts.warning} appel(s) manquant(s) </span>}
                  {counts.info > 0 && <span className="text-blue-600 font-medium">{counts.info} en attente</span>}
                  {total === 0 && "Aucune alerte"}
                </p>
              </div>
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {total === 0 ?
          <div className="py-12 text-center">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Tout est à jour !</p>
              </div> :

          <div className="divide-y divide-slate-50">
                {notifications.map((notif) => {
              const cfg = severityConfig[notif.severity];
              const Icon = cfg.icon;
              return (
                <div key={notif.id} className={`p-3 ${cfg.bg} border-l-4 ${cfg.border} hover:opacity-90 transition-opacity`}>
                      <div className="flex items-start gap-2.5">
                        <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${cfg.iconColor}`} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-slate-800">{notif.title}</p>
                          <p className="text-xs text-slate-600 mt-0.5 truncate">{notif.message}</p>
                          <div className="flex gap-1.5 mt-2 flex-wrap">
                            {notif.type === "no_call" &&
                        <Link
                          to={createPageUrl("RentCall")}
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-amber-600 text-white hover:bg-amber-700 font-medium">

                                <ChevronRight className="w-3 h-3" /> Aller à l'appel
                              </Link>
                        }
                            {(notif.type === "no_receipt" || notif.type === "late" || notif.type === "pending") && notif.pay &&
                        <>
                                {(notif.pay.status === "paid" || notif.pay.status === "partial") &&
                          <>
                                    {notif.type === "no_receipt" &&
                            <button
                              onClick={() => handleAutoGenerate(notif.pay)}
                              disabled={generatingIds.includes(notif.pay.id)}
                              className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-emerald-600 text-white hover:bg-emerald-700 font-medium disabled:opacity-60">

                                        {generatingIds.includes(notif.pay.id) ?
                              <Loader2 className="w-3 h-3 animate-spin" /> :
                              <Save className="w-3 h-3" />}
                                        Générer
                                      </button>
                            }
                                    <button
                              onClick={() => {onViewReceipt(notif.pay);setOpen(false);}}
                              className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-slate-700 text-white hover:bg-slate-800 font-medium">

                                      <Printer className="w-3 h-3" /> Imprimer
                                    </button>
                                    <button
                              onClick={() => {onSendReceipt(notif.pay, notif.tenant);setOpen(false);}}
                              className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-indigo-600 text-white hover:bg-indigo-700 font-medium">

                                      <Mail className="w-3 h-3" /> Email
                                    </button>
                                  </>
                          }
                                {(notif.type === "late" || notif.type === "pending") &&
                          <Link
                            to={createPageUrl("Payments?filter=late")}
                            onClick={() => setOpen(false)}
                            className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-red-600 text-white hover:bg-red-700 font-medium">

                                    <ChevronRight className="w-3 h-3" /> Voir paiements
                                  </Link>
                          }
                              </>
                        }
                          </div>
                        </div>
                        <button
                      onClick={() => setDismissed((d) => [...d, notif.id])}
                      className="text-slate-300 hover:text-slate-500 shrink-0">

                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>);

            })}
              </div>
          }

            {total > 0 &&
          <div className="sticky bottom-0 bg-white border-t border-slate-100 px-4 py-2 flex justify-end">
                <button
              onClick={() => setDismissed(notifications.map((n) => n.id))}
              className="text-xs text-slate-400 hover:text-slate-600">

                  Tout ignorer
                </button>
              </div>
          }
          </div>
        </>
      }
    </div>);

}