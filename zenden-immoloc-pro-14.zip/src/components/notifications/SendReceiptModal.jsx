import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Loader2, CheckCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

const MONTHS_FR = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

export default function SendReceiptModal({ payment, tenant, settings, onClose }) {
  const [to, setTo] = useState(tenant?.email || "");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  if (!payment) return null;

  const month = MONTHS_FR[(payment.period_month || 1) - 1];
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const ownerName = settings?.owner_name || "Le Propriétaire";

  const handleSend = async () => {
    if (!to) return;
    setSending(true);

    const body = `
Bonjour ${payment.tenant_name},

Veuillez trouver ci-joint votre quittance de loyer pour le mois de ${month} ${payment.period_year}.

— Récapitulatif —
Bien loué : ${payment.property_name}
Période : ${month} ${payment.period_year}
Montant reçu : ${formatXAF(payment.amount)} XAF
Mode de paiement : ${payment.payment_method || "—"}
${payment.reference ? `Référence : ${payment.reference}` : ""}

${settings?.receipt_footer_text || `Le bailleur certifie avoir reçu la somme de ${formatXAF(payment.amount)} XAF en règlement du loyer du bien susmentionné.`}

Cordialement,
${ownerName}
${companyName}
${settings?.owner_phone || ""}
    `.trim();

    await base44.integrations.Core.SendEmail({
      from_name: companyName,
      to,
      subject: `Quittance de loyer — ${month} ${payment.period_year} — ${payment.property_name}`,
      body,
    });

    setSending(false);
    setSent(true);
    setTimeout(() => { setSent(false); onClose(); }, 2000);
  };

  return (
    <Dialog open={!!payment} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-indigo-500" /> Envoyer la quittance par email
          </DialogTitle>
        </DialogHeader>

        {sent ? (
          <div className="py-8 text-center">
            <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
            <p className="font-semibold text-slate-800">Email envoyé avec succès !</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-3 text-sm space-y-1">
              <p><span className="text-slate-500">Locataire :</span> <strong>{payment.tenant_name}</strong></p>
              <p><span className="text-slate-500">Bien :</span> {payment.property_name}</p>
              <p><span className="text-slate-500">Période :</span> {month} {payment.period_year}</p>
              <p><span className="text-slate-500">Montant :</span> <strong className="text-emerald-700">{formatXAF(payment.amount)} XAF</strong></p>
            </div>

            <div>
              <Label>Adresse email du destinataire *</Label>
              <Input
                type="email"
                value={to}
                onChange={e => setTo(e.target.value)}
                placeholder="locataire@email.com"
                className="mt-1"
              />
              {tenant?.email && to !== tenant.email && (
                <button
                  onClick={() => setTo(tenant.email)}
                  className="text-xs text-blue-600 hover:underline mt-1"
                >
                  Utiliser l'email du locataire : {tenant.email}
                </button>
              )}
            </div>

            <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 text-xs text-blue-700">
              Un email récapitulatif de la quittance sera envoyé depuis {companyName}.
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          {!sent && (
            <Button onClick={handleSend} disabled={sending || !to} className="bg-indigo-600 hover:bg-indigo-700">
              {sending ? <><Loader2 className="w-4 h-4 animate-spin mr-1" /> Envoi...</> : <><Mail className="w-4 h-4 mr-1" /> Envoyer</>}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}