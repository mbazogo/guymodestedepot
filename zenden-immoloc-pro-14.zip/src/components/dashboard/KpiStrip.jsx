import React, { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Building2, Wallet, AlertTriangle, FileText, TrendingUp, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const MONTHS_SHORT = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

// Animated counter
function AnimatedNumber({ value, prefix = "", suffix = "" }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const start = 0;
    const end = value;
    if (end === 0) {setDisplay(0);return;}
    const duration = 900;
    const step = (end - start) / (duration / 16);
    let current = start;
    const timer = setInterval(() => {
      current += step;
      if (current >= end) {setDisplay(end);clearInterval(timer);} else
      setDisplay(Math.round(current));
    }, 16);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{prefix}{new Intl.NumberFormat("fr-FR").format(display)}{suffix}</span>;
}

export default function KpiStrip({ properties, tenants, payments, leases }) {
  const [lastUpdate, setLastUpdate] = useState(new Date());

  // Auto-refresh timestamp
  useEffect(() => {
    const interval = setInterval(() => setLastUpdate(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  const today = new Date();
  const currentMonth = today.getMonth() + 1;
  const currentYear = today.getFullYear();

  // 1. Taux d'occupation
  const activeProperties = properties.filter((p) => !p.archived);
  const occupiedCount = activeProperties.filter((p) => p.status === "occupied").length;
  const totalCount = activeProperties.length;
  const occupancyRate = totalCount > 0 ? Math.round(occupiedCount / totalCount * 100) : 0;

  // 2. Revenus cumulés du mois
  const monthRevenue = payments.
  filter((p) => p.period_year === currentYear && p.period_month === currentMonth && (p.status === "paid" || p.status === "partial")).
  reduce((s, p) => s + (p.amount || 0), 0);

  const expectedMonth = tenants.
  filter((t) => t.status === "active" && !t.archived).
  reduce((s, t) => s + (t.rent_amount || 0), 0);

  const collectionRate = expectedMonth > 0 ? Math.round(monthRevenue / expectedMonth * 100) : 0;

  // 3. Dettes totales des locataires (loyers en retard + en attente)
  const totalDebt = payments.
  filter((p) => p.status === "late" || p.status === "pending").
  reduce((s, p) => s + (p.expected_amount || 0), 0);

  const debtorCount = new Set(
    payments.filter((p) => p.status === "late" || p.status === "pending").map((p) => p.tenant_id)
  ).size;

  // 4. Prochaines échéances de baux (60 jours)
  const in60 = new Date(today);
  in60.setDate(in60.getDate() + 60);
  const upcomingLeases = leases.
  filter((l) => {
    if (l.status !== "active" || l.archived) return false;
    if (!l.end_date) return false;
    const end = new Date(l.end_date);
    return end >= today && end <= in60;
  }).
  sort((a, b) => new Date(a.end_date) - new Date(b.end_date));

  const kpis = [
  {
    label: "Taux d'occupation",
    value: `${occupancyRate}%`,
    raw: occupancyRate,
    icon: Building2,
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600",
    sub: `${occupiedCount}/${totalCount} biens occupés`,
    bar: true,
    barColor: occupancyRate >= 80 ? "bg-emerald-500" : occupancyRate >= 50 ? "bg-amber-500" : "bg-red-500",
    link: createPageUrl("Properties"),
    badge: null
  },
  {
    label: "Revenus du mois",
    value: formatXAF(monthRevenue) + " XAF",
    raw: monthRevenue,
    icon: Wallet,
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
    sub: `${collectionRate}% collecté — Attendu : ${formatXAF(expectedMonth)} XAF`,
    bar: true,
    barColor: collectionRate >= 80 ? "bg-emerald-500" : collectionRate >= 50 ? "bg-amber-500" : "bg-red-500",
    barValue: collectionRate,
    link: createPageUrl("Payments"),
    badge: null
  },
  {
    label: "Dettes locataires",
    value: formatXAF(totalDebt) + " XAF",
    raw: totalDebt,
    icon: AlertTriangle,
    iconBg: totalDebt > 0 ? "bg-red-100" : "bg-slate-100",
    iconColor: totalDebt > 0 ? "text-red-600" : "text-slate-400",
    sub: totalDebt > 0 ? `${debtorCount} locataire(s) en retard/attente` : "Aucun impayé",
    bar: false,
    link: createPageUrl("Unpaid"),
    badge: debtorCount > 0 ? { label: `${debtorCount} impayé(s)`, color: "bg-red-500" } : null
  },
  {
    label: "Baux à renouveler",
    value: `${upcomingLeases.length}`,
    raw: upcomingLeases.length,
    icon: FileText,
    iconBg: upcomingLeases.length > 0 ? "bg-amber-100" : "bg-slate-100",
    iconColor: upcomingLeases.length > 0 ? "text-amber-600" : "text-slate-400",
    sub: upcomingLeases.length > 0 ?
    `Prochain : ${upcomingLeases[0].tenant_name} — ${new Date(upcomingLeases[0].end_date).toLocaleDateString("fr-FR")}` :
    "Aucune échéance dans 60 jours",
    bar: false,
    link: createPageUrl("Leases"),
    badge: upcomingLeases.length > 0 ? { label: `Dans 60j`, color: "bg-amber-500" } : null
  }];


  return (
    <div className="space-y-2">
      {/* Real-time indicator */}
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
          Indicateurs clés en temps réel
        </h2>
        <span className="text-[10px] text-slate-400 flex items-center gap-1">
          <RefreshCw className="w-3 h-3" /> Mis à jour : {lastUpdate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {kpis.map(({ label, value, raw, icon: Icon, iconBg, iconColor, sub, bar, barColor, barValue, link, badge }) =>
        <Link key={label} to={link} className="block group">
            <Card className="p-4 hover:shadow-md transition-all duration-200 group-hover:border-slate-300 relative overflow-hidden">
              {/* Background accent */}
              <div className="absolute top-0 right-0 w-16 h-16 opacity-5 translate-x-4 -translate-y-4">
                <Icon className="w-full h-full" />
              </div>

              <div className="flex items-start justify-between mb-2">
                <div className={`w-9 h-9 rounded-lg ${iconBg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4.5 h-4.5 ${iconColor}`} />
                </div>
                {badge &&
              <span className={`text-[9px] text-white px-1.5 py-0.5 rounded-full font-semibold ${badge.color}`}>
                    {badge.label}
                  </span>
              }
              </div>

              <p className="text-[11px] text-slate-500 leading-tight">{label}</p>
              <p className="text-slate-800 mt-0.5 text-base font-bold leading-tight truncate">{value}</p>

              {bar &&
            <div className="mt-2">
                  <div className="w-full bg-slate-100 rounded-full h-1.5">
                    <div
                  className={`h-1.5 rounded-full transition-all duration-700 ${barColor}`}
                  style={{ width: `${Math.min(barValue ?? raw, 100)}%` }} />

                  </div>
                </div>
            }

              <p className="text-[10px] text-slate-400 mt-1.5 leading-tight truncate">{sub}</p>
            </Card>
          </Link>
        )}
      </div>

      {/* Upcoming leases detail strip */}
      {upcomingLeases.length > 0 &&
      <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="w-3.5 h-3.5 text-amber-600" />
            <span className="text-xs font-semibold text-amber-800">Baux arrivant à échéance dans les 60 prochains jours</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {upcomingLeases.slice(0, 5).map((l) => {
            const daysLeft = Math.ceil((new Date(l.end_date) - today) / (1000 * 60 * 60 * 24));
            return (
              <div key={l.id} className={`flex items-center gap-2 px-2.5 py-1 rounded-lg text-xs font-medium border ${daysLeft <= 14 ? "bg-red-100 border-red-300 text-red-700" : "bg-amber-100 border-amber-300 text-amber-700"}`}>
                  <span>{l.tenant_name || l.property_name}</span>
                  <span className="opacity-60">•</span>
                  <span>{daysLeft}j</span>
                </div>);

          })}
            {upcomingLeases.length > 5 &&
          <Link to={createPageUrl("Leases")} className="flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-amber-100 border border-amber-300 text-amber-700 hover:bg-amber-200">
                +{upcomingLeases.length - 5} autres →
              </Link>
          }
          </div>
        </div>
      }
    </div>);

}