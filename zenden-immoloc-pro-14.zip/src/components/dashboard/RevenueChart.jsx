import React, { useState } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend, Area, AreaChart, ComposedChart
} from "recharts";

const MONTHS = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];

function formatXAF(value) {
  if (value >= 1000000) return (value / 1000000).toFixed(1) + "M";
  if (value >= 1000) return (value / 1000).toFixed(0) + "k";
  return new Intl.NumberFormat("fr-FR").format(value);
}

function formatFull(value) {
  return new Intl.NumberFormat("fr-FR").format(value) + " XAF";
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-3 text-xs min-w-[160px]">
      <p className="font-bold text-slate-700 mb-2">{label}</p>
      {payload.map((entry, i) => (
        <div key={i} className="flex justify-between gap-4 mb-1">
          <span style={{ color: entry.color }}>{entry.name}</span>
          <span className="font-semibold text-slate-800">{formatFull(entry.value)}</span>
        </div>
      ))}
      {payload.length >= 2 && (
        <div className="border-t border-slate-100 mt-1.5 pt-1.5 flex justify-between">
          <span className="text-slate-500">Résultat net</span>
          <span className={`font-bold ${(payload[0]?.value || 0) - (payload[1]?.value || 0) >= 0 ? "text-emerald-600" : "text-red-600"}`}>
            {formatFull((payload[0]?.value || 0) - (payload[1]?.value || 0))}
          </span>
        </div>
      )}
    </div>
  );
};

export default function RevenueChart({ payments, charges, year }) {
  const [chartType, setChartType] = useState("bar");

  const data = MONTHS.map((month, index) => {
    const monthPayments = payments.filter(
      (p) => p.period_year === year && p.period_month === index + 1 && (p.status === "paid" || p.status === "partial")
    );
    const monthCharges = charges.filter((c) => {
      const d = new Date(c.date);
      return d.getFullYear() === year && d.getMonth() === index;
    });
    const rev = monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const dep = monthCharges.reduce((sum, c) => sum + (c.amount || 0), 0);
    return { name: month, revenus: rev, depenses: dep, net: rev - dep };
  });

  const yearRevenue = data.reduce((s, d) => s + d.revenus, 0);
  const yearExpenses = data.reduce((s, d) => s + d.depenses, 0);
  const yearNet = yearRevenue - yearExpenses;
  const bestMonth = data.reduce((best, d) => d.revenus > best.revenus ? d : best, data[0]);

  const commonXAxis = <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />;
  const commonYAxis = <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={formatXAF} width={50} />;
  const commonGrid = <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />;

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-800">Revenus vs Dépenses — {year}</h3>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-[11px] text-emerald-600 font-medium">↑ {formatXAF(yearRevenue)} rev.</span>
            <span className="text-[11px] text-red-500 font-medium">↓ {formatXAF(yearExpenses)} dep.</span>
            <span className={`text-[11px] font-bold ${yearNet >= 0 ? "text-emerald-700" : "text-red-700"}`}>
              = {yearNet >= 0 ? "+" : ""}{formatXAF(yearNet)} net
            </span>
          </div>
        </div>
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {[
            { key: "bar", label: "Barres" },
            { key: "area", label: "Courbe" },
            { key: "composed", label: "Mixte" },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setChartType(key)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${chartType === key ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        {chartType === "bar" ? (
          <BarChart data={data} barGap={2}>
            {commonGrid}
            {commonXAxis}
            {commonYAxis}
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Bar dataKey="revenus" name="Revenus" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="depenses" name="Dépenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
          </BarChart>
        ) : chartType === "area" ? (
          <AreaChart data={data}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="depGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
              </linearGradient>
            </defs>
            {commonGrid}
            {commonXAxis}
            {commonYAxis}
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Area type="monotone" dataKey="revenus" name="Revenus" stroke="#10b981" strokeWidth={2} fill="url(#revGrad)" />
            <Area type="monotone" dataKey="depenses" name="Dépenses" stroke="#ef4444" strokeWidth={2} fill="url(#depGrad)" />
          </AreaChart>
        ) : (
          <ComposedChart data={data}>
            {commonGrid}
            {commonXAxis}
            {commonYAxis}
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Bar dataKey="revenus" name="Revenus" fill="#10b981" radius={[4, 4, 0, 0]} opacity={0.85} />
            <Bar dataKey="depenses" name="Dépenses" fill="#ef4444" radius={[4, 4, 0, 0]} opacity={0.85} />
            <Line type="monotone" dataKey="net" name="Net" stroke="#6366f1" strokeWidth={2} dot={false} />
          </ComposedChart>
        )}
      </ResponsiveContainer>

      {bestMonth?.revenus > 0 && (
        <p className="text-[11px] text-slate-400 mt-2 text-right">
          Meilleur mois : <strong className="text-emerald-600">{bestMonth.name}</strong> ({formatFull(bestMonth.revenus)})
        </p>
      )}
    </div>
  );
}