import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AlertTriangle, Clock, ExternalLink } from "lucide-react";

function formatXAF(value) {
  return new Intl.NumberFormat("fr-FR").format(value || 0);
}

export default function DueAlerts({ latePayments, pendingPayments }) {
  return (
    <div className="space-y-4">
      {/* Late */}
      <div className="bg-white rounded-xl border border-red-100 p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-red-600" />
            </div>
            <h3 className="text-sm font-semibold text-red-800">Échéances en retard</h3>
          </div>
          <Link
            to={createPageUrl("Payments") + "?filter=late"}
            className="text-xs text-red-600 hover:text-red-700 font-medium flex items-center gap-1">

            Voir <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
        {latePayments.length === 0 ?
        <p className="text-xs text-slate-400 text-center py-3">Aucun retard 🎉</p> :

        <div className="space-y-2 max-h-[180px] overflow-y-auto">
            {latePayments.slice(0, 5).map((p) =>
          <div key={p.id} className="flex items-center justify-between py-1.5 border-b border-red-50 last:border-0">
                <div>
                  <p className="text-xs font-medium text-slate-800">{p.tenant_name}</p>
                  <p className="text-[10px] text-slate-400">{p.property_name}</p>
                </div>
                <span className="text-xs font-semibold text-red-600">{formatXAF(p.expected_amount)} XAF</span>
              </div>
          )}
          </div>
        }
      </div>

      {/* Pending */}
      <div className="bg-white rounded-xl border border-amber-100 p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center">
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <h3 className="bg-zinc-100 text-amber-800 text-sm font-semibold">Loyers à payer</h3>
          </div>
          <Link
            to={createPageUrl("Payments") + "?filter=pending"}
            className="text-xs text-amber-600 hover:text-amber-700 font-medium flex items-center gap-1">

            Voir <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
        {pendingPayments.length === 0 ?
        <p className="text-xs text-slate-400 text-center py-3">Aucun loyer en attente</p> :

        <div className="space-y-2 max-h-[180px] overflow-y-auto">
            {pendingPayments.slice(0, 5).map((p) =>
          <div key={p.id} className="flex items-center justify-between py-1.5 border-b border-amber-50 last:border-0">
                <div>
                  <p className="text-xs font-medium text-slate-800">{p.tenant_name}</p>
                  <p className="text-[10px] text-slate-400">{p.property_name}</p>
                </div>
                <span className="text-xs font-semibold text-amber-600">{formatXAF(p.expected_amount)} XAF</span>
              </div>
          )}
          </div>
        }
      </div>
    </div>);

}