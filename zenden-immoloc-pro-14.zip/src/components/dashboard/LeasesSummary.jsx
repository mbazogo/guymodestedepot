import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { FileText, ExternalLink, AlertTriangle, CheckCircle2, XCircle, Clock } from "lucide-react";

function daysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
}

export default function LeasesSummary({ leases }) {
  const active = leases.filter(l => l.status === "active");
  const expired = leases.filter(l => l.status === "expired" || l.status === "terminated");
  const draft = leases.filter(l => l.status === "draft");

  const today = new Date();
  const in60 = new Date(today);
  in60.setDate(in60.getDate() + 60);

  const expiringSoon = active.filter(l => {
    if (!l.end_date) return false;
    const d = new Date(l.end_date);
    return d >= today && d <= in60;
  }).sort((a, b) => new Date(a.end_date) - new Date(b.end_date));

  const stats = [
    { label: "Actifs", count: active.length, icon: CheckCircle2, color: "emerald", bg: "bg-emerald-50" },
    { label: "À échéance", count: expiringSoon.length, icon: Clock, color: "amber", bg: "bg-amber-50" },
    { label: "Expirés/Résiliés", count: expired.length, icon: XCircle, color: "red", bg: "bg-red-50" },
    { label: "Brouillons", count: draft.length, icon: FileText, color: "slate", bg: "bg-slate-50" },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-100 flex items-center justify-center">
            <FileText className="w-4 h-4 text-blue-600" />
          </div>
          <h3 className="text-sm font-semibold text-slate-800">Résumé des baux</h3>
        </div>
        <Link to={createPageUrl("Leases")} className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
          Gérer <ExternalLink className="w-3 h-3" />
        </Link>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-4 gap-2 mb-4">
        {stats.map(({ label, count, icon: Icon, color, bg }) => (
          <div key={label} className={`${bg} rounded-lg p-2.5 text-center`}>
            <p className={`text-xl font-bold text-${color}-700`}>{count}</p>
            <p className={`text-[10px] text-${color}-600 mt-0.5 leading-tight`}>{label}</p>
          </div>
        ))}
      </div>

      {/* Expiring soon list */}
      {expiringSoon.length > 0 && (
        <div>
          <p className="text-[11px] text-amber-600 font-semibold uppercase tracking-wide mb-2 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> Expirent dans les 60 jours
          </p>
          <div className="space-y-1.5">
            {expiringSoon.slice(0, 4).map(l => {
              const days = daysUntil(l.end_date);
              return (
                <div key={l.id} className="flex items-center justify-between py-1 border-b border-slate-50 last:border-0">
                  <div>
                    <p className="text-xs font-medium text-slate-800">{l.tenant_name || "—"}</p>
                    <p className="text-[10px] text-slate-400">{l.property_name}</p>
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${days <= 14 ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                    {days}j
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {leases.length === 0 && (
        <p className="text-xs text-slate-400 text-center py-3">Aucun bail enregistré</p>
      )}
    </div>
  );
}