import React from "react";
import { Progress } from "@/components/ui/progress";

function formatXAF(value) {
  return new Intl.NumberFormat("fr-FR").format(value || 0);
}

export default function TenantProgress({ tenants, payments, year }) {
  const currentMonth = new Date().getMonth() + 1;

  const tenantData = tenants
    .filter((t) => t.status === "active")
    .map((t) => {
      const yearPayments = payments.filter(
        (p) =>
          p.tenant_id === t.id &&
          p.period_year === year &&
          (p.status === "paid" || p.status === "partial")
      );
      const totalPaid = yearPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const expected = (t.rent_amount || 0) * currentMonth;
      const percent = expected > 0 ? Math.min(Math.round((totalPaid / expected) * 100), 100) : 0;
      return {
        name: `${t.first_name} ${t.last_name}`,
        property: t.property_name,
        paid: totalPaid,
        expected,
        percent,
      };
    });

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-slate-800 mb-4">
        Progression des encaissements par locataire
      </h3>
      <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
        {tenantData.length === 0 && (
          <p className="text-sm text-slate-400 text-center py-6">Aucun locataire actif</p>
        )}
        {tenantData.map((t, i) => (
          <div key={i} className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-700 truncate max-w-[60%]">{t.name}</span>
              <span className="text-slate-500">
                {formatXAF(t.paid)} / {formatXAF(t.expected)} XAF
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Progress
                value={t.percent}
                className="h-2 flex-1"
              />
              <span
                className={`text-xs font-bold ${
                  t.percent >= 80 ? "text-emerald-600" : t.percent >= 50 ? "text-amber-600" : "text-red-600"
                }`}
              >
                {t.percent}%
              </span>
            </div>
            <p className="text-[10px] text-slate-400">{t.property}</p>
          </div>
        ))}
      </div>
    </div>
  );
}