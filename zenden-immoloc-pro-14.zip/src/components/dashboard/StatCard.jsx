import React from "react";
import { motion } from "framer-motion";

export default function StatCard({ title, value, icon: Icon, color = "emerald", subtitle, onClick }) {
  const colors = {
    emerald: { bg: "bg-emerald-50", icon: "bg-emerald-500", text: "text-emerald-600" },
    blue: { bg: "bg-blue-50", icon: "bg-blue-500", text: "text-blue-600" },
    red: { bg: "bg-red-50", icon: "bg-red-500", text: "text-red-600" },
    amber: { bg: "bg-amber-50", icon: "bg-amber-500", text: "text-amber-600" },
    violet: { bg: "bg-violet-50", icon: "bg-violet-500", text: "text-violet-600" }
  };

  const c = colors[color] || colors.emerald;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      onClick={onClick}
      className={`zd-stat-card cursor-pointer group ${onClick ? "cursor-pointer" : ""}`}>

      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{title}</p>
          <p className="text-slate-900 mt-2 text-sm font-bold">{value}</p>
          {subtitle && <p className={`text-xs mt-1 ${c.text} font-medium`}>{subtitle}</p>}
        </div>
        <div className={`w-10 h-10 rounded-xl ${c.icon} flex items-center justify-center shadow-lg shadow-${color}-200/50`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
    </motion.div>);

}