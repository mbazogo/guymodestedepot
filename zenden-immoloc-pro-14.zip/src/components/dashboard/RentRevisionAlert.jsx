import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertTriangle, RefreshCw, X } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

export default function RentRevisionAlert({ tenants, leases }) {
  const [open, setOpen] = useState(false);
  const now = new Date();
  const twoMonthsLater = new Date(now.getFullYear(), now.getMonth() + 2, now.getDate());

  // Find leases ending within 2 months or tenants with no lease end date older than 12 months
  const toRevise = [];

  leases?.forEach((lease) => {
    if (!lease.end_date || lease.status !== "active") return;
    const end = new Date(lease.end_date);
    if (end <= twoMonthsLater && end >= now) {
      const tenant = tenants?.find((t) => t.id === lease.tenant_id);
      toRevise.push({ lease, tenant, daysLeft: Math.ceil((end - now) / (1000 * 60 * 60 * 24)) });
    }
  });

  // Also check tenants whose lease start is more than 12 months ago with no end date
  leases?.forEach((lease) => {
    if (lease.end_date || lease.status !== "active") return;
    const start = new Date(lease.start_date);
    const months = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth());
    if (months >= 12 && months % 12 === 0) {
      const tenant = tenants?.find((t) => t.id === lease.tenant_id);
      if (!toRevise.find((r) => r.lease.id === lease.id)) {
        toRevise.push({ lease, tenant, daysLeft: null, anniversary: months });
      }
    }
  });

  if (toRevise.length === 0) return null;

  return (
    <>
      <Card
        className="p-4 border-amber-200 bg-amber-50 cursor-pointer hover:shadow-md transition-shadow"
        onClick={() => setOpen(true)}
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center">
              <RefreshCw className="w-4.5 h-4.5 text-amber-600" />
            </div>
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-amber-500 animate-pulse" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-amber-800">Loyers à réviser</p>
            <p className="text-xs text-amber-600">{toRevise.length} bail(aux) nécessitent une révision</p>
          </div>
          <Badge className="bg-amber-500 text-white text-xs shrink-0">{toRevise.length}</Badge>
        </div>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-amber-500" />
              Loyers à réviser
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {toRevise.map(({ lease, tenant, daysLeft, anniversary }, i) => (
              <div key={i} className="p-3 border border-amber-200 rounded-lg bg-amber-50">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">
                      {tenant ? `${tenant.first_name} ${tenant.last_name}` : lease.tenant_name}
                    </p>
                    <p className="text-xs text-slate-500">{lease.property_name}</p>
                    <p className="text-xs text-slate-600 mt-1">Loyer actuel : <span className="font-bold">{formatXAF(lease.rent_amount)} XAF</span></p>
                  </div>
                  <div className="text-right">
                    {daysLeft !== null ? (
                      <Badge className={`text-xs ${daysLeft <= 30 ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                        {daysLeft}j restants
                      </Badge>
                    ) : (
                      <Badge className="bg-blue-100 text-blue-700 text-xs">
                        {anniversary} mois
                      </Badge>
                    )}
                  </div>
                </div>
                {lease.end_date && (
                  <p className="text-xs text-slate-400 mt-1">Échéance bail : {new Date(lease.end_date).toLocaleDateString("fr-FR")}</p>
                )}
              </div>
            ))}
          </div>
          <div className="pt-2">
            <Link to={createPageUrl("Leases")} onClick={() => setOpen(false)} className="text-sm text-blue-600 hover:underline">
              → Gérer les baux
            </Link>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}