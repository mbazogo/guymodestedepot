import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sparkles, Trash2, Loader2, X } from "lucide-react";

const DEMO_TAG = "__DEMO__";

const demoData = {
  buildings: [
    { name: "Résidence Les Palmiers", type: "immeuble", address: "12 Avenue de la Paix", city: "Douala", floors: 3, total_units: 6, notes: DEMO_TAG }
  ],
  properties: [
    { name: "Appartement 1A", type: "appartement", address: "12 Avenue de la Paix", city: "Douala", surface: 65, rooms: 3, rent_amount: 150000, status: "occupied", notes: DEMO_TAG },
    { name: "Appartement 1B", type: "appartement", address: "12 Avenue de la Paix", city: "Douala", surface: 55, rooms: 2, rent_amount: 120000, status: "occupied", notes: DEMO_TAG },
    { name: "Studio 2A", type: "studio", address: "12 Avenue de la Paix", city: "Douala", surface: 30, rooms: 1, rent_amount: 80000, status: "vacant", notes: DEMO_TAG },
    { name: "Maison Bastos", type: "maison", address: "45 Rue Bastos", city: "Yaoundé", surface: 120, rooms: 5, rent_amount: 300000, status: "occupied", notes: DEMO_TAG },
  ],
  tenants: [
    { civility: "M.", first_name: "Jean", last_name: "Mbarga", email: "jean.mbarga@email.com", phone: "+237 6 90 12 34 56", rent_amount: 150000, status: "active", notes: DEMO_TAG },
    { civility: "Mme", first_name: "Marie", last_name: "Tchangani", email: "marie.t@email.com", phone: "+237 6 75 98 23 11", rent_amount: 120000, status: "active", notes: DEMO_TAG },
    { civility: "M.", first_name: "Paul", last_name: "Essomba", email: "p.essomba@email.com", phone: "+237 6 55 44 33 22", rent_amount: 300000, status: "active", notes: DEMO_TAG },
  ],
  payments: [],
  charges: [
    { category: "maintenance", description: "Réparation toiture - DÉMO", amount: 85000, date: new Date().toISOString().split("T")[0], status: "paid", notes: DEMO_TAG },
    { category: "gardiennage", description: "Gardiennage janvier - DÉMO", amount: 45000, date: new Date().toISOString().split("T")[0], status: "paid", notes: DEMO_TAG },
  ]
};

export default function DemoDataBanner({ properties, onDismiss }) {
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [dismissed, setDismissed] = useState(() => localStorage.getItem("demo_banner_dismissed") === "1");
  const qc = useQueryClient();

  const hasDemoData = properties.some((p) => p.notes === DEMO_TAG);
  const isEmpty = properties.length === 0;

  const handleCreateDemo = async () => {
    setLoading(true);
    try {
      // Create building
      const [building] = await base44.entities.Building.bulkCreate(demoData.buildings);

      // Create properties linked to building
      const propsToCreate = demoData.properties.map((p, i) =>
        i < 3 ? { ...p, building_id: building.id, building_name: building.name } : p
      );
      const createdProps = await base44.entities.Property.bulkCreate(propsToCreate);

      // Create tenants linked to properties
      const tenantsToCreate = demoData.tenants.map((t, i) => ({
        ...t,
        property_id: createdProps[i]?.id || "",
        property_name: createdProps[i]?.name || "",
      }));
      const createdTenants = await base44.entities.Tenant.bulkCreate(tenantsToCreate);

      // Create payments for last 3 months
      const now = new Date();
      const paymentsToCreate = [];
      for (let m = 0; m < 3; m++) {
        const d = new Date(now.getFullYear(), now.getMonth() - m, 1);
        createdTenants.forEach((t, i) => {
          paymentsToCreate.push({
            tenant_id: t.id,
            tenant_name: `${t.first_name} ${t.last_name}`,
            property_id: createdProps[i]?.id || "",
            property_name: createdProps[i]?.name || "",
            amount: t.rent_amount,
            expected_amount: t.rent_amount,
            payment_date: new Date(d.getFullYear(), d.getMonth(), 5).toISOString().split("T")[0],
            period_month: d.getMonth() + 1,
            period_year: d.getFullYear(),
            payment_method: "especes",
            status: "paid",
            type: "loyer",
            notes: DEMO_TAG,
          });
        });
      }
      await base44.entities.Payment.bulkCreate(paymentsToCreate);
      await base44.entities.Charge.bulkCreate(demoData.charges);

      qc.invalidateQueries();
      setDismissed(true);
      localStorage.setItem("demo_banner_dismissed", "1");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteDemo = async () => {
    if (!confirm("Supprimer toutes les données de démo ? Cette action est irréversible.")) return;
    setDeleting(true);
    try {
      const [allProps, allTenants, allPayments, allCharges, allBuildings] = await Promise.all([
        base44.entities.Property.list(),
        base44.entities.Tenant.list(),
        base44.entities.Payment.list(),
        base44.entities.Charge.list(),
        base44.entities.Building.list(),
      ]);
      await Promise.all([
        ...allProps.filter((x) => x.notes === DEMO_TAG).map((x) => base44.entities.Property.delete(x.id)),
        ...allTenants.filter((x) => x.notes === DEMO_TAG).map((x) => base44.entities.Tenant.delete(x.id)),
        ...allPayments.filter((x) => x.notes === DEMO_TAG).map((x) => base44.entities.Payment.delete(x.id)),
        ...allCharges.filter((x) => x.notes === DEMO_TAG).map((x) => base44.entities.Charge.delete(x.id)),
        ...allBuildings.filter((x) => x.notes === DEMO_TAG).map((x) => base44.entities.Building.delete(x.id)),
      ]);
      qc.invalidateQueries();
      localStorage.removeItem("demo_banner_dismissed");
    } finally {
      setDeleting(false);
    }
  };

  const handleDismiss = () => {
    setDismissed(true);
    localStorage.setItem("demo_banner_dismissed", "1");
    onDismiss?.();
  };

  // Show delete button if demo data exists
  if (hasDemoData) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-amber-800">Données de démonstration actives</p>
            <p className="text-xs text-amber-600">Supprimez-les quand vous êtes prêt à utiliser vos vraies données.</p>
          </div>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={handleDeleteDemo}
          disabled={deleting}
          className="border-amber-300 text-amber-700 hover:bg-amber-100 shrink-0"
        >
          {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5 mr-1.5" />}
          {deleting ? "Suppression..." : "Supprimer les données démo"}
        </Button>
      </div>
    );
  }

  // Show create demo banner if empty and not dismissed
  if (!isEmpty || dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border border-emerald-200 rounded-xl p-5 relative">
      <button onClick={handleDismiss} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600">
        <X className="w-4 h-4" />
      </button>
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shrink-0">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-emerald-800 mb-1">Bienvenue sur Zenden ImmoLoc ! 👋</h3>
          <p className="text-xs text-emerald-700 mb-3">
            Votre espace est vide. Générez des données de démonstration pour explorer toutes les fonctionnalités de l'application (biens, locataires, paiements, charges...). Vous pourrez les supprimer à tout moment.
          </p>
          <div className="flex gap-3">
            <Button
              size="sm"
              onClick={handleCreateDemo}
              disabled={loading}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : <Sparkles className="w-3.5 h-3.5 mr-1.5" />}
              {loading ? "Création en cours..." : "Créer les données de démo"}
            </Button>
            <Button size="sm" variant="ghost" onClick={handleDismiss} className="text-emerald-700">
              Commencer sans données
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}