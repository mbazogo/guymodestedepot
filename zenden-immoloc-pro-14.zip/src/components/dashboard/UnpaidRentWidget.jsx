import React from "react";
import { AlertTriangle } from "lucide-react";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

export default function UnpaidRentWidget({ payments, tenants }) {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  // Late + pending payments for current month
  const unpaidThisMonth = payments.filter((p) =>
  p.period_year === currentYear &&
  p.period_month === currentMonth && (
  p.status === "late" || p.status === "pending")
  );

  const totalUnpaid = unpaidThisMonth.reduce((s, p) => s + ((p.expected_amount || p.amount || 0) - (p.status === "partial" ? p.amount || 0 : 0)), 0);
  const lateOnly = unpaidThisMonth.filter((p) => p.status === "late");

  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-slate-700 text-xs font-semibold flex items-center gap-2">Loyers impayés — mois en cours

        </h3>
        <span className="text-red-600 text-xs font-bold">{formatXAF(totalUnpaid)} XAF</span>
      </div>

      {unpaidThisMonth.length === 0 ?
      <p className="text-sm text-emerald-600 font-medium bg-emerald-50 rounded-lg px-3 py-2">✓ Aucun impayé ce mois-ci</p> :

      <div className="space-y-1 max-h-40 overflow-y-auto">
          {unpaidThisMonth.map((p) =>
        <div key={p.id} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-50 last:border-0">
              <div>
                <span className="font-medium text-slate-700">{p.tenant_name}</span>
                <span className="ml-1 text-slate-400">— {p.property_name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${p.status === "late" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                  {p.status === "late" ? "En retard" : "En attente"}
                </span>
                <span className="font-bold text-red-600">{formatXAF(p.expected_amount || p.amount)} XAF</span>
              </div>
            </div>
        )}
        </div>
      }

      <div className="flex gap-3 mt-3 text-[11px] text-slate-500">
        <span className="bg-red-50 text-red-600 px-2 py-0.5 rounded-full font-medium">{lateOnly.length} en retard</span>
        <span className="bg-amber-50 text-amber-600 px-2 py-0.5 rounded-full font-medium">{unpaidThisMonth.length - lateOnly.length} en attente</span>
      </div>
    </div>);

}