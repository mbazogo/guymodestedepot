import React from "react";
import { Building2 } from "lucide-react";

export default function OccupancyWidget({ properties }) {
  const total = properties.length;
  const occupied = properties.filter((p) => p.status === "occupied").length;
  const vacant = properties.filter((p) => p.status === "vacant").length;
  const maintenance = properties.filter((p) => p.status === "maintenance").length;
  const rate = total > 0 ? Math.round(occupied / total * 100) : 0;

  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-violet-500" /> Taux d'occupation
        </h3>
        <span className="text-emerald-600 text-base font-bold">
          {rate}%
        </span>
      </div>
      <div className="w-full bg-slate-100 rounded-full h-3 mb-3">
        <div
          className={`h-3 rounded-full transition-all duration-500 ${rate >= 80 ? "bg-violet-500" : rate >= 50 ? "bg-amber-500" : "bg-red-500"}`}
          style={{ width: `${rate}%` }} />

      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-emerald-50 rounded-lg p-2 text-center">
          <p className="text-xl font-bold text-emerald-700">{occupied}</p>
          <p className="text-[10px] text-emerald-600">Occupés</p>
        </div>
        <div className="bg-red-50 rounded-lg p-2 text-center">
          <p className="text-xl font-bold text-red-700">{vacant}</p>
          <p className="text-[10px] text-red-600">Vacants</p>
        </div>
        <div className="bg-amber-50 rounded-lg p-2 text-center">
          <p className="text-xl font-bold text-amber-700">{maintenance}</p>
          <p className="text-[10px] text-amber-600">Maintenance</p>
        </div>
      </div>
    </div>);

}