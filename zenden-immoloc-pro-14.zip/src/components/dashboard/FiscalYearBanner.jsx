import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Plus, ArrowRight, CheckCircle2, AlertTriangle } from "lucide-react";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

export default function FiscalYearBanner({ payments, charges, currentYear }) {
  const qc = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [step, setStep] = useState(1); // 1=summary, 2=confirm, 3=done
  const [loading, setLoading] = useState(false);

  const { data: fiscalYears = [], refetch } = useQuery({
    queryKey: ["fiscalYears"],
    queryFn: () => base44.entities.FiscalYear.list()
  });

  const activeYear = fiscalYears.find(f => f.status === "active") || { year: currentYear };
  const nextYear = (activeYear.year || currentYear) + 1;

  // Calcul de clôture
  const yearPayments = payments.filter(p => p.period_year === (activeYear.year || currentYear) && (p.status === "paid" || p.status === "partial"));
  const yearCharges = charges.filter(c => new Date(c.date).getFullYear() === (activeYear.year || currentYear));
  const totalRevenue = yearPayments.reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpenses = yearCharges.reduce((s, c) => s + (c.amount || 0), 0);
  const balance = totalRevenue - totalExpenses;
  const prevOpening = activeYear.opening_balance || 0;
  const reportANouveau = prevOpening + balance;

  const handleNewFiscalYear = async () => {
    setLoading(true);
    // Clôturer l'exercice actif
    if (activeYear.id) {
      await base44.entities.FiscalYear.update(activeYear.id, {
        status: "closed",
        closing_revenue: totalRevenue,
        closing_expenses: totalExpenses,
        closing_balance: reportANouveau
      });
    }
    // Créer le nouvel exercice
    await base44.entities.FiscalYear.create({
      year: nextYear,
      label: `Exercice ${nextYear}`,
      status: "active",
      start_date: `${nextYear}-01-01`,
      end_date: `${nextYear}-12-31`,
      opening_balance: reportANouveau,
      closing_revenue: 0,
      closing_expenses: 0,
      closing_balance: 0
    });
    await refetch();
    qc.invalidateQueries({ queryKey: ["fiscalYears"] });
    setLoading(false);
    setStep(3);
  };

  return (
    <>
      <div className="bg-white border border-slate-200 rounded-xl px-5 py-3 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#0f2b4c] flex items-center justify-center shrink-0">
            <CalendarDays className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-800">Exercice {activeYear.year || currentYear}</span>
              <Badge className="bg-emerald-100 text-emerald-700 text-[10px]">En cours</Badge>
            </div>
            {activeYear.opening_balance > 0 && (
              <p className="text-[11px] text-slate-500">Report à nouveau : {formatXAF(activeYear.opening_balance)} XAF</p>
            )}
          </div>
        </div>
        <Button
          size="sm"
          variant="outline"
          className="gap-1.5 text-xs border-[#0f2b4c] text-[#0f2b4c] hover:bg-[#0f2b4c] hover:text-white"
          onClick={() => { setStep(1); setShowDialog(true); }}
        >
          <Plus className="w-3.5 h-3.5" /> Nouvel exercice {nextYear}
        </Button>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarDays className="w-5 h-5 text-[#0f2b4c]" />
              Nouvel exercice comptable {nextYear}
            </DialogTitle>
          </DialogHeader>

          {step === 1 && (
            <div className="space-y-4">
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <h3 className="font-semibold text-slate-700 mb-3">Clôture de l'exercice {activeYear.year || currentYear}</h3>
                <div className="flex justify-between"><span className="text-slate-500">Revenus encaissés</span><span className="font-semibold text-emerald-700">+ {formatXAF(totalRevenue)} XAF</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Charges payées</span><span className="font-semibold text-red-600">− {formatXAF(totalExpenses)} XAF</span></div>
                {prevOpening !== 0 && <div className="flex justify-between"><span className="text-slate-500">Report entrant</span><span className="font-semibold text-blue-700">{formatXAF(prevOpening)} XAF</span></div>}
                <div className="flex justify-between border-t pt-2 mt-1">
                  <span className="font-semibold text-slate-700">Report à nouveau → {nextYear}</span>
                  <span className={`font-bold text-base ${reportANouveau >= 0 ? "text-emerald-700" : "text-red-600"}`}>{formatXAF(reportANouveau)} XAF</span>
                </div>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex gap-2 text-xs text-amber-800">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Cette opération clôturera l'exercice <strong>{activeYear.year || currentYear}</strong> et ouvrira un nouvel exercice <strong>{nextYear}</strong> avec le report à nouveau ci-dessus.</span>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
              <h3 className="font-semibold text-slate-800">Exercice {nextYear} ouvert !</h3>
              <p className="text-sm text-slate-500">Le report à nouveau de <strong>{formatXAF(reportANouveau)} XAF</strong> a été transféré vers le nouvel exercice.</p>
            </div>
          )}

          <DialogFooter>
            {step === 1 && (
              <>
                <Button variant="outline" onClick={() => setShowDialog(false)}>Annuler</Button>
                <Button onClick={() => setStep(2)} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-1.5">
                  Continuer <ArrowRight className="w-4 h-4" />
                </Button>
              </>
            )}
            {step === 2 && (
              <>
                <Button variant="outline" onClick={() => setStep(1)}>Retour</Button>
                <Button onClick={handleNewFiscalYear} disabled={loading} className="bg-emerald-600 hover:bg-emerald-700">
                  {loading ? "Création en cours..." : `Confirmer & ouvrir ${nextYear}`}
                </Button>
              </>
            )}
            {step === 3 && (
              <Button onClick={() => { setShowDialog(false); setStep(1); }} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] w-full">Fermer</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}