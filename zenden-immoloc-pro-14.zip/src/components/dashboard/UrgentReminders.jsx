import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Bell, AlertTriangle, CalendarClock, ExternalLink, Send } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

function daysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
}

const TYPE_LABELS = {
  fin_bail: "Fin de bail",
  echeance_loyer: "Échéance loyer",
  renouvellement_assurance: "Assurance",
  renouvellement_cni: "CNI",
  autre: "Autre",
};

export default function UrgentReminders() {
  const { data: reminders = [] } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list("-event_date"),
  });

  const urgent = reminders
    .filter(r => r.status === "active")
    .map(r => ({ ...r, days: daysUntil(r.event_date) }))
    .filter(r => r.days !== null && r.days <= 30)
    .sort((a, b) => a.days - b.days)
    .slice(0, 5);

  return (
    <div className="bg-white rounded-xl border border-amber-100 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center">
            <Bell className="w-4 h-4 text-amber-600" />
          </div>
          <h3 className="text-sm font-semibold text-slate-800">Rappels urgents</h3>
        </div>
        <Link to={createPageUrl("Reminders")} className="text-xs text-amber-600 hover:text-amber-700 font-medium flex items-center gap-1">
          Tous <ExternalLink className="w-3 h-3" />
        </Link>
      </div>

      {urgent.length === 0 ? (
        <p className="text-xs text-slate-400 text-center py-4">Aucun rappel urgent dans les 30 prochains jours 🎉</p>
      ) : (
        <div className="space-y-2">
          {urgent.map(r => (
            <div key={r.id} className={`flex items-center justify-between py-2 border-b border-slate-50 last:border-0`}>
              <div className="flex items-center gap-2.5 min-w-0">
                <div className={`w-2 h-2 rounded-full shrink-0 ${r.days < 0 ? "bg-red-500" : r.days <= 7 ? "bg-red-400" : "bg-amber-400"}`} />
                <div className="min-w-0">
                  <p className="text-xs font-medium text-slate-800 truncate">{r.tenant_name}</p>
                  <p className="text-[10px] text-slate-400">{TYPE_LABELS[r.type] || r.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0 ml-2">
                <CalendarClock className="w-3 h-3 text-slate-400" />
                <span className={`text-xs font-semibold whitespace-nowrap ${r.days < 0 ? "text-red-600" : r.days <= 7 ? "text-red-500" : "text-amber-600"}`}>
                  {r.days < 0 ? `${Math.abs(r.days)}j dép.` : r.days === 0 ? "Auj." : `${r.days}j`}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <Link to={createPageUrl("Reminders")}
        className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg py-2 transition-colors font-medium">
        <Bell className="w-3.5 h-3.5" /> Gérer les rappels
      </Link>
    </div>
  );
}