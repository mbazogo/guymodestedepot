import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ExternalLink } from "lucide-react";

function formatXAF(value) {
  return new Intl.NumberFormat("fr-FR").format(value || 0);
}

const statusLabels = {
  paid: { label: "Payé", class: "zd-badge-paid" },
  partial: { label: "Partiel", class: "zd-badge-pending" },
  pending: { label: "En attente", class: "zd-badge-pending" },
  late: { label: "En retard", class: "zd-badge-late" },
};

export default function LatestPayments({ payments }) {
  const sorted = [...payments]
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 8);

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-800">Derniers encaissements</h3>
        <Link
          to={createPageUrl("Payments")}
          className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1"
        >
          Voir tout <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="text-left py-2 text-slate-500 font-medium">Locataire</th>
              <th className="text-left py-2 text-slate-500 font-medium">Période</th>
              <th className="text-right py-2 text-slate-500 font-medium">Montant</th>
              <th className="text-right py-2 text-slate-500 font-medium">Statut</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((p) => {
              const st = statusLabels[p.status] || statusLabels.pending;
              return (
                <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="py-2.5 font-medium text-slate-700">{p.tenant_name}</td>
                  <td className="py-2.5 text-slate-500">
                    {String(p.period_month).padStart(2, "0")}/{p.period_year}
                  </td>
                  <td className="py-2.5 text-right font-semibold text-slate-800">
                    {formatXAF(p.amount)} XAF
                  </td>
                  <td className="py-2.5 text-right">
                    <span className={st.class}>{st.label}</span>
                  </td>
                </tr>
              );
            })}
            {sorted.length === 0 && (
              <tr>
                <td colSpan={4} className="py-6 text-center text-slate-400">
                  Aucun encaissement
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}