import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Printer, FileText, Layout } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

function generateContractHTML(lease, tenant, property, settings, template) {
  const today = new Date();
  const companyName = settings?.company_name || "Le Propriétaire";
  const ownerName = settings?.owner_name || companyName;
  const ownerAddress = settings?.owner_address || "";
  const ownerPhone = settings?.owner_phone || "";
  const typeLabels = { non_meuble: "d'habitation non meublée", meuble: "d'habitation meublée", bnb: "de type BnB", commercial: "commercial", autre: "" };
  const renewalMonths = template?.renewal_months || 24;
  const renewalYears = Math.round(renewalMonths / 12);
  const noticeMonths = template?.notice_months || 3;

  const startDate = lease?.start_date ? new Date(lease.start_date) : today;
  const endDate = lease?.end_date ? new Date(lease.end_date) : null;

  const logoHtml = settings?.logo_url
    ? `<img src="${settings.logo_url}" alt="Logo" style="height:60px; object-fit:contain; margin-bottom:8px;" /><br/>`
    : "";
  const signatureHtml = settings?.signature_url
    ? `<img src="${settings.signature_url}" alt="Signature" style="height:50px; object-fit:contain; display:block; margin:8px auto 0;" />`
    : "";

  const paymentDay = lease?.payment_day || 1;
  const pdSuffix = paymentDay === 1 ? "er" : "ème";

  const allClauses = [lease?.clauses, template?.additional_clauses].filter(Boolean).join("\n\n");
  const leaseArticleN = allClauses ? 22 : 21;

  const headerText = template?.header_text || "";
  const footerText = template?.footer_text || "";

  return `
    <div style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; line-height: 1.8; color: #1a1a1a; max-width: 760px; margin: auto; padding: 40px;">
      <div style="text-align:center; margin-bottom: 30px;">
        ${logoHtml}
        <p style="font-size:10pt; color:#555; margin-bottom:4px;">LOI N° 15/88 DU 30 DÉCEMBRE 1988 FIXANT LE RÉGIME LOCATIF DES IMMEUBLES ET LOCAUX À USAGE D'HABITATION OU À USAGE MIXTE</p>
        <h1 style="font-size: 18pt; font-weight: bold; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 6px;">Contrat de bail ${typeLabels[lease?.type] || ""}</h1>
        ${template ? `<p style="font-size:10pt; color:#666; margin-bottom:4px;">Modèle : ${template.name}</p>` : ""}
        <p style="color: #555; font-size: 10pt;">Réf. BAIL-${lease?.id?.slice(-6)?.toUpperCase() || "XXXX"} — ${today.toLocaleDateString("fr-FR")}</p>
        <hr style="border: 1.5px solid #333; margin-top: 10px;" />
      </div>

      ${headerText ? `<div style="background:#f8f9fa; border-left:3px solid #0f2b4c; padding:12px 16px; margin-bottom:20px; font-style:italic;">${headerText.replace(/\n/g, "<br/>")}</div>` : ""}

      <h2 style="font-size: 13pt; font-weight: bold; margin-top: 24px; border-bottom: 1px solid #ccc; padding-bottom: 4px;">ENTRE LES SOUSSIGNÉS</h2>

      <p><strong>LE BAILLEUR :</strong><br/>
      ${ownerName}<br/>
      ${ownerAddress ? `Adresse : ${ownerAddress}<br/>` : ""}
      ${ownerPhone ? `Téléphone : ${ownerPhone}<br/>` : ""}
      ${settings?.owner_email ? `Email : ${settings.owner_email}` : ""}
      <br/><em>Ci-après dénommé « Le Bailleur »,</em>
      </p>
      <p style="margin-top:4px;"><strong>D'une part,</strong></p>

      <p style="margin-top: 12px;"><strong>ET LE PRENEUR :</strong><br/>
      ${tenant?.civility ? `${tenant.civility} ` : ""}${tenant?.first_name || ""} ${tenant?.last_name || ""}<br/>
      ${tenant?.phone ? `Téléphone : ${tenant.phone}<br/>` : ""}
      ${tenant?.email ? `Email : ${tenant.email}<br/>` : ""}
      ${tenant?.id_number ? `Pièce d'identité : ${tenant.id_number}<br/>` : ""}
      ${tenant?.emergency_contact ? `Contact d'urgence : ${tenant.emergency_contact}` : ""}
      <br/><em>Ci-après désigné « Le Preneur »,</em>
      </p>
      <p><strong>D'autre part,</strong></p>

      <p style="margin-top:16px; font-style:italic;">Il a été convenu et arrêté ce qui suit :</p>

      <h2 style="font-size: 13pt; font-weight: bold; margin-top: 24px; border-bottom: 1px solid #ccc; padding-bottom: 4px;">PRÉAMBULE</h2>
      <p>${tenant?.civility ? `${tenant.civility} ` : ""}${tenant?.first_name || ""} ${tenant?.last_name || ""} souhaite conclure un contrat de location avec ${ownerName} ; ${ownerName} accepte d'être Le Bailleur selon les conditions spécifiées dans le présent contrat. Les Parties conviennent de ce qui suit :</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 1 : OBJET DU CONTRAT</h3>
      <p>Par les présentes, Le Bailleur donne à bail, conformément aux dispositions de la loi n° 15/88 du 30 décembre 1988, fixant les modalités du bail d'habitation, au Preneur qui accepte, les lieux ci-après désignés.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 2 : CONSISTANCE - DÉSIGNATION</h3>
      <p>Les lieux loués consistent en <strong>${property?.name || "—"}</strong>, situé(e) <strong>${property?.address || ""}${property?.city ? ", " + property.city : ""}</strong>.<br/>
      ${property?.type ? `Type : <strong>${property.type}</strong>` : ""} ${property?.surface ? `— Surface : <strong>${property.surface} m²</strong>` : ""} ${property?.rooms ? `— <strong>${property.rooms} pièce(s)</strong>` : ""}${property?.furnished ? " — <strong>Meublé</strong>" : ""}.<br/>
      Le Preneur déclare bien connaître les lieux pour les avoir expressément visités.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 3 : ÉTAT DES LIEUX</h3>
      <p>Un état des lieux sera dressé contradictoirement par les Parties, lors de la remise des clés au Preneur pour être joint aux présentes. Un autre état des lieux sera établi à l'expiration de la durée du contrat ou à sa résiliation.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 4 : DURÉE</h3>
      <p>Le présent bail est consenti et accepté pour une durée de <strong>deux (2) ans</strong> à compter du <strong>${startDate.toLocaleDateString("fr-FR")}</strong>${endDate ? ` pour expirer le <strong>${endDate.toLocaleDateString("fr-FR")}</strong>` : ""}.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 5 : RENOUVELLEMENT</h3>
      <p>À l'expiration du terme fixé par le présent contrat, le bail se renouvellera par tacite reconduction pour une période de <strong>${renewalYears > 1 ? `${renewalYears} ans` : "un (1) an"} (${renewalMonths} mois)</strong>.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 6 : RÉSILIATION NON MOTIVÉE</h3>
      <p>Chaque Partie pourra décider de ne pas renouveler le contrat à l'expiration de la durée initiale ou de la durée de reconduction automatique, à condition de prévenir l'autre Partie <strong>${noticeMonths} mois</strong> au moins à l'avance par lettre recommandée avec accusé de réception ou par acte extrajudiciaire.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 7 : REPRISE POUR HABITER</h3>
      <p>Le Bailleur peut décider de reprendre les locaux loués pour les habiter lui-même ou les faire habiter par ses ascendants ou ses descendants un (1) an au moins après la prise d'effet du bail.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 8 : REPRISE POUR RECONSTRUIRE</h3>
      <p>Deux (2) ans au moins après la prise d'effet du bail, Le Bailleur peut reprendre les lieux en vue de réaliser des travaux de construction ou d'aménagement, à condition de prévenir les locataires ${noticeMonths} mois au moins à l'avance.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 9 : TRAVAUX D'AMÉLIORATION</h3>
      <p>Le Bailleur peut entreprendre des travaux d'amélioration lorsque ceux-ci ne rendent pas inhabitable ce qui est nécessaire au logement du Preneur, après notification de ${noticeMonths} mois par lettre recommandée.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 10 : RÉSILIATION À L'AMIABLE</h3>
      <p>Les Parties conviennent de mettre fin au présent contrat avant la date fixée dans l'acte de préavis, dans les cas de reprise pour habiter, pour reconstruire ou pour travaux d'amélioration.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 11 : RÉSILIATION DU BAIL POUR CAUSE DE CESSION</h3>
      <p>Pendant la durée de renouvellement du bail, Le Bailleur peut mettre fin au contrat par la vente de la propriété, à condition que Le Preneur en soit prévenu par acte extrajudiciaire ${noticeMonths} mois avant la prise d'effet de la cession.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 12 : CESSION DES BIENS LOUÉS SANS RÉSILIATION</h3>
      <p>Le Bailleur peut vendre ou donner le logement loué sans résiliation du bail, à condition que les locataires en soient informés par acte extrajudiciaire ${noticeMonths} mois au moins avant la prise d'effet de l'acte et que le nouveau propriétaire s'engage à maintenir les locataires.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 13 : LOYERS</h3>
      <p>Le présent bail est consenti moyennant un loyer mensuel de <strong>${formatXAF(lease?.rent_amount)} XAF</strong>${lease?.tva_applicable ? ` hors taxes (TVA ${lease.tva_rate || 0}%)` : ""}, payable le <strong>${paymentDay}${pdSuffix}</strong> de chaque mois.
      ${lease?.charges_amount ? `<br/>Les charges mensuelles sont de <strong>${formatXAF(lease.charges_amount)} XAF</strong>.` : ""}
      <br/>L'augmentation des loyers intervient tous les deux (2) ans à compter de la date de prise d'effet du contrat. Le Bailleur qui désire procéder à l'augmentation doit informer les locataires ${noticeMonths} mois au moins à l'avance.
      <br/>Le défaut de paiement des loyers pour une seule période entraînera la résiliation de plein droit un (1) mois après mise en demeure.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 14 : DÉPÔT DE GARANTIE</h3>
      <p>${lease?.deposit_amount ? `Le Preneur versera au Bailleur à la signature du présent contrat un dépôt de garantie de <strong>${formatXAF(lease.deposit_amount)} XAF</strong>, correspondant à un (1) mois de loyer. Cette somme sera remboursée dans un délai de soixante (60) jours après le départ du Preneur, déduction faite des sommes éventuellement dues. <br/><strong>ATTENTION : LE DÉPÔT DE GARANTIE NE PAIE PAS LE DERNIER MOIS DE LOYER.</strong>` : "Aucun dépôt de garantie n'est requis pour ce bail."}</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 14 BIS : RETENUE SUR DÉPÔT DE GARANTIE — VIDANGE DES FOSSES SEPTIQUES</h3>
      <p>Il est expressément convenu entre les Parties qu'une somme forfaitaire sera retenue sur le dépôt de garantie au titre des travaux de vidange des fosses septiques, selon la durée d'occupation des lieux :</p>
      <ul style="margin-left: 20px;">
        <li>Pour une durée d'occupation de <strong>1 à 12 mois</strong> : retenue forfaitaire de <strong>45 000 XAF (quarante-cinq mille francs CFA)</strong> ;</li>
        <li>Pour une durée d'occupation <strong>supérieure à 12 mois</strong> : retenue forfaitaire de <strong>55 000 XAF (cinquante-cinq mille francs CFA)</strong>.</li>
      </ul>
      <p>Cette retenue est effectuée de manière automatique lors de la restitution du dépôt de garantie, sans préjudice des autres déductions éventuellement applicables au titre des dégradations ou loyers impayés.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 15 : CHARGES LOCATIVES</h3>
      <p>Les locataires sont tenus, en sus du loyer principal, au paiement des charges locatives correspondant aux services rendus liés à l'usage des différents éléments des locaux loués, aux dépenses d'entretien et aux menues réparations.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 16 : CESSION DU BAIL ET SOUS-LOCATION</h3>
      <p>Sous peine de résiliation de plein droit, Le Preneur n'a le droit ni de céder ni de sous-louer son bail, sauf accord exprès et écrit du Bailleur.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 17 : OBLIGATIONS DU PRENEUR</h3>
      <p>Le Preneur s'engage à :</p>
      <ul style="margin-left: 20px;">
        <li>User paisiblement des locaux loués et éviter de troubler la tranquillité des voisins ;</li>
        <li>Payer régulièrement le loyer et les charges aux termes convenus ;</li>
        <li>Prendre en charge l'entretien courant des locaux et les réparations locatives ;</li>
        <li>Ne faire aucun changement de distribution ni travaux de transformation sans autorisation écrite du Bailleur ;</li>
        <li>Souscrire une assurance habitation (incendie, explosions, dégâts des eaux) et en justifier au Bailleur ;</li>
        <li>Répondre des dégradations et pertes survenues dans les lieux loués ;</li>
        <li>Ne pas donner aux locaux une destination autre que celle indiquée au contrat ;</li>
        <li>Permettre l'accès des lieux au Bailleur ou son représentant une (1) fois par semestre.</li>
      </ul>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 18 : OBLIGATIONS DU BAILLEUR</h3>
      <p>Le Bailleur s'engage à :</p>
      <ul style="margin-left: 20px;">
        <li>Délivrer au Preneur les locaux en bon état de réparation ;</li>
        <li>Assurer au Preneur la jouissance paisible des locaux ;</li>
        <li>Prendre en charge les grosses réparations (plomberie, sanitaires, système électrique, climatisation...) ;</li>
        <li>Remettre une quittance de loyer à chaque paiement.</li>
      </ul>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 19 : RÉSILIATION MOTIVÉE OU DE PLEIN DROIT</h3>
      <p>Le contrat est résilié de plein droit au profit du Bailleur si Le Preneur n'exécute pas ses obligations, abandonne les lieux pendant plus de six (6) mois consécutifs, décède ou est frappé d'une peine de prison ferme supérieure à six (6) mois. La résiliation ne produit ses effets qu'un (1) mois après notification.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 20 : RÉSILIATION JUDICIAIRE</h3>
      <p>Les Parties ont à tout moment la faculté de saisir le Tribunal de première instance d'une action en résiliation judiciaire du bail, avec demande de dommages et intérêts, pour inexécution des obligations.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 21 : FRAIS ET DROITS D'ENREGISTREMENT</h3>
      <p>Tous les frais, droits d'enregistrement et de timbre auxquels donneront lieu les présentes seront supportés par Le Preneur.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 22 : ÉLECTION DE DOMICILE</h3>
      <p>Pour l'exécution des présentes, les Parties font élection de domicile aux adresses respectives définies ci-dessus.</p>

      <h2 style="font-size: 13pt; font-weight: bold; margin-top: 30px; border-bottom: 2px solid #333; padding-bottom: 6px; text-transform: uppercase;">Dispositions Particulières</h2>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 23 : Entretien et vidange de la fosse septique</h3>
      <p>Le Preneur s'engage à contribuer aux frais d'entretien et de vidange de la fosse septique lorsque celle-ci est rendue nécessaire pendant la durée de son occupation du logement. Cette participation pourra être demandée proportionnellement à la durée d'occupation ou à l'usage du logement, dans les conditions prévues à l'Article 14 BIS du présent contrat.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 24 : Entretien courant du logement</h3>
      <p>Le Preneur est tenu d'assurer l'entretien courant du logement loué, notamment le maintien en bon état de propreté, l'entretien des installations sanitaires, électriques et des équipements mis à sa disposition pendant toute la durée du bail. Cette obligation s'inscrit en complément des obligations générales définies à l'Article 17 du présent contrat.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 25 : Travaux de peinture avant restitution</h3>
      <p>Avant la restitution des lieux, le Preneur s'engage à procéder à la réfection complète des peintures intérieures du logement. La conformité et l'état des travaux réalisés seront vérifiés lors de l'état des lieux de sortie visé à l'Article 3 du présent contrat. À défaut, le coût des travaux de remise en peinture sera déduit du dépôt de garantie.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 26 : Dépôt de garantie — affectation et interdiction d'imputation sur le dernier loyer</h3>
      <p>Le dépôt de garantie versé par le Preneur lors de la signature du présent contrat, tel que défini à l'Article 14, <strong>ne peut en aucun cas être utilisé comme paiement du dernier mois de loyer.</strong> Il restera acquis au Bailleur jusqu'à la restitution des lieux et pourra servir à couvrir les éventuelles dégradations, réparations locatives ou sommes restant dues, y compris les frais de peinture et de vidange de fosse septique visés aux Articles 24 et 25 ci-dessus.</p>

      <h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 27 : État des lieux et réparations locatives</h3>
      <p>Conformément à l'Article 3 du présent contrat, un état des lieux sera établi à l'entrée et à la sortie du Preneur. Toute dégradation constatée lors de l'état des lieux de sortie, au-delà de l'usure normale, sera à la charge exclusive du Preneur et pourra être déduite du dépôt de garantie ou faire l'objet d'un remboursement complémentaire si le montant des réparations excède ce dépôt.</p>

      ${allClauses ? `<h3 style="font-size: 12pt; font-weight: bold; margin-top: 20px;">Article 28 : CLAUSES ADDITIONNELLES</h3><p>${allClauses.replace(/\n/g, "<br/>")}</p>` : ""}

      ${footerText ? `<div style="border-top:1px solid #ccc; margin-top:20px; padding-top:12px; font-style:italic; color:#555;">${footerText.replace(/\n/g, "<br/>")}</div>` : ""}

      <p style="margin-top:20px; font-style:italic;">Le présent contrat est établi conformément à la Loi n° 15/88 du 30 décembre 1988 fixant le régime locatif des immeubles et locaux à usage d'habitation ou à usage mixte en République Gabonaise.</p>

      <div style="margin-top: 50px; display: flex; justify-content: space-between; gap: 40px;">
        <div style="flex:1; text-align: center;">
          <p style="font-weight: bold; margin-bottom: 60px;">LE BAILLEUR</p>
          ${signatureHtml}
          <p style="border-top: 1px solid #333; padding-top: 6px; font-size: 10pt;">${ownerName}</p>
        </div>
        <div style="flex:1; text-align: center;">
          <p style="font-weight: bold; margin-bottom: 60px;">LE PRENEUR</p>
          <p style="border-top: 1px solid #333; padding-top: 6px; font-size: 10pt;">${tenant?.civility ? `${tenant.civility} ` : ""}${tenant?.first_name || ""} ${tenant?.last_name || ""}</p>
        </div>
      </div>

      <p style="text-align: center; color: #888; font-size: 9pt; margin-top: 30px;">Fait à Libreville, le ${today.toLocaleDateString("fr-FR")} — En deux (2) exemplaires originaux</p>
    </div>
  `;
}

export default function LeaseContractModal({ lease, tenant, property, settings, onClose }) {
  const [selectedTemplateId, setSelectedTemplateId] = useState("default");

  const { data: templates = [] } = useQuery({
    queryKey: ["leaseTemplates"],
    queryFn: () => base44.entities.LeaseTemplate.list(),
  });

  // Auto-select default template for lease type
  const defaultTemplate = templates.find(t => t.type === lease?.type && t.is_default);
  const selectedTemplate = selectedTemplateId === "default"
    ? (defaultTemplate || null)
    : templates.find(t => t.id === selectedTemplateId) || null;

  const html = generateContractHTML(lease, tenant, property, settings, selectedTemplate);

  const handlePrint = () => {
    const w = window.open("", "_blank");
    w.document.write(`<html><head><title>Contrat de bail</title><style>@media print{body{margin:0}}</style></head><body>${html}</body></html>`);
    w.document.close();
    w.print();
  };

  const handleSaveDoc = async () => {
    await base44.entities.Document.create({
      name: `Contrat de bail — ${tenant?.first_name} ${tenant?.last_name}`,
      type: "bail",
      tenant_id: lease?.tenant_id,
      tenant_name: `${tenant?.first_name} ${tenant?.last_name}`,
      property_id: lease?.property_id,
      property_name: property?.name,
      content: html,
      status: "draft"
    });
    alert("Contrat sauvegardé dans vos documents !");
    onClose();
  };

  const typeLabels = { non_meuble: "Non meublé", meuble: "Meublé", bnb: "BnB", commercial: "Commercial", autre: "Autre" };
  const compatibleTemplates = templates.filter(t => t.type === lease?.type);

  return (
    <Dialog open={!!lease} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Contrat de bail — {tenant?.first_name} {tenant?.last_name}
          </DialogTitle>
        </DialogHeader>

        {/* Template selector */}
        {templates.length > 0 && (
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <Layout className="w-4 h-4 text-slate-500 shrink-0" />
            <Label className="text-sm shrink-0">Modèle :</Label>
            <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
              <SelectTrigger className="flex-1 h-8 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Standard (par défaut)</SelectItem>
                {compatibleTemplates.map(t => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name} {t.is_default ? "⭐" : ""}
                  </SelectItem>
                ))}
                {compatibleTemplates.length === 0 && (
                  <SelectItem value="__none__" disabled>Aucun modèle pour ce type de bail</SelectItem>
                )}
              </SelectContent>
            </Select>
            {selectedTemplate && (
              <span className="text-xs text-slate-500 shrink-0">
                Reconduction {selectedTemplate.renewal_months}m • Préavis {selectedTemplate.notice_months}m
              </span>
            )}
          </div>
        )}

        {/* Preview */}
        <div className="border rounded-xl bg-white overflow-auto max-h-[52vh]">
          <div dangerouslySetInnerHTML={{ __html: html }} />
        </div>

        <DialogFooter className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
          <Button variant="outline" onClick={handleSaveDoc} className="text-blue-600 border-blue-200">
            <FileText className="w-4 h-4 mr-1.5" /> Sauvegarder dans Documents
          </Button>
          <Button onClick={handlePrint} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
            <Printer className="w-4 h-4 mr-1.5" /> Imprimer / PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}