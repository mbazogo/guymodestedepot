import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Star, FileText } from "lucide-react";

const TYPE_LABELS = { non_meuble: "Non meublé", meuble: "Meublé", commercial: "Commercial", bnb: "BnB", autre: "Autre" };

const DEFAULT_FORM = {
  name: "", type: "non_meuble", description: "", is_default: false,
  header_text: "", additional_clauses: "", footer_text: "",
  renewal_months: 24, notice_months: 3,
};

export default function LeaseTemplateManager({ open, onClose }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(DEFAULT_FORM);
  const qc = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["leaseTemplates"],
    queryFn: () => base44.entities.LeaseTemplate.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId
      ? base44.entities.LeaseTemplate.update(editingId, data)
      : base44.entities.LeaseTemplate.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["leaseTemplates"] }); setDialogOpen(false); }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.LeaseTemplate.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leaseTemplates"] })
  });

  const openNew = () => { setForm(DEFAULT_FORM); setEditingId(null); setDialogOpen(true); };
  const openEdit = (t) => { setForm({ ...t }); setEditingId(t.id); setDialogOpen(true); };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Modèles de contrats de bail
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div className="flex justify-end">
            <Button onClick={openNew} size="sm" className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              <Plus className="w-4 h-4 mr-1" /> Nouveau modèle
            </Button>
          </div>

          {templates.length === 0 && (
            <div className="text-center py-10 text-slate-400">
              <FileText className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-sm">Aucun modèle personnalisé — le modèle standard sera utilisé.</p>
            </div>
          )}

          {templates.map(t => (
            <div key={t.id} className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{t.name}</span>
                    {t.is_default && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />}
                    <Badge className="text-[10px] bg-blue-100 text-blue-700">{TYPE_LABELS[t.type]}</Badge>
                  </div>
                  {t.description && <p className="text-xs text-slate-500 mt-0.5">{t.description}</p>}
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Reconduction : {t.renewal_months || 24} mois • Préavis : {t.notice_months || 3} mois
                  </p>
                </div>
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(t)}>
                  <Pencil className="w-4 h-4 text-slate-500" />
                </Button>
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { if (confirm("Supprimer ce modèle ?")) deleteMutation.mutate(t.id); }}>
                  <Trash2 className="w-4 h-4 text-red-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Fermer</Button>
        </DialogFooter>
      </DialogContent>

      {/* Inner edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le modèle" : "Nouveau modèle"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Nom du modèle *</Label>
                <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Ex: Bail standard habitation" />
              </div>
              <div>
                <Label>Type de bail *</Label>
                <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Description courte</Label>
              <Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Description du modèle..." />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Durée de reconduction (mois)</Label>
                <Input type="number" value={form.renewal_months || 24} onChange={e => setForm({ ...form, renewal_months: Number(e.target.value) })} />
              </div>
              <div>
                <Label>Préavis (mois)</Label>
                <Input type="number" value={form.notice_months || 3} onChange={e => setForm({ ...form, notice_months: Number(e.target.value) })} />
              </div>
            </div>
            <div>
              <Label>Texte d'introduction personnalisé</Label>
              <Textarea value={form.header_text || ""} onChange={e => setForm({ ...form, header_text: e.target.value })} rows={3} placeholder="Texte à insérer en préambule du contrat..." />
            </div>
            <div>
              <Label>Clauses supplémentaires</Label>
              <Textarea value={form.additional_clauses || ""} onChange={e => setForm({ ...form, additional_clauses: e.target.value })} rows={4} placeholder="Clauses personnalisées à ajouter au contrat..." />
            </div>
            <div>
              <Label>Texte de pied de contrat</Label>
              <Textarea value={form.footer_text || ""} onChange={e => setForm({ ...form, footer_text: e.target.value })} rows={2} placeholder="Texte en bas de contrat..." />
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium">Modèle par défaut</p>
                <p className="text-xs text-slate-400">Utilisé automatiquement pour ce type de bail</p>
              </div>
              <Switch checked={!!form.is_default} onCheckedChange={v => setForm({ ...form, is_default: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending || !form.name} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}