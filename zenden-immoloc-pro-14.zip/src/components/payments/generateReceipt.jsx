import { base44 } from "@/api/base44Client";

const MONTHS_FR = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const methodLabels = { especes: "Espèces", virement: "Virement bancaire", cheque: "Chèque", mobile_money: "Mobile Money", autre: "Autre" };
function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

function buildReceiptHTML(payment, settings) {
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const ownerName = settings?.owner_name || "Le Propriétaire";
  const month = MONTHS_FR[(payment.period_month || 1) - 1];
  const logoHtml = settings?.logo_url ? `<img src="${settings.logo_url}" alt="Logo" style="height:48px;object-fit:contain;display:block;margin-bottom:8px;" />` : "";
  const sigHtml = settings?.signature_url ? `<img src="${settings.signature_url}" alt="Signature" style="height:60px;object-fit:contain;display:block;margin:0 auto 4px;" />` : `<div style="height:60px;"></div>`;
  const clauseHtml = settings?.receipt_custom_clause ? `<div style="background:#fffbeb;border:1px solid #fef3c7;border-radius:8px;padding:12px 16px;margin:16px 0;font-size:11px;color:#64748b;font-style:italic;">${settings.receipt_custom_clause}</div>` : "";
  const refHtml = (settings?.receipt_show_reference !== false) && payment.reference ? `<p style="font-size:11px;color:#64748b;margin-top:8px;">Référence : <strong>${payment.reference}</strong></p>` : "";
  const footerText = settings?.receipt_footer_text || `Le bailleur certifie avoir reçu la somme de ${formatXAF(payment.amount)} XAF en règlement du loyer du bien susmentionné.`;
  const today = new Date().toLocaleDateString("fr-FR");

  return `<html><head><title>Quittance de loyer</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 40px; color: #1e293b; font-size: 13px; margin: 0; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; border-bottom: 2px solid #0f2b4c; padding-bottom: 16px; }
    .company-name { font-size: 20px; font-weight: bold; color: #0f2b4c; }
    .subtitle { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 2px; }
    .ref-block { text-align: right; font-size: 11px; color: #64748b; }
    .title-block { text-align: center; margin: 20px 0; }
    .title-block h1 { font-size: 18px; font-weight: bold; text-transform: uppercase; color: #0f2b4c; border: 2px solid #0f2b4c; padding: 8px 24px; display: inline-block; letter-spacing: 1px; }
    .period { font-size: 13px; color: #475569; margin-top: 8px; }
    .parties { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
    .party { background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; border-radius: 8px; }
    .party-label { font-size: 10px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
    .party-name { font-size: 14px; font-weight: 700; }
    .party-detail { font-size: 11px; color: #475569; margin-top: 2px; }
    .amount-block { background: #0f2b4c; color: white; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0; }
    .amount-value { font-size: 30px; font-weight: bold; letter-spacing: 1px; }
    .amount-label { font-size: 11px; opacity: 0.75; margin-top: 4px; }
    .details { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin: 16px 0; }
    .detail-box { background: #f8fafc; padding: 10px; border-radius: 8px; text-align: center; }
    .detail-label { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .detail-value { font-size: 12px; font-weight: 600; margin-top: 4px; }
    .footer-section { margin-top: 32px; border-top: 1px solid #e2e8f0; padding-top: 20px; display: flex; justify-content: space-between; align-items: flex-end; }
    .footer-text { font-size: 10px; color: #64748b; max-width: 55%; line-height: 1.6; }
    .signature { text-align: center; }
    .sig-line { border-top: 1px solid #1e293b; padding-top: 4px; font-size: 11px; color: #374151; width: 180px; margin: 0 auto; }
    .legal { font-size: 9px; color: #94a3b8; text-align: center; margin-top: 20px; }
  </style></head><body>
  <div class="header">
    <div>${logoHtml}<div class="company-name">${companyName}</div><div class="subtitle">Gestion locative</div>${settings?.owner_address ? `<div style="font-size:11px;color:#64748b;margin-top:4px;">${settings.owner_address}</div>` : ""}${settings?.owner_phone ? `<div style="font-size:11px;color:#64748b;">${settings.owner_phone}</div>` : ""}</div>
    <div class="ref-block"><div>N° QTT-${payment.id?.slice(-6).toUpperCase() || ""}</div><div style="margin-top:4px;">Émise le ${today}</div></div>
  </div>
  <div class="title-block"><h1>Quittance de Loyer</h1><p class="period">Pour le mois de <strong>${month} ${payment.period_year}</strong></p></div>
  <div class="parties">
    <div class="party"><div class="party-label">Bailleur</div><div class="party-name">${ownerName}</div>${settings?.owner_address ? `<div class="party-detail">${settings.owner_address}</div>` : ""}${settings?.owner_email ? `<div class="party-detail">${settings.owner_email}</div>` : ""}</div>
    <div class="party"><div class="party-label">Locataire</div><div class="party-name">${payment.tenant_name}</div><div class="party-detail">${payment.property_name}</div></div>
  </div>
  <div class="amount-block"><div class="amount-value">${formatXAF(payment.amount)} XAF</div><div class="amount-label">Montant reçu en paiement du loyer</div></div>
  <div class="details">
    <div class="detail-box"><div class="detail-label">Bien loué</div><div class="detail-value">${payment.property_name}</div></div>
    <div class="detail-box"><div class="detail-label">Période</div><div class="detail-value">${month} ${payment.period_year}</div></div>
    <div class="detail-box"><div class="detail-label">Mode de paiement</div><div class="detail-value">${methodLabels[payment.payment_method] || payment.payment_method || "—"}</div></div>
  </div>
  ${refHtml}
  ${clauseHtml}
  <div class="footer-section">
    <div class="footer-text">${footerText}</div>
    <div class="signature">${sigHtml}<div class="sig-line">${ownerName}</div></div>
  </div>
  <div class="legal">Document généré par ${companyName} • Quittance valable comme reçu de paiement</div>
  </body></html>`;
}

/**
 * Génère la quittance HTML, l'uploade comme fichier et met à jour le paiement avec l'URL.
 * Retourne l'URL uploadée.
 */
export async function generateAndSaveReceipt(payment, settings) {
  const html = buildReceiptHTML(payment, settings);
  const blob = new Blob([html], { type: "text/html" });
  const file = new File([blob], `quittance-${payment.id?.slice(-6)}-${payment.period_month}-${payment.period_year}.html`, { type: "text/html" });

  const { file_url } = await base44.integrations.Core.UploadFile({ file });
  await base44.entities.Payment.update(payment.id, { receipt_url: file_url });
  return file_url;
}