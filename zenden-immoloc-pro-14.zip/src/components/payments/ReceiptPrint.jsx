import React, { useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, X, Save, Loader2, MessageCircle } from "lucide-react";
import { generateAndSaveReceipt } from "./generateReceipt";
import { useQueryClient } from "@tanstack/react-query";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

const MONTHS_FR = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const methodLabels = { especes: "Espèces", virement: "Virement bancaire", cheque: "Chèque", mobile_money: "Mobile Money", autre: "Autre" };

export default function ReceiptPrint({ payment, settings, onClose }) {
  const printRef = useRef();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const queryClient = useQueryClient();

  const handleSave = async () => {
    setSaving(true);
    await generateAndSaveReceipt(payment, settings);
    await queryClient.invalidateQueries({ queryKey: ["payments"] });
    setSaving(false);
    setSaved(true);
  };

  if (!payment) return null;

  const handlePrint = () => {
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const ownerName = settings?.owner_name || "Le Propriétaire";
    const month = MONTHS_FR[(payment.period_month || 1) - 1];
    const logoHtml = settings?.logo_url ? `<img src="${settings.logo_url}" alt="Logo" style="height:48px;object-fit:contain;display:block;margin-bottom:8px;" />` : "";
    const sigHtml = settings?.signature_url ? `<img src="${settings.signature_url}" alt="Signature" style="height:60px;object-fit:contain;display:block;margin:0 auto 4px;" />` : `<div style="height:60px;"></div>`;
    const clauseHtml = settings?.receipt_custom_clause ? `<div style="background:#fffbeb;border:1px solid #fef3c7;border-radius:8px;padding:12px 16px;margin:16px 0;font-size:11px;color:#64748b;font-style:italic;">${settings.receipt_custom_clause}</div>` : "";
    const refHtml = (settings?.receipt_show_reference !== false) && payment.reference ? `<p style="font-size:11px;color:#64748b;margin-top:8px;">Référence : <strong>${payment.reference}</strong></p>` : "";
    const footerText = settings?.receipt_footer_text || `Le bailleur certifie avoir reçu la somme de ${formatXAF(payment.amount)} XAF en règlement du loyer du bien susmentionné.`;

    const html = `<html><head><title>Quittance de loyer</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 40px; color: #1e293b; font-size: 13px; margin: 0; }
      .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; border-bottom: 2px solid #0f2b4c; padding-bottom: 16px; }
      .company-name { font-size: 20px; font-weight: bold; color: #0f2b4c; }
      .subtitle { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 2px; }
      .ref-block { text-align: right; font-size: 11px; color: #64748b; }
      .title-block { text-align: center; margin: 20px 0; }
      .title-block h1 { font-size: 18px; font-weight: bold; text-transform: uppercase; color: #0f2b4c; border: 2px solid #0f2b4c; padding: 8px 24px; display: inline-block; letter-spacing: 1px; }
      .period { font-size: 13px; color: #475569; margin-top: 8px; }
      .parties { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
      .party { background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; border-radius: 8px; }
      .party-label { font-size: 10px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
      .party-name { font-size: 14px; font-weight: 700; }
      .party-detail { font-size: 11px; color: #475569; margin-top: 2px; }
      .amount-block { background: #0f2b4c; color: white; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0; }
      .amount-value { font-size: 30px; font-weight: bold; letter-spacing: 1px; }
      .amount-label { font-size: 11px; opacity: 0.75; margin-top: 4px; }
      .details { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin: 16px 0; }
      .detail-box { background: #f8fafc; padding: 10px; border-radius: 8px; text-align: center; }
      .detail-label { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
      .detail-value { font-size: 12px; font-weight: 600; margin-top: 4px; }
      .footer-section { margin-top: 32px; border-top: 1px solid #e2e8f0; padding-top: 20px; display: flex; justify-content: space-between; align-items: flex-end; }
      .footer-text { font-size: 10px; color: #64748b; max-width: 55%; line-height: 1.6; }
      .signature { text-align: center; }
      .sig-line { border-top: 1px solid #1e293b; padding-top: 4px; font-size: 11px; color: #374151; width: 180px; margin: 0 auto; }
      .legal { font-size: 9px; color: #94a3b8; text-align: center; margin-top: 20px; }
      @media print { body { padding: 24px; } }
    </style></head><body>
    <div class="header">
      <div>${logoHtml}<div class="company-name">${companyName}</div><div class="subtitle">Gestion locative</div>${settings?.owner_address ? `<div style="font-size:11px;color:#64748b;margin-top:4px;">${settings.owner_address}</div>` : ""}${settings?.owner_phone ? `<div style="font-size:11px;color:#64748b;">${settings.owner_phone}</div>` : ""}</div>
      <div class="ref-block"><div>N° QTT-${payment.id?.slice(-6).toUpperCase() || ""}</div><div style="margin-top:4px;">Émise le ${new Date().toLocaleDateString("fr-FR")}</div></div>
    </div>
    <div class="title-block"><h1>Quittance de Loyer</h1><p class="period">Pour le mois de <strong>${month} ${payment.period_year}</strong></p></div>
    <div class="parties">
      <div class="party"><div class="party-label">Bailleur</div><div class="party-name">${ownerName}</div>${settings?.owner_address ? `<div class="party-detail">${settings.owner_address}</div>` : ""}${settings?.owner_email ? `<div class="party-detail">${settings.owner_email}</div>` : ""}</div>
      <div class="party"><div class="party-label">Locataire</div><div class="party-name">${payment.tenant_name}</div><div class="party-detail">${payment.property_name}</div></div>
    </div>
    <div class="amount-block"><div class="amount-value">${formatXAF(payment.amount)} XAF</div><div class="amount-label">Montant reçu en paiement du loyer</div></div>
    <div class="details">
      <div class="detail-box"><div class="detail-label">Bien loué</div><div class="detail-value">${payment.property_name}</div></div>
      <div class="detail-box"><div class="detail-label">Période</div><div class="detail-value">${month} ${payment.period_year}</div></div>
      <div class="detail-box"><div class="detail-label">Mode de paiement</div><div class="detail-value">${methodLabels[payment.payment_method] || payment.payment_method || "—"}</div></div>
    </div>
    ${refHtml}
    ${clauseHtml}
    <div class="footer-section">
      <div class="footer-text">${footerText}</div>
      <div class="signature">${sigHtml}<div class="sig-line">${ownerName}</div></div>
    </div>
    <div class="legal">Document généré par ${companyName} • Quittance valable comme reçu de paiement</div>
    </body></html>`;

    const win = window.open("", "_blank");
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 500);
  };

  const month = MONTHS_FR[(payment.period_month || 1) - 1];
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const ownerName = settings?.owner_name || "Le Propriétaire";

  return (
    <Dialog open={!!payment} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Quittance de loyer</span>
          </DialogTitle>
        </DialogHeader>

        {/* Preview */}
        <div ref={printRef} className="bg-white p-6 border rounded-lg text-sm">
          {/* Header */}
          <div className="header flex justify-between items-start border-b-2 border-[#0f2b4c] pb-4 mb-6">
            <div>
              {settings?.logo_url && <img src={settings.logo_url} alt="Logo" className="h-12 object-contain mb-2" />}
              <div className="text-xl font-bold text-[#0f2b4c]">{companyName}</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-widest">Gestion locative</div>
              {settings?.owner_address && <div className="text-xs text-slate-600 mt-1">{settings.owner_address}</div>}
              {settings?.owner_phone && <div className="text-xs text-slate-600">{settings.owner_phone}</div>}
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-500">N° de quittance</div>
              <div className="font-mono font-bold text-[#0f2b4c]">QTT-{payment.id?.slice(-6).toUpperCase()}</div>
              <div className="text-xs text-slate-500 mt-1">Émise le</div>
              <div className="text-xs font-medium">{new Date().toLocaleDateString("fr-FR")}</div>
            </div>
          </div>

          {/* Title */}
          <div className="title-block text-center my-5">
            <h1 className="inline-block border-2 border-[#0f2b4c] text-[#0f2b4c] font-bold text-lg uppercase px-6 py-2">
              Quittance de Loyer
            </h1>
            <p className="text-slate-600 mt-2 text-sm">Pour le mois de <strong>{month} {payment.period_year}</strong></p>
          </div>

          {/* Grid bailleur / locataire */}
          <div className="grid grid-cols-2 gap-4 my-5">
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg">
              <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-2">Bailleur</div>
              <div className="font-semibold">{ownerName}</div>
              {settings?.owner_address && <div className="text-xs text-slate-600 mt-1">{settings.owner_address}</div>}
              {settings?.owner_email && <div className="text-xs text-slate-600">{settings.owner_email}</div>}
            </div>
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg">
              <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-2">Locataire</div>
              <div className="font-semibold">{payment.tenant_name}</div>
              <div className="text-xs text-slate-600 mt-1">{payment.property_name}</div>
            </div>
          </div>

          {/* Amount */}
          <div className="bg-[#0f2b4c] text-white p-5 rounded-lg text-center my-5">
            <div className="text-2xl font-bold">{formatXAF(payment.amount)} XAF</div>
            <div className="text-xs text-blue-200 mt-1">Montant reçu en paiement du loyer</div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-3 gap-3 my-4">
            <div className="bg-slate-50 p-3 rounded-lg text-center">
              <div className="text-[10px] text-slate-500 uppercase">Bien loué</div>
              <div className="font-medium text-xs mt-1">{payment.property_name}</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg text-center">
              <div className="text-[10px] text-slate-500 uppercase">Période</div>
              <div className="font-medium text-xs mt-1">{month} {payment.period_year}</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg text-center">
              <div className="text-[10px] text-slate-500 uppercase">Mode de paiement</div>
              <div className="font-medium text-xs mt-1">{methodLabels[payment.payment_method] || payment.payment_method || "—"}</div>
            </div>
          </div>

          {(settings?.receipt_show_reference !== false) && payment.reference && (
            <div className="text-xs text-slate-500 mt-2">Référence : <span className="font-medium">{payment.reference}</span></div>
          )}

          {settings?.receipt_custom_clause && (
            <div className="bg-amber-50 border border-amber-100 rounded-lg px-4 py-2 mt-3 text-xs text-slate-600 italic">
              {settings.receipt_custom_clause}
            </div>
          )}

          {/* Footer */}
          <div className="border-t border-slate-200 pt-5 mt-6 flex justify-between items-end">
            <div className="text-xs text-slate-500 max-w-xs">
              {settings?.receipt_footer_text || `Le bailleur certifie avoir reçu la somme de ${formatXAF(payment.amount)} XAF en règlement du loyer du bien susmentionné.`}
            </div>
            <div className="text-center">
              {settings?.signature_url ? (
                <img src={settings.signature_url} alt="Signature" className="h-16 object-contain mb-1 mx-auto" />
              ) : (
                <div style={{ height: 48 }} />
              )}
              <div className="border-t border-slate-800 pt-1 text-xs text-slate-600 w-40">{ownerName}</div>
            </div>
          </div>

          <div className="text-center text-[9px] text-slate-400 mt-4">
            Document généré par {companyName} • Quittance valable comme reçu de paiement
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 flex-wrap">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
          <Button
            onClick={handleSave}
            disabled={saving || saved || !!payment.receipt_url}
            variant="outline"
            className="gap-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50 disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saved || payment.receipt_url ? "Quittance enregistrée ✓" : "Enregistrer la quittance"}
          </Button>
          <Button
            variant="outline"
            className="gap-2 border-green-400 text-green-700 hover:bg-green-50"
            onClick={() => {
              const month = MONTHS_FR[(payment.period_month || 1) - 1];
              const companyName = settings?.company_name || "Zenden ImmoLoc";
              const msg = `Bonjour,\n\nVeuillez trouver ci-jointe votre quittance de loyer pour le mois de ${month} ${payment.period_year}.\n\nMontant : ${formatXAF(payment.amount)} XAF\nBien : ${payment.property_name}\n\nCordialement,\n${companyName}`;
              const waUrl = `https://wa.me/?text=${encodeURIComponent(msg)}`;
              window.open(waUrl, "_blank");
            }}
          >
            <MessageCircle className="w-4 h-4" /> WhatsApp
          </Button>
          <Button onClick={handlePrint} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">
            <Printer className="w-4 h-4" /> Imprimer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}