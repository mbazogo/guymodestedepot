import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, ClipboardList } from "lucide-react";

const CONDITION_LABELS = { bon: "Bon état", moyen: "État moyen", mauvais: "Mauvais état", na: "N/A" };
const CONDITION_COLORS = { bon: "#16a34a", moyen: "#d97706", mauvais: "#dc2626", na: "#94a3b8" };
const TYPE_LABELS = { entree: "ENTRÉE", sortie: "SORTIE" };
const HOUSING_LABELS = { appartement: "Appartement", studio: "Studio", maison: "Maison", villa: "Villa", local_commercial: "Local commercial", autre: "Autre" };

function generateEDLHtml(report, tenant, property, settings) {
  const ownerName = settings?.owner_name || settings?.company_name || "Le Bailleur";
  const logo = settings?.logo_url ? `<img src="${settings.logo_url}" style="height:48px;object-fit:contain;" />` : "";
  const sig = settings?.signature_url ? `<img src="${settings.signature_url}" style="height:44px;object-fit:contain;display:block;margin:4px auto 0;" />` : "";
  const date = report.date ? new Date(report.date).toLocaleDateString("fr-FR") : "—";
  const rooms = Array.isArray(report.rooms) ? report.rooms : [];

  return `
  <div style="font-family:Arial,sans-serif;font-size:11pt;color:#1a1a1a;max-width:760px;margin:auto;padding:36px;">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0f2b4c;padding-bottom:14px;margin-bottom:20px;">
      <div>${logo}<div style="font-size:16pt;font-weight:bold;color:#0f2b4c;margin-top:4px;">${settings?.company_name || "Zenden ImmoLoc"}</div></div>
      <div style="text-align:center;">
        <div style="font-size:15pt;font-weight:bold;text-transform:uppercase;border:2px solid #0f2b4c;padding:6px 20px;color:#0f2b4c;">ÉTAT DES LIEUX ${TYPE_LABELS[report.type] || ""}</div>
        <div style="font-size:9pt;color:#64748b;margin-top:4px;">Le ${date}</div>
      </div>
    </div>

    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr>
        <td style="width:50%;padding:10px;background:#f8fafc;border:1px solid #e2e8f0;vertical-align:top;">
          <div style="font-size:9pt;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Bailleur</div>
          <div style="font-weight:bold;">${ownerName}</div>
          ${settings?.owner_address ? `<div style="font-size:10pt;">${settings.owner_address}</div>` : ""}
          ${settings?.owner_phone ? `<div style="font-size:10pt;">${settings.owner_phone}</div>` : ""}
        </td>
        <td style="width:50%;padding:10px;background:#f8fafc;border:1px solid #e2e8f0;vertical-align:top;">
          <div style="font-size:9pt;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Locataire</div>
          <div style="font-weight:bold;">${tenant?.civility ? tenant.civility + " " : ""}${tenant?.first_name || ""} ${tenant?.last_name || ""}</div>
          ${tenant?.phone ? `<div style="font-size:10pt;">${tenant.phone}</div>` : ""}
          ${tenant?.id_number ? `<div style="font-size:10pt;">CNI/Passeport : ${tenant.id_number}</div>` : ""}
        </td>
      </tr>
    </table>

    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr>
        <td colspan="3" style="background:#0f2b4c;color:white;padding:8px 12px;font-size:10pt;font-weight:bold;">BIEN LOUÉ</td>
      </tr>
      <tr>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;"><strong>${property?.name || "—"}</strong></td>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;">${property?.address || ""}${property?.city ? ", " + property.city : ""}</td>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;">${HOUSING_LABELS[report.housing_type] || "—"} ${property?.surface ? "— " + property.surface + " m²" : ""}</td>
      </tr>
      <tr>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;">Compteur eau : <strong>${report.meter_water || "—"}</strong></td>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;">Compteur élec : <strong>${report.meter_electricity || "—"}</strong></td>
        <td style="padding:8px 12px;border:1px solid #e2e8f0;">Clés remises : <strong>${report.keys_count || 1}</strong></td>
      </tr>
    </table>

    ${rooms.length > 0 ? `
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr style="background:#0f2b4c;color:white;">
        <td style="padding:8px 12px;font-weight:bold;width:35%;">Pièce</td>
        <td style="padding:8px 12px;font-weight:bold;width:20%;">État</td>
        <td style="padding:8px 12px;font-weight:bold;">Observations</td>
      </tr>
      ${rooms.map((r, i) => `
      <tr style="background:${i % 2 === 0 ? "#f8fafc" : "white"};">
        <td style="padding:7px 12px;border:1px solid #e2e8f0;">${r.name || "—"}</td>
        <td style="padding:7px 12px;border:1px solid #e2e8f0;color:${CONDITION_COLORS[r.condition] || "#333"};font-weight:bold;">${CONDITION_LABELS[r.condition] || "—"}</td>
        <td style="padding:7px 12px;border:1px solid #e2e8f0;">${r.notes || ""}</td>
      </tr>`).join("")}
    </table>` : ""}

    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr>
        <td style="padding:10px 12px;border:1px solid #e2e8f0;"><strong>État général :</strong> <span style="color:${CONDITION_COLORS[report.general_condition] || "#333"};font-weight:bold;">${CONDITION_LABELS[report.general_condition] || "—"}</span></td>
      </tr>
      ${report.observations ? `<tr><td style="padding:10px 12px;border:1px solid #e2e8f0;"><strong>Observations :</strong><br/>${report.observations.replace(/\n/g, "<br/>")}</td></tr>` : ""}
    </table>

    ${report.type === "sortie" && (report.deposit_deduction > 0 || report.deposit_returned > 0) ? `
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr style="background:#0f2b4c;color:white;">
        <td colspan="2" style="padding:8px 12px;font-weight:bold;">RÉGULARISATION DU DÉPÔT DE GARANTIE</td>
      </tr>
      ${report.deposit_deduction > 0 ? `<tr><td style="padding:7px 12px;border:1px solid #e2e8f0;">Retenue pour dégradations :</td><td style="padding:7px 12px;border:1px solid #e2e8f0;color:#dc2626;font-weight:bold;">${new Intl.NumberFormat("fr-FR").format(report.deposit_deduction)} XAF</td></tr>` : ""}
      ${report.deduction_reason ? `<tr><td colspan="2" style="padding:7px 12px;border:1px solid #e2e8f0;font-style:italic;">Motif : ${report.deduction_reason}</td></tr>` : ""}
      ${report.deposit_returned > 0 ? `<tr><td style="padding:7px 12px;border:1px solid #e2e8f0;font-weight:bold;">Dépôt restitué :</td><td style="padding:7px 12px;border:1px solid #e2e8f0;color:#16a34a;font-weight:bold;">${new Intl.NumberFormat("fr-FR").format(report.deposit_returned)} XAF</td></tr>` : ""}
    </table>` : ""}

    <div style="margin-top:40px;display:flex;justify-content:space-between;gap:40px;">
      <div style="flex:1;text-align:center;">
        <p style="font-weight:bold;margin-bottom:50px;">Le Bailleur</p>
        ${sig}
        <p style="border-top:1px solid #333;padding-top:5px;font-size:10pt;">${ownerName}</p>
      </div>
      <div style="flex:1;text-align:center;">
        <p style="font-weight:bold;margin-bottom:50px;">Le Locataire</p>
        <p style="border-top:1px solid #333;padding-top:5px;font-size:10pt;">${tenant?.first_name || ""} ${tenant?.last_name || ""}</p>
      </div>
    </div>
    <p style="text-align:center;color:#94a3b8;font-size:9pt;margin-top:20px;">Document généré par ${settings?.company_name || "Zenden ImmoLoc"} — Fait à Libreville, le ${date} — En deux (2) exemplaires</p>
  </div>`;
}

export default function InventoryPrintModal({ report, tenant, property, settings, onClose }) {
  if (!report) return null;
  const html = generateEDLHtml(report, tenant, property, settings);

  const handlePrint = () => {
    const w = window.open("", "_blank");
    w.document.write(`<html><head><title>État des lieux</title><style>@media print{body{margin:0}}</style></head><body>${html}</body></html>`);
    w.document.close();
    w.print();
  };

  return (
    <Dialog open={!!report} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-[#0f2b4c]" />
            État des lieux — {report.type === "entree" ? "Entrée" : "Sortie"} — {report.tenant_name}
          </DialogTitle>
        </DialogHeader>
        <div className="border rounded-xl bg-white overflow-auto max-h-[60vh]">
          <div dangerouslySetInnerHTML={{ __html: html }} />
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
          <Button onClick={handlePrint} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">
            <Printer className="w-4 h-4" /> Imprimer / PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}