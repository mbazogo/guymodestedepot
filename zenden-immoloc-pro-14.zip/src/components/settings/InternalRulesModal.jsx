import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, ScrollText } from "lucide-react";

function generateRulesHTML(settings) {
  const ownerName = settings?.owner_name || "Le Bailleur";
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const today = new Date().toLocaleDateString("fr-FR");
  const logoHtml = settings?.logo_url ? `<img src="${settings.logo_url}" alt="Logo" style="height:50px;object-fit:contain;margin-bottom:8px;display:block;" /><br/>` : "";
  const signatureHtml = settings?.signature_url ? `<img src="${settings.signature_url}" alt="Signature" style="height:50px;object-fit:contain;display:block;margin:8px auto 0;" />` : "";

  return `
  <div style="font-family: 'Times New Roman', Times, serif; font-size: 11pt; line-height: 1.8; color: #1a1a1a; max-width: 760px; margin: auto; padding: 40px;">
    <div style="text-align:center; margin-bottom: 30px;">
      ${logoHtml}
      <h1 style="font-size:18pt; font-weight:bold; text-transform:uppercase; letter-spacing:2px; margin-bottom:6px;">Règlement Intérieur</h1>
      <p style="color:#555; font-size:10pt;">${companyName} — ${today}</p>
      <hr style="border:1px solid #333; margin-top:10px;"/>
    </div>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Préambule</h2>
    <p>Le présent règlement intérieur a pour but de garantir la bonne entente entre les locataires, le respect du voisinage, ainsi qu'un cadre de vie agréable et sécurisé pour tous. Il complète les dispositions du contrat de bail et doit être respecté par tous les occupants, y compris les enfants.</p>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 1 – Respect du voisinage et du vivre ensemble</h2>
    <p>Tout locataire s'engage à adopter un comportement respectueux envers ses voisins.</p>
    <p>Les nuisances sonores sont interdites à toute heure. Une tolérance de jeux calmes est autorisée aux enfants entre 16h00 et 18h00, dans le respect du silence.</p>
    <p>Les comportements inappropriés, tels qu'uriner depuis les balcons ou lancer des objets par les fenêtres, sont strictement interdits. Ces actes sont considérés comme graves et peuvent entraîner la résiliation du bail.</p>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 2 – Propreté et entretien des parties communes</h2>
    <ul style="margin-left:20px;">
      <li>Les mégots de cigarette, déchets et objets divers ne doivent en aucun cas être jetés au sol ni dans les espaces communs.</li>
      <li>Les locataires doivent veiller à maintenir propres leurs balcons, rebords de fenêtres et couloirs d'accès.</li>
      <li>Les sacs-poubelle doivent être déposés dans les conteneurs prévus à cet effet. Aucun dépôt sauvage ne sera toléré.</li>
      <li>Il est interdit de secouer des tapis ou linges par les fenêtres ou les balcons.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 3 – Respect de la vie privée</h2>
    <ul style="margin-left:20px;">
      <li>Il est strictement interdit d'espionner, de photographier ou de filmer ses voisins sans leur consentement.</li>
      <li>Les conversations et comportements dans les parties communes doivent rester discrets et respectueux.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 4 – Usage des espaces communs et balcons</h2>
    <ul style="margin-left:20px;">
      <li>Les balcons ne doivent pas être utilisés comme débarras ou lieu de jeux dangereux.</li>
      <li>Il est interdit d'y fumer si cela engendre des nuisances pour les voisins.</li>
      <li>Les installations personnelles (barbecue, antennes, gros mobiliers, etc.) doivent faire l'objet d'un accord préalable du bailleur.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 5 – Paiement du loyer</h2>
    <ul style="margin-left:20px;">
      <li>Le loyer est exigible au plus tard le 5 de chaque mois. Tout retard non justifié pourra entraîner des pénalités ou des procédures légales.</li>
      <li>En cas de difficulté temporaire, le locataire doit prévenir immédiatement le bailleur afin de convenir d'un arrangement éventuel.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 6 – Entretien du logement</h2>
    <ul style="margin-left:20px;">
      <li>Chaque locataire est responsable de l'entretien courant de son logement.</li>
      <li>Les dégradations constatées doivent être réparées par le locataire ou signalées sans délai au bailleur.</li>
      <li>Aucune modification importante ne peut être apportée au logement sans l'accord écrit du bailleur.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 7 – Animaux de compagnie</h2>
    <ul style="margin-left:20px;">
      <li>La présence d'animaux de compagnie est tolérée, à condition qu'ils ne causent aucune gêne au voisinage (bruits, odeurs, salissures, agressivité).</li>
      <li>Les chiens doivent être tenus en laisse dans les parties communes.</li>
      <li>Les propriétaires d'animaux doivent veiller à ramasser immédiatement les déjections de leurs animaux.</li>
      <li>Les animaux dangereux ou de catégorie 1 ou 2 sont interdits sauf preuve d'assurance spécifique.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 8 – Sanctions</h2>
    <p>Tout manquement grave ou répété au présent règlement pourra faire l'objet :</p>
    <ul style="margin-left:20px;">
      <li>D'un avertissement écrit ;</li>
      <li>D'un constat d'huissier (à la charge du locataire en infraction) ;</li>
      <li>En cas de récidive ou de nuisance grave, d'une résiliation du bail pour manquement aux obligations contractuelles.</li>
    </ul>

    <h2 style="font-size:12pt; font-weight:bold; margin-top:20px; border-bottom:1px solid #ccc; padding-bottom:4px;">Article 9 – Acceptation</h2>
    <p>Ce règlement intérieur est remis à chaque locataire à l'entrée dans les lieux. Il est annexé au contrat de bail et a valeur contractuelle.</p>

    <div style="margin-top: 50px; display: flex; justify-content: space-between; gap: 40px;">
      <div style="flex:1; text-align:center;">
        <p style="font-weight:bold; margin-bottom:60px;">Le Bailleur</p>
        ${signatureHtml}
        <p style="border-top:1px solid #333; padding-top:6px; font-size:10pt;">${ownerName}</p>
      </div>
      <div style="flex:1; text-align:center;">
        <p style="font-weight:bold; margin-bottom:60px;">Le Locataire</p>
        <p style="border-top:1px solid #333; padding-top:6px; font-size:10pt;">Signature précédée de la mention "Lu et approuvé"</p>
      </div>
    </div>

    <p style="text-align:center; color:#888; font-size:9pt; margin-top:30px;">Fait à Libreville, le ${today}</p>
  </div>
  `;
}

export default function InternalRulesModal({ settings, open, onClose }) {
  const html = generateRulesHTML(settings);

  const handlePrint = () => {
    const w = window.open("", "_blank");
    w.document.write(`<html><head><title>Règlement Intérieur</title><style>@media print{body{margin:0}}</style></head><body>${html}</body></html>`);
    w.document.close();
    w.print();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-[#0f2b4c]" />
            Règlement Intérieur
          </DialogTitle>
        </DialogHeader>
        <div className="border rounded-xl bg-white overflow-auto max-h-[60vh]">
          <div dangerouslySetInnerHTML={{ __html: html }} />
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
          <Button onClick={handlePrint} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">
            <Printer className="w-4 h-4" /> Imprimer / PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}