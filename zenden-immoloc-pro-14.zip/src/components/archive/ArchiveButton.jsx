import React from "react";
import { Button } from "@/components/ui/button";
import { Archive, ArchiveRestore } from "lucide-react";

export default function ArchiveButton({ item, entityName, onArchive, size = "icon" }) {
  const isArchived = item.archived;

  const handleClick = () => {
    const action = isArchived ? "désarchiver" : "archiver";
    if (confirm(`Voulez-vous ${action} cet élément ?`)) {
      onArchive(item.id, !isArchived);
    }
  };

  if (size === "icon") {
    return (
      <Button
        size="icon"
        variant="ghost"
        onClick={handleClick}
        title={isArchived ? "Désarchiver" : "Archiver"}
      >
        {isArchived
          ? <ArchiveRestore className="w-4 h-4 text-emerald-500" />
          : <Archive className="w-4 h-4 text-slate-400 hover:text-amber-500" />
        }
      </Button>
    );
  }

  return (
    <Button
      size="sm"
      variant="outline"
      onClick={handleClick}
      className={isArchived ? "text-emerald-600 border-emerald-200" : "text-amber-600 border-amber-200"}
    >
      {isArchived ? <ArchiveRestore className="w-3.5 h-3.5 mr-1" /> : <Archive className="w-3.5 h-3.5 mr-1" />}
      {isArchived ? "Désarchiver" : "Archiver"}
    </Button>
  );
}