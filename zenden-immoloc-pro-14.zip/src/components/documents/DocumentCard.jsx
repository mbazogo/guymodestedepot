import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, FileImage, FileSpreadsheet, Eye, Download, Trash2, Tag, User, Building2 } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const TYPE_LABELS = {
  bail: "Bail", quittance: "Quittance", avis_echeance: "Avis d'échéance",
  courrier: "Courrier", attestation: "Attestation", relance: "Relance", autre: "Autre"
};
const TYPE_COLORS = {
  bail: "bg-violet-100 text-violet-700",
  quittance: "bg-emerald-100 text-emerald-700",
  avis_echeance: "bg-amber-100 text-amber-700",
  courrier: "bg-blue-100 text-blue-700",
  attestation: "bg-teal-100 text-teal-700",
  relance: "bg-red-100 text-red-700",
  autre: "bg-slate-100 text-slate-600",
};
const STATUS_COLORS = {
  draft: "bg-slate-100 text-slate-600",
  sent: "bg-blue-100 text-blue-700",
  signed: "bg-emerald-100 text-emerald-700",
};
const STATUS_LABELS = { draft: "Brouillon", sent: "Envoyé", signed: "Signé" };

function getFileIcon(url) {
  if (!url) return FileText;
  const ext = url.split("?")[0].split(".").pop()?.toLowerCase();
  if (["png", "jpg", "jpeg", "gif", "webp"].includes(ext)) return FileImage;
  if (["xls", "xlsx", "csv"].includes(ext)) return FileSpreadsheet;
  return FileText;
}

function getFileIconColor(url) {
  if (!url) return "text-slate-400";
  const ext = url.split("?")[0].split(".").pop()?.toLowerCase();
  if (ext === "pdf") return "text-red-500";
  if (["png", "jpg", "jpeg", "gif", "webp"].includes(ext)) return "text-green-500";
  if (["xls", "xlsx", "csv"].includes(ext)) return "text-emerald-600";
  return "text-indigo-500";
}

export default function DocumentCard({ doc, onPreview, onDelete }) {
  const Icon = getFileIcon(doc.file_url);
  const iconColor = getFileIconColor(doc.file_url);

  return (
    <div className="bg-white rounded-xl border border-slate-100 hover:shadow-md hover:border-slate-200 transition-all duration-200 p-4 flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center shrink-0 border border-slate-100`}>
          <Icon className={`w-5 h-5 ${iconColor}`} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-slate-800 truncate leading-tight">{doc.name}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">
            {doc.created_date ? format(new Date(doc.created_date), "d MMM yyyy", { locale: fr }) : "—"}
          </p>
        </div>
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-1.5">
        <Badge className={`${TYPE_COLORS[doc.type] || TYPE_COLORS.autre} text-[10px]`}>{TYPE_LABELS[doc.type] || doc.type}</Badge>
        <Badge className={`${STATUS_COLORS[doc.status]} text-[10px]`}>{STATUS_LABELS[doc.status]}</Badge>
      </div>

      {/* Associations */}
      {(doc.tenant_name || doc.property_name) && (
        <div className="space-y-1">
          {doc.tenant_name && (
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
              <User className="w-3 h-3 shrink-0" /> {doc.tenant_name}
            </div>
          )}
          {doc.property_name && (
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
              <Building2 className="w-3 h-3 shrink-0" /> {doc.property_name}
            </div>
          )}
        </div>
      )}

      {/* Tags */}
      {doc.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {doc.tags.slice(0, 3).map(t => (
            <span key={t} className="text-[9px] bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
              <Tag className="w-2.5 h-2.5" /> {t}
            </span>
          ))}
          {doc.tags.length > 3 && <span className="text-[9px] text-slate-400">+{doc.tags.length - 3}</span>}
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2 pt-1 border-t border-slate-50">
        <Button size="sm" variant="outline" onClick={() => onPreview(doc)} className="flex-1 gap-1 text-xs h-7">
          <Eye className="w-3.5 h-3.5" /> Voir
        </Button>
        {doc.file_url && (
          <a href={doc.file_url} download className="flex-1">
            <Button size="sm" variant="outline" className="w-full gap-1 text-xs h-7">
              <Download className="w-3.5 h-3.5" /> Télécharger
            </Button>
          </a>
        )}
        <Button size="sm" variant="ghost" onClick={() => onDelete(doc)} className="h-7 w-7 p-0 text-red-400 hover:text-red-600 hover:bg-red-50">
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}