import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { History, Eye, GitBranch } from "lucide-react";

const statusColors = { draft: "bg-slate-100 text-slate-600", sent: "bg-blue-100 text-blue-700", signed: "bg-emerald-100 text-emerald-700" };
const statusLabels = { draft: "Brouillon", sent: "Envoyé", signed: "Signé" };

export default function DocumentVersionHistory({ open, onClose, document, allDocuments, onViewVersion }) {
  if (!document) return null;

  // Get all versions: the root doc + any doc with parent_id pointing to the root
  const rootId = document.parent_id || document.id;
  const versions = allDocuments
    .filter(d => d.id === rootId || d.parent_id === rootId)
    .sort((a, b) => (b.version || 1) - (a.version || 1));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-500" />
            Historique des versions — {versions[0]?.name || document.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {versions.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">Aucune version trouvée</p>
          ) : (
            versions.map((v) => (
              <div key={v.id} className={`flex items-center justify-between p-3 rounded-lg border ${v.is_latest_version ? "border-indigo-200 bg-indigo-50" : "border-slate-100 bg-white"}`}>
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${v.is_latest_version ? "bg-indigo-500 text-white" : "bg-slate-200 text-slate-600"}`}>
                    v{v.version || 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-800">{v.version_label || `Version ${v.version || 1}`}</span>
                      {v.is_latest_version && <Badge className="bg-indigo-100 text-indigo-700 text-[10px]">Actuelle</Badge>}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge className={`${statusColors[v.status]} text-[10px]`}>{statusLabels[v.status]}</Badge>
                      <span className="text-[10px] text-slate-400">
                        {v.created_date ? new Date(v.created_date).toLocaleDateString("fr-FR") : "—"}
                      </span>
                    </div>
                  </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => onViewVersion(v)}>
                  <Eye className="w-4 h-4" />
                </Button>
              </div>
            ))
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Fermer</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}