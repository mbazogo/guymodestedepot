import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Loader2, FileText, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import DocumentTagsInput from "./DocumentTagsInput";

const DOC_TYPES = [
  { value: "bail", label: "Bail / Contrat" },
  { value: "quittance", label: "Quittance de loyer" },
  { value: "avis_echeance", label: "Avis d'échéance" },
  { value: "courrier", label: "Courrier" },
  { value: "attestation", label: "Attestation" },
  { value: "relance", label: "Lettre de relance" },
  { value: "autre", label: "Autre" },
];

const DOC_CATEGORIES = [
  { value: "administratif", label: "Administratif" },
  { value: "financier", label: "Financier" },
  { value: "juridique", label: "Juridique" },
  { value: "communication", label: "Communication" },
  { value: "autre", label: "Autre" },
];

export default function DocumentUploadModal({ open, onClose, onSave, tenants, properties, defaultTenantId, defaultPropertyId }) {
  const initialForm = () => ({
    name: "",
    type: "autre",
    category: "administratif",
    tenant_id: defaultTenantId || "none",
    property_id: defaultPropertyId || "none",
    status: "draft",
    tags: [],
  });

  const [form, setForm] = useState(initialForm());
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // Réinitialiser le formulaire à chaque ouverture de la modale
  useEffect(() => {
    if (open) {
      setForm(initialForm());
      setFile(null);
    }
  }, [open]);

  // Liaison automatique : sélectionner un locataire pré-remplit le bien associé
  const handleTenantChange = (tenantId) => {
    if (tenantId === "none") {
      setForm(p => ({ ...p, tenant_id: "none" }));
      return;
    }
    const tenant = tenants.find(t => t.id === tenantId);
    const autoPropertyId = tenant?.property_id
      ? (properties.find(p => p.id === tenant.property_id) ? tenant.property_id : "none")
      : "none";
    setForm(p => ({ ...p, tenant_id: tenantId, property_id: autoPropertyId }));
  };

  // Liaison automatique : sélectionner un bien propose les locataires associés
  const handlePropertyChange = (propertyId) => {
    setForm(p => ({ ...p, property_id: propertyId }));
    // Si aucun locataire n'est sélectionné, tenter de pré-remplir avec le locataire du bien
    if (form.tenant_id === "none" && propertyId !== "none") {
      const linkedTenant = tenants.find(t => t.property_id === propertyId && t.status === "active");
      if (linkedTenant) {
        setForm(p => ({ ...p, property_id: propertyId, tenant_id: linkedTenant.id }));
      }
    }
  };

  const handleFile = (f) => {
    if (!f) return;
    setFile(f);
    if (!form.name) setForm(p => ({ ...p, name: f.name.replace(/\.[^.]+$/, "") }));
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const handleSubmit = async () => {
    if (!form.name || !file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const resolvedTenantId = form.tenant_id === "none" ? "" : form.tenant_id;
      const resolvedPropertyId = form.property_id === "none" ? "" : form.property_id;
      const tenant = resolvedTenantId ? tenants.find(t => t.id === resolvedTenantId) : null;
      const property = resolvedPropertyId ? properties.find(p => p.id === resolvedPropertyId) : null;
      const docData = {
        ...form,
        tenant_id: resolvedTenantId,
        property_id: resolvedPropertyId,
        file_url,
        tenant_name: tenant ? `${tenant.first_name} ${tenant.last_name}` : "",
        property_name: property?.name || "",
        version: 1,
        is_latest_version: true,
      };
      await onSave(docData);
      setForm({ name: "", type: "autre", category: "administratif", tenant_id: defaultTenantId || "none", property_id: defaultPropertyId || "none", status: "draft", tags: [] });
      setFile(null);
      onClose();
    } finally {
      setUploading(false);
    }
  };

  // Locataires filtrés selon le bien sélectionné (si un bien est choisi)
  const filteredTenants = form.property_id !== "none"
    ? tenants.filter(t => t.property_id === form.property_id || t.id === form.tenant_id)
    : tenants;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-indigo-500" /> Ajouter un document
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Drop zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => document.getElementById("ged-file-input").click()}
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${dragOver ? "border-indigo-400 bg-indigo-50" : "border-slate-200 hover:border-indigo-300 hover:bg-slate-50"}`}
          >
            <input id="ged-file-input" type="file" className="hidden" onChange={e => handleFile(e.target.files[0])} />
            {file ? (
              <div className="flex items-center justify-center gap-3">
                <FileText className="w-8 h-8 text-indigo-500" />
                <div className="text-left">
                  <p className="text-sm font-medium text-slate-800">{file.name}</p>
                  <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(1)} Ko</p>
                </div>
                <button onClick={(e) => { e.stopPropagation(); setFile(null); }} className="ml-2 text-slate-400 hover:text-red-500">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div>
                <Upload className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Glissez un fichier ici ou <span className="text-indigo-600 font-medium">cliquez pour parcourir</span></p>
                <p className="text-xs text-slate-400 mt-1">PDF, Word, Images — Max 20 Mo</p>
              </div>
            )}
          </div>

          {/* Liaison rapide */}
          <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3 space-y-2">
            <p className="text-xs font-semibold text-indigo-700 uppercase tracking-wide">Rattacher à</p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label className="text-xs text-slate-600">Locataire</Label>
                <Select value={form.tenant_id} onValueChange={handleTenantChange}>
                  <SelectTrigger className="bg-white"><SelectValue placeholder="— Aucun —" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— Aucun —</SelectItem>
                    {tenants.map(t => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-slate-600">Bien immobilier</Label>
                <Select value={form.property_id} onValueChange={handlePropertyChange}>
                  <SelectTrigger className="bg-white"><SelectValue placeholder="— Aucun —" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— Aucun —</SelectItem>
                    {properties.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {(form.tenant_id !== "none" || form.property_id !== "none") && (
              <p className="text-[10px] text-indigo-500">
                ✓ Document rattaché automatiquement
                {form.tenant_id !== "none" && ` au locataire`}
                {form.tenant_id !== "none" && form.property_id !== "none" && ` et`}
                {form.property_id !== "none" && ` au bien`}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label>Nom du document *</Label>
              <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Ex: Contrat de bail — M. Dupont" />
            </div>
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={v => setForm(p => ({ ...p, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DOC_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Catégorie</Label>
              <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DOC_CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Statut</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Brouillon</SelectItem>
                  <SelectItem value="sent">Envoyé</SelectItem>
                  <SelectItem value="signed">Signé</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Tags</Label>
            <div className="mt-1">
              <DocumentTagsInput tags={form.tags} onChange={tags => setForm(p => ({ ...p, tags }))} />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSubmit} disabled={uploading || !form.name || !file} className="bg-indigo-600 hover:bg-indigo-700">
            {uploading ? <><Loader2 className="w-4 h-4 animate-spin mr-1" /> Envoi...</> : <><Upload className="w-4 h-4 mr-1" /> Enregistrer</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}