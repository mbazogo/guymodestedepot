import React, { useState } from "react";
import { X, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";

const PRESET_TAGS = ["urgent", "à signer", "archivé", "modèle", "confidentiel", "important", "à envoyer"];

export default function DocumentTagsInput({ tags = [], onChange }) {
  const [inputValue, setInputValue] = useState("");

  const addTag = (tag) => {
    const trimmed = tag.trim().toLowerCase();
    if (!trimmed || tags.includes(trimmed)) return;
    onChange([...tags, trimmed]);
    setInputValue("");
  };

  const removeTag = (tag) => onChange(tags.filter(t => t !== tag));

  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(inputValue);
    }
    if (e.key === "Backspace" && !inputValue && tags.length > 0) {
      removeTag(tags[tags.length - 1]);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {tags.map(tag => (
          <span key={tag} className="inline-flex items-center gap-1 bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full font-medium">
            #{tag}
            <button onClick={() => removeTag(tag)} className="hover:text-indigo-900">
              <X className="w-3 h-3" />
            </button>
          </span>
        ))}
      </div>
      <Input
        value={inputValue}
        onChange={e => setInputValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Ajouter un tag (Entrée pour valider)..."
        className="text-sm"
      />
      <div className="flex flex-wrap gap-1 mt-1.5">
        {PRESET_TAGS.filter(t => !tags.includes(t)).map(t => (
          <button key={t} onClick={() => addTag(t)}
            className="text-[10px] text-slate-500 bg-slate-100 hover:bg-indigo-100 hover:text-indigo-600 px-2 py-0.5 rounded-full transition-colors flex items-center gap-0.5">
            <Plus className="w-2.5 h-2.5" /> {t}
          </button>
        ))}
      </div>
    </div>
  );
}