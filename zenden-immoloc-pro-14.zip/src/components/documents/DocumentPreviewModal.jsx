import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, ExternalLink, FileText, Image, FileSpreadsheet, X } from "lucide-react";

const TYPE_LABELS = {
  bail: "Bail", quittance: "Quittance", avis_echeance: "Avis d'échéance",
  courrier: "Courrier", attestation: "Attestation", relance: "Relance", autre: "Autre"
};
const STATUS_COLORS = {
  draft: "bg-slate-100 text-slate-600", sent: "bg-blue-100 text-blue-700", signed: "bg-emerald-100 text-emerald-700"
};
const STATUS_LABELS = { draft: "Brouillon", sent: "Envoyé", signed: "Signé" };

function getFileType(url) {
  if (!url) return "unknown";
  const ext = url.split("?")[0].split(".").pop()?.toLowerCase();
  if (["pdf"].includes(ext)) return "pdf";
  if (["png", "jpg", "jpeg", "gif", "webp"].includes(ext)) return "image";
  if (["xls", "xlsx", "csv"].includes(ext)) return "spreadsheet";
  if (["doc", "docx"].includes(ext)) return "word";
  return "unknown";
}

export default function DocumentPreviewModal({ open, onClose, document }) {
  if (!document) return null;
  const fileType = getFileType(document.file_url);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-5 py-4 border-b border-slate-100 shrink-0">
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-base font-semibold text-slate-800 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-500 shrink-0" />
                {document.name}
              </DialogTitle>
              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                <Badge className="bg-indigo-100 text-indigo-700 text-[10px]">{TYPE_LABELS[document.type] || document.type}</Badge>
                <Badge className={`${STATUS_COLORS[document.status]} text-[10px]`}>{STATUS_LABELS[document.status]}</Badge>
                {document.tenant_name && <span className="text-xs text-slate-500">👤 {document.tenant_name}</span>}
                {document.property_name && <span className="text-xs text-slate-500">🏠 {document.property_name}</span>}
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 ml-4">
              {document.file_url && (
                <>
                  <a href={document.file_url} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" variant="outline" className="gap-1">
                      <ExternalLink className="w-3.5 h-3.5" /> Ouvrir
                    </Button>
                  </a>
                  <a href={document.file_url} download>
                    <Button size="sm" variant="outline" className="gap-1">
                      <Download className="w-3.5 h-3.5" /> Télécharger
                    </Button>
                  </a>
                </>
              )}
            </div>
          </div>
        </DialogHeader>

        {/* Preview area */}
        <div className="flex-1 overflow-hidden bg-slate-100">
          {!document.file_url ? (
            <div className="flex flex-col items-center justify-center h-full text-slate-400">
              <FileText className="w-16 h-16 mb-3 opacity-30" />
              <p className="text-sm">Aucun fichier associé</p>
            </div>
          ) : fileType === "pdf" ? (
            <iframe
              src={`${document.file_url}#toolbar=1&navpanes=0`}
              className="w-full h-full border-0"
              title={document.name}
            />
          ) : fileType === "image" ? (
            <div className="flex items-center justify-center h-full p-4">
              <img src={document.file_url} alt={document.name} className="max-w-full max-h-full object-contain rounded-lg shadow-lg" />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-4">
              {fileType === "spreadsheet" ? <FileSpreadsheet className="w-20 h-20 text-green-400 opacity-50" /> : <FileText className="w-20 h-20 text-blue-400 opacity-50" />}
              <div className="text-center">
                <p className="font-medium text-slate-700">{document.name}</p>
                <p className="text-sm text-slate-400 mt-1">Prévisualisation non disponible pour ce type de fichier</p>
              </div>
              <a href={document.file_url} target="_blank" rel="noopener noreferrer">
                <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2">
                  <ExternalLink className="w-4 h-4" /> Ouvrir le fichier
                </Button>
              </a>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}