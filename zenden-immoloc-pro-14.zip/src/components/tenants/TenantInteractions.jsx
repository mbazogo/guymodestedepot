import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, MessageSquare, FileText, User, MapPin, StickyNote, Plus, Trash2, ArrowDownLeft, ArrowUpRight } from "lucide-react";

const TYPE_CONFIG = {
  appel:    { label: "Appel",    icon: Phone,          color: "bg-blue-100 text-blue-700" },
  email:    { label: "Email",    icon: Mail,           color: "bg-indigo-100 text-indigo-700" },
  sms:      { label: "SMS",      icon: MessageSquare,  color: "bg-teal-100 text-teal-700" },
  visite:   { label: "Visite",   icon: MapPin,         color: "bg-violet-100 text-violet-700" },
  note:     { label: "Note",     icon: StickyNote,     color: "bg-amber-100 text-amber-700" },
  courrier: { label: "Courrier", icon: FileText,        color: "bg-orange-100 text-orange-700" },
  autre:    { label: "Autre",    icon: User,            color: "bg-slate-100 text-slate-600" },
};

const DEFAULT_FORM = {
  type: "note", direction: "sortant", subject: "", content: "",
  date: new Date().toISOString().split("T")[0], author: ""
};

export default function TenantInteractions({ tenantId, tenantName }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(DEFAULT_FORM);
  const [editingId, setEditingId] = useState(null);
  const qc = useQueryClient();

  const { data: interactions = [] } = useQuery({
    queryKey: ["interactions", tenantId],
    queryFn: () => base44.entities.TenantInteraction.filter({ tenant_id: tenantId }, "-date"),
    enabled: !!tenantId
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId
      ? base44.entities.TenantInteraction.update(editingId, data)
      : base44.entities.TenantInteraction.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["interactions", tenantId] }); setOpen(false); }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TenantInteraction.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["interactions", tenantId] })
  });

  const openNew = () => { setForm(DEFAULT_FORM); setEditingId(null); setOpen(true); };
  const openEdit = (item) => { setForm({ ...item }); setEditingId(item.id); setOpen(true); };

  const handleSave = () => {
    saveMutation.mutate({ ...form, tenant_id: tenantId, tenant_name: tenantName });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-800 text-sm">Historique des interactions ({interactions.length})</h3>
        <Button size="sm" onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
          <Plus className="w-3.5 h-3.5 mr-1.5" /> Ajouter
        </Button>
      </div>

      {interactions.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <StickyNote className="w-10 h-10 mx-auto mb-2 text-slate-300" />
          <p className="text-sm">Aucune interaction enregistrée</p>
          <button onClick={openNew} className="text-xs text-emerald-600 hover:underline mt-1">Ajouter la première →</button>
        </div>
      ) : (
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-5 top-0 bottom-0 w-px bg-slate-200" />
          <div className="space-y-3">
            {interactions.map((item) => {
              const cfg = TYPE_CONFIG[item.type] || TYPE_CONFIG.autre;
              const Icon = cfg.icon;
              return (
                <div key={item.id} className="flex gap-4 relative">
                  {/* Icon dot */}
                  <div className={`w-10 h-10 rounded-full ${cfg.color} flex items-center justify-center shrink-0 z-10 border-2 border-white shadow-sm`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  {/* Content */}
                  <div className="flex-1 bg-white border border-slate-100 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Badge className={`${cfg.color} text-[10px]`}>{cfg.label}</Badge>
                        {item.direction && (
                          <span className={`flex items-center gap-0.5 text-[10px] font-medium ${item.direction === "entrant" ? "text-emerald-600" : "text-blue-600"}`}>
                            {item.direction === "entrant"
                              ? <ArrowDownLeft className="w-3 h-3" />
                              : <ArrowUpRight className="w-3 h-3" />}
                            {item.direction}
                          </span>
                        )}
                        {item.subject && <span className="text-sm font-semibold text-slate-800">{item.subject}</span>}
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="text-[10px] text-slate-400 whitespace-nowrap">
                          {item.date ? new Date(item.date).toLocaleDateString("fr-FR") : ""}
                        </span>
                        <Button size="icon" variant="ghost" className="w-6 h-6" onClick={() => openEdit(item)}>
                          <FileText className="w-3 h-3 text-slate-400" />
                        </Button>
                        <Button size="icon" variant="ghost" className="w-6 h-6" onClick={() => { if (confirm("Supprimer ?")) deleteMutation.mutate(item.id); }}>
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </Button>
                      </div>
                    </div>
                    {item.content && <p className="text-xs text-slate-600 mt-1.5 whitespace-pre-wrap">{item.content}</p>}
                    {item.author && <p className="text-[10px] text-slate-400 mt-1">par {item.author}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editingId ? "Modifier l'interaction" : "Nouvelle interaction"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Type *</Label>
                <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_CONFIG).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Sens</Label>
                <Select value={form.direction} onValueChange={v => setForm({ ...form, direction: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sortant">Sortant</SelectItem>
                    <SelectItem value="entrant">Entrant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Date *</Label>
                <Input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Auteur</Label>
                <Input value={form.author || ""} onChange={e => setForm({ ...form, author: e.target.value })} placeholder="Votre nom" className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Objet</Label>
              <Input value={form.subject || ""} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="Ex: Rappel loyer, question bail…" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Notes / Contenu</Label>
              <Textarea value={form.content || ""} onChange={e => setForm({ ...form, content: e.target.value })} rows={4} placeholder="Détails de l'interaction…" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}