import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AlertTriangle, CalendarClock, CheckCircle2, Clock } from "lucide-react";

function daysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
}

export default function TenantLeaseAlerts({ tenant, lease }) {
  const alerts = [];

  // Lease end alert
  const endDays = daysUntil(tenant?.lease_end || lease?.end_date);
  if (endDays !== null) {
    if (endDays < 0) {
      alerts.push({ level: "error", icon: AlertTriangle, message: `Bail expiré depuis ${Math.abs(endDays)} jour(s)`, link: "Leases" });
    } else if (endDays <= 90) {
      alerts.push({ level: "warning", icon: Clock, message: `Fin de bail dans ${endDays} jour(s) (${new Date(tenant?.lease_end || lease?.end_date).toLocaleDateString("fr-FR")})`, link: "Leases" });
    }
  }

  // Lease start anniversary
  const startDate = tenant?.lease_start || lease?.start_date;
  if (startDate) {
    const start = new Date(startDate);
    const now = new Date();
    const thisYearAnniv = new Date(now.getFullYear(), start.getMonth(), start.getDate());
    const daysToAnniv = daysUntil(thisYearAnniv.toISOString().split("T")[0]);
    const years = now.getFullYear() - start.getFullYear();
    if (daysToAnniv !== null && daysToAnniv >= 0 && daysToAnniv <= 30) {
      alerts.push({ level: "info", icon: CalendarClock, message: `Anniversaire du bail dans ${daysToAnniv} jour(s) — ${years} an(s) de location` });
    } else if (daysToAnniv !== null && daysToAnniv < 0 && daysToAnniv > -5) {
      alerts.push({ level: "info", icon: CheckCircle2, message: `Anniversaire du bail il y a ${Math.abs(daysToAnniv)} jour(s) — ${years} an(s) de location` });
    }
  }

  if (alerts.length === 0) return null;

  const styles = {
    error:   "bg-red-50 border-red-200 text-red-800",
    warning: "bg-amber-50 border-amber-200 text-amber-800",
    info:    "bg-blue-50 border-blue-200 text-blue-800",
  };
  const iconStyles = { error: "text-red-500", warning: "text-amber-500", info: "text-blue-500" };

  return (
    <div className="space-y-2">
      {alerts.map((alert, i) => {
        const Icon = alert.icon;
        return (
          <div key={i} className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${styles[alert.level]}`}>
            <Icon className={`w-4 h-4 shrink-0 ${iconStyles[alert.level]}`} />
            <span className="text-sm flex-1">{alert.message}</span>
            {alert.link && (
              <Link to={createPageUrl(alert.link)} className="text-xs font-semibold underline underline-offset-2 shrink-0">
                Voir →
              </Link>
            )}
          </div>
        );
      })}
    </div>
  );
}