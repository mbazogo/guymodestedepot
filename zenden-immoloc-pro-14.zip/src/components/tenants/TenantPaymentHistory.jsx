import React, { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, AlertTriangle, XCircle, TrendingUp, TrendingDown, Minus, Printer, MessageCircle, Download, Loader2 } from "lucide-react";

const MONTHS_FR = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

const STATUS_CONFIG = {
  paid:    { label: "Payé",       cls: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: CheckCircle2, iconCls: "text-emerald-500", rowCls: "bg-white" },
  partial: { label: "Partiel",    cls: "bg-amber-100 text-amber-700 border-amber-200",   icon: Minus,         iconCls: "text-amber-500",   rowCls: "bg-amber-50/40" },
  pending: { label: "En attente", cls: "bg-sky-100 text-sky-700 border-sky-200",         icon: Clock,         iconCls: "text-sky-500",     rowCls: "bg-sky-50/30" },
  late:    { label: "En retard",  cls: "bg-red-100 text-red-700 border-red-200",         icon: AlertTriangle, iconCls: "text-red-500",     rowCls: "bg-red-50/40" },
  missing: { label: "Non appelé", cls: "bg-slate-100 text-slate-500 border-slate-200",   icon: XCircle,       iconCls: "text-slate-400",   rowCls: "bg-slate-50/50" },
};

const FILTERS = ["Tous", "Payé", "Partiel", "En attente", "En retard", "Non appelé"];
const FILTER_MAP = { "Tous": null, "Payé": "paid", "Partiel": "partial", "En attente": "pending", "En retard": "late", "Non appelé": "missing" };

export default function TenantPaymentHistory({ tenant, payments, lease, onPrintReceipt, onWhatsAppReceipt, onDownloadReceipt, generatingPdf, selectedPaymentId }) {
  const [filter, setFilter] = useState("Tous");

  // Build all periods from lease start (or first payment) to today
  const allPeriods = React.useMemo(() => {
    const today = new Date();
    let startDate;
    if (lease?.start_date) {
      startDate = new Date(lease.start_date);
    } else if (tenant?.lease_start) {
      startDate = new Date(tenant.lease_start);
    } else if (payments.length > 0) {
      const sorted = [...payments].sort((a, b) => (a.period_year * 100 + a.period_month) - (b.period_year * 100 + b.period_month));
      startDate = new Date(sorted[0].period_year, sorted[0].period_month - 1, 1);
    } else {
      startDate = new Date(today.getFullYear(), today.getMonth(), 1);
    }

    const periods = [];
    const cur = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    const endMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    while (cur <= endMonth) {
      const m = cur.getMonth() + 1;
      const y = cur.getFullYear();
      const pay = payments.find(p => p.period_month === m && p.period_year === y);
      periods.push({ month: m, year: y, payment: pay });
      cur.setMonth(cur.getMonth() + 1);
    }

    return periods.reverse(); // most recent first
  }, [tenant, lease, payments]);

  const periodsWithStatus = allPeriods.map(p => ({
    ...p,
    status: p.payment?.status || "missing",
  }));

  const filtered = FILTER_MAP[filter]
    ? periodsWithStatus.filter(p => p.status === FILTER_MAP[filter])
    : periodsWithStatus;

  // Stats
  const stats = {
    paid: periodsWithStatus.filter(p => p.status === "paid").length,
    partial: periodsWithStatus.filter(p => p.status === "partial").length,
    late: periodsWithStatus.filter(p => p.status === "late").length,
    pending: periodsWithStatus.filter(p => p.status === "pending").length,
    missing: periodsWithStatus.filter(p => p.status === "missing").length,
    totalPaid: payments.filter(p => p.status === "paid" || p.status === "partial").reduce((s, p) => s + (p.amount || 0), 0),
    totalExpected: allPeriods.length * (tenant?.rent_amount || 0),
  };

  return (
    <div className="space-y-4">
      {/* KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="p-3 text-center">
          <div className="text-xs text-slate-500 mb-1">Périodes totales</div>
          <div className="text-xl font-bold text-slate-800">{allPeriods.length}</div>
        </Card>
        <Card className="p-3 text-center">
          <div className="text-xs text-slate-500 mb-1">Total encaissé</div>
          <div className="text-lg font-bold text-emerald-600">{formatXAF(stats.totalPaid)}</div>
          <div className="text-[10px] text-slate-400">XAF</div>
        </Card>
        <Card className="p-3 text-center">
          <div className="text-xs text-slate-500 mb-1">Mois payés / en retard</div>
          <div className="flex items-center justify-center gap-2">
            <span className="text-lg font-bold text-emerald-600 flex items-center gap-1"><TrendingUp className="w-4 h-4" />{stats.paid + stats.partial}</span>
            <span className="text-slate-300">/</span>
            <span className="text-lg font-bold text-red-500 flex items-center gap-1"><TrendingDown className="w-4 h-4" />{stats.late}</span>
          </div>
        </Card>
        <Card className="p-3 text-center">
          <div className="text-xs text-slate-500 mb-1">Non appelés</div>
          <div className="text-xl font-bold text-slate-400">{stats.missing + stats.pending}</div>
        </Card>
      </div>

      {/* Filter pills */}
      <div className="flex flex-wrap gap-2">
        {FILTERS.map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${
              filter === f
                ? "bg-slate-800 text-white border-slate-800"
                : "bg-white text-slate-600 border-slate-200 hover:border-slate-400"
            }`}
          >
            {f}
            {f !== "Tous" && (
              <span className="ml-1 opacity-60">
                ({periodsWithStatus.filter(p => p.status === FILTER_MAP[f]).length})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="text-left px-4 py-3 text-slate-500 font-semibold">Période</th>
                <th className="text-left px-4 py-3 text-slate-500 font-semibold">Date paiement</th>
                <th className="text-left px-4 py-3 text-slate-500 font-semibold">Mode</th>
                <th className="text-right px-4 py-3 text-slate-500 font-semibold">Attendu</th>
                <th className="text-right px-4 py-3 text-slate-500 font-semibold">Payé</th>
                <th className="text-center px-4 py-3 text-slate-500 font-semibold">Statut</th>
                <th className="text-center px-4 py-3 text-slate-500 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(({ month, year, payment, status }) => {
                const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.missing;
                const Icon = cfg.icon;
                const isGenPdf = generatingPdf && selectedPaymentId === payment?.id;
                return (
                  <tr key={`${year}-${month}`} className={`border-b border-slate-50 ${cfg.rowCls} hover:brightness-95 transition-all`}>
                    <td className="px-4 py-3 font-semibold text-slate-800">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-3.5 h-3.5 shrink-0 ${cfg.iconCls}`} />
                        {MONTHS_FR[month - 1]} {year}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {payment?.payment_date ? (
                        <span className="font-medium text-slate-700">
                          {payment.payment_date.split("T")[0].split("-").reverse().join("/")}
                        </span>
                      ) : (
                        <span className="text-slate-300 text-xs italic">non renseignée</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-500 capitalize">
                      {payment?.payment_method?.replace(/_/g, " ") || "—"}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600">
                      {formatXAF(payment?.expected_amount || tenant?.rent_amount)} XAF
                    </td>
                    <td className="px-4 py-3 text-right font-semibold">
                      {payment ? <span className={status === "paid" ? "text-emerald-700" : status === "late" ? "text-red-600" : "text-amber-700"}>{formatXAF(payment.amount)} XAF</span> : <span className="text-slate-300">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${cfg.cls}`}>
                        {cfg.label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {payment && (status === "paid" || status === "partial") ? (
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => onPrintReceipt?.(payment)}
                            title="Imprimer quittance"
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onWhatsAppReceipt?.(payment)}
                            title="Envoyer via WhatsApp"
                            className="p-1.5 rounded-md hover:bg-green-100 text-slate-500 hover:text-green-700 transition-colors"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDownloadReceipt?.(payment)}
                            title="Télécharger PDF"
                            disabled={isGenPdf}
                            className="p-1.5 rounded-md hover:bg-emerald-100 text-slate-500 hover:text-emerald-700 transition-colors disabled:opacity-50"
                          >
                            {isGenPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-300 text-center block">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">Aucune période trouvée</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}