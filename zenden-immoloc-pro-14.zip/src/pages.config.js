/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Accounting from './pages/Accounting';
import AppSettingsPage from './pages/AppSettingsPage';
import Archives from './pages/Archives';
import Charges from './pages/Charges';
import Dashboard from './pages/Dashboard';
import Documents from './pages/Documents';
import FinancialStats from './pages/FinancialStats';
import InventoryReports from './pages/InventoryReports';
import Leases from './pages/Leases';
import Messaging from './pages/Messaging';
import Payments from './pages/Payments';
import Profitability from './pages/Profitability';
import Properties from './pages/Properties';
import Reminders from './pages/Reminders';
import RentCall from './pages/RentCall';
import Reports from './pages/Reports';
import RevenueAllocation from './pages/RevenueAllocation';
import RevenueBoard from './pages/RevenueBoard';
import TenantDetail from './pages/TenantDetail';
import Tenants from './pages/Tenants';
import Unpaid from './pages/Unpaid';
import InternalRules from './pages/InternalRules';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Accounting": Accounting,
    "AppSettingsPage": AppSettingsPage,
    "Archives": Archives,
    "Charges": Charges,
    "Dashboard": Dashboard,
    "Documents": Documents,
    "FinancialStats": FinancialStats,
    "InventoryReports": InventoryReports,
    "Leases": Leases,
    "Messaging": Messaging,
    "Payments": Payments,
    "Profitability": Profitability,
    "Properties": Properties,
    "Reminders": Reminders,
    "RentCall": RentCall,
    "Reports": Reports,
    "RevenueAllocation": RevenueAllocation,
    "RevenueBoard": RevenueBoard,
    "TenantDetail": TenantDetail,
    "Tenants": Tenants,
    "Unpaid": Unpaid,
    "InternalRules": InternalRules,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};