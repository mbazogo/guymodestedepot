import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, FileText, Search, Printer, Settings2, Archive } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import ArchiveButton from "../components/archive/ArchiveButton";
import LeaseContractModal from "../components/leases/LeaseContractModal";
import LeaseTemplateManager from "../components/leases/LeaseTemplateManager";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const typeLabels = { non_meuble: "Non meublé", meuble: "Meublé", bnb: "BnB", commercial: "Commercial", autre: "Autre" };
const statusColors = { active: "bg-emerald-100 text-emerald-700", expired: "bg-red-100 text-red-700", terminated: "bg-slate-100 text-slate-600", draft: "bg-amber-100 text-amber-700" };
const statusLabels = { active: "Actif", expired: "Expiré", terminated: "Résilié", draft: "Brouillon" };

export default function Leases() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [contractLease, setContractLease] = useState(null);
  const [showTemplateManager, setShowTemplateManager] = useState(false);
  const qc = useQueryClient();

  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const { data: leases = [], isLoading } = useQuery({ queryKey: ["leases"], queryFn: () => base44.entities.Lease.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const result = editingId
        ? await base44.entities.Lease.update(editingId, data)
        : await base44.entities.Lease.create(data);
      // When lease is active, mark the property as occupied
      if (data.status === "active" && data.property_id) {
        await base44.entities.Property.update(data.property_id, { status: "occupied" });
      }
      return result;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leases"] });
      qc.invalidateQueries({ queryKey: ["properties"] });
      setDialogOpen(false);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Lease.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leases"] })
  });

  const [showArchived, setShowArchived] = useState(false);

  const archiveMutation = useMutation({
    mutationFn: ({ id, archived }) => base44.entities.Lease.update(id, { archived }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leases"] })
  });

  const openNew = () => {
    setForm({ tenant_id: "", property_id: "", type: "non_meuble", start_date: "", end_date: "", rent_amount: "", charges_amount: "", deposit_amount: "", payment_day: 1, status: "draft", clauses: "", tva_applicable: false, tva_rate: 0 });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (l) => {setForm({ ...l });setEditingId(l.id);setDialogOpen(true);};

  const handleSave = () => {
    const tenant = tenants.find((t) => t.id === form.tenant_id);
    const prop = properties.find((p) => p.id === form.property_id);
    saveMutation.mutate({
      ...form,
      tenant_name: tenant ? `${tenant.first_name} ${tenant.last_name}` : "",
      property_name: prop?.name || "",
      rent_amount: Number(form.rent_amount) || 0,
      charges_amount: Number(form.charges_amount) || 0,
      deposit_amount: Number(form.deposit_amount) || 0,
      payment_day: Number(form.payment_day) || 1,
      tva_rate: Number(form.tva_rate) || 0
    });
  };

  const visibleLeases = leases.filter((l) => showArchived ? l.archived : !l.archived);
  const filtered = visibleLeases.filter((l) =>
    l.tenant_name?.toLowerCase().includes(search.toLowerCase()) ||
    l.property_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-green-600 text-xl font-bold">Gestion des baux</h1>
          <p className="text-sm text-slate-500">{leases.length} bail(aux)</p>
        </div>
        <div className="flex gap-2">
          {!showArchived && (
            <Button variant="outline" onClick={() => setShowTemplateManager(true)} className="gap-2 text-sm">
              <Settings2 className="w-4 h-4" /> Modèles
            </Button>
          )}
          <Button variant="outline" onClick={() => setShowArchived(!showArchived)} className={showArchived ? "border-amber-300 text-amber-700 bg-amber-50" : ""}>
            <Archive className="w-4 h-4 mr-2" /> {showArchived ? "Vue archivés" : "Archives"}
          </Button>
          {!showArchived && (
            <Button onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              <Plus className="w-4 h-4 mr-2" /> Nouveau bail
            </Button>
          )}
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      {isLoading ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div> :

      <div className="space-y-3">
          {filtered.map((l) =>
        <Card key={l.id} className="p-4 hover:shadow-md transition-shadow">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-sm">{l.tenant_name || "—"}</h3>
                      <Badge className={`${statusColors[l.status]} text-[10px]`}>{statusLabels[l.status]}</Badge>
                      <Badge variant="outline" className="text-[10px]">{typeLabels[l.type]}</Badge>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {l.property_name} • {l.start_date} → {l.end_date || "Indéterminé"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold">{formatXAF(l.rent_amount)} XAF/mois</span>
                  <Button size="sm" variant="outline" onClick={() => setContractLease(l)} title="Générer le contrat de bail" className="text-blue-600 border-blue-200 hover:bg-blue-50">
                    <Printer className="w-3.5 h-3.5 mr-1" /> Contrat
                  </Button>
                  {!l.archived && <Button size="icon" variant="ghost" onClick={() => openEdit(l)}><Pencil className="w-4 h-4 text-slate-500" /></Button>}
                  <ArchiveButton item={l} onArchive={(id, archived) => archiveMutation.mutate({ id, archived })} />
                  {!l.archived && <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ?")) deleteMutation.mutate(l.id);}}><Trash2 className="w-4 h-4 text-red-500" /></Button>}
                </div>
              </div>
            </Card>
        )}
          {filtered.length === 0 &&
        <div className="text-center py-16 text-slate-400">
              <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun bail trouvé</p>
            </div>
        }
        </div>
      }

      {/* Contract modal */}
      <LeaseTemplateManager open={showTemplateManager} onClose={() => setShowTemplateManager(false)} />

      {contractLease && (
        <LeaseContractModal
          lease={contractLease}
          tenant={tenants.find((t) => t.id === contractLease.tenant_id)}
          property={properties.find((p) => p.id === contractLease.property_id)}
          settings={settings}
          onClose={() => setContractLease(null)}
        />
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le bail" : "Nouveau bail"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Locataire *</Label>
              <Select value={form.tenant_id || ""} onValueChange={(v) => setForm({ ...form, tenant_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>{tenants.map((t) => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Bien *</Label>
              <Select value={form.property_id || ""} onValueChange={(v) => setForm({ ...form, property_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>{properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type *</Label>
                <Select value={form.type || "non_meuble"} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(typeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Statut</Label>
                <Select value={form.status || "draft"} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(statusLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Date début *</Label><Input type="date" value={form.start_date || ""} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
              <div><Label>Date fin</Label><Input type="date" value={form.end_date || ""} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><Label>Loyer (XAF) *</Label><Input type="number" value={form.rent_amount || ""} onChange={(e) => setForm({ ...form, rent_amount: e.target.value })} /></div>
              <div><Label>Charges (XAF)</Label><Input type="number" value={form.charges_amount || ""} onChange={(e) => setForm({ ...form, charges_amount: e.target.value })} /></div>
              <div><Label>Dépôt (XAF)</Label><Input type="number" value={form.deposit_amount || ""} onChange={(e) => setForm({ ...form, deposit_amount: e.target.value })} /></div>
            </div>
            <div><Label>Clauses particulières</Label><Textarea value={form.clauses || ""} onChange={(e) => setForm({ ...form, clauses: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}