import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings, Save, Upload, Building2, FileText, Bell, Trash2, AlertTriangle, Receipt, Eye, ScrollText } from "lucide-react";
import InternalRulesModal from "../components/settings/InternalRulesModal";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";

const DEFAULT_SETTINGS = {
  company_name: "Zenden Immo", currency: "XAF", tva_rate: 0, payment_day: 1,
  owner_name: "", owner_address: "", owner_phone: "", owner_email: "",
  auto_rent_call: false, auto_receipt: true, notification_days_before: 5,
  receipt_footer_text: "Le bailleur certifie avoir reçu la somme indiquée en règlement du loyer du bien susmentionné.",
  receipt_show_charges: true,
  receipt_show_reference: true,
  receipt_custom_clause: "",
};

const DYNAMIC_FIELDS = [
  { key: "receipt_show_charges", label: "Afficher les charges" },
  { key: "receipt_show_reference", label: "Afficher la référence de paiement" },
];

export default function AppSettingsPage() {
  const qc = useQueryClient();
  const [form, setForm] = useState(DEFAULT_SETTINGS);
  const [logoFile, setLogoFile] = useState(null);
  const [signatureFile, setSignatureFile] = useState(null);
  const [showReceiptPreview, setShowReceiptPreview] = useState(false);
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [settingsId, setSettingsId] = useState(null);

  const { data: settingsList = [], isLoading } = useQuery({
    queryKey: ["settings"],
    queryFn: () => base44.entities.AppSettings.list()
  });

  useEffect(() => {
    if (settingsList.length > 0) {
      const s = settingsList[0];
      setSettingsId(s.id);
      const { id, created_date, updated_date, created_by, ...rest } = s;
      setForm({ ...DEFAULT_SETTINGS, ...rest });
    }
  }, [settingsList]);

  const handleSave = async () => {
    setSaving(true);
    try {
      let data = { ...form };

      if (logoFile) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: logoFile });
        data.logo_url = file_url;
        setLogoFile(null);
      }
      if (signatureFile) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: signatureFile });
        data.signature_url = file_url;
        setSignatureFile(null);
      }

      if (settingsId) {
        await base44.entities.AppSettings.update(settingsId, data);
      } else {
        const created = await base44.entities.AppSettings.create(data);
        setSettingsId(created.id);
      }
      qc.invalidateQueries({ queryKey: ["settings"] });
      alert("Paramètres enregistrés avec succès !");
    } catch (e) {
      alert("Erreur lors de l'enregistrement : " + e.message);
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) return <div className="space-y-4">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}</div>;

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-blue-700 text-xl font-bold">Paramètres</h1>
        <p className="text-sm text-slate-500">Configuration de l'application</p>
      </div>

      {/* Company info */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center"><Building2 className="w-4 h-4 text-blue-600" /></div>
          <h2 className="text-sm font-semibold text-left">Informations du propriétaire</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><Label>Nom de la société</Label><Input value={form.company_name || ""} onChange={(e) => setForm({ ...form, company_name: e.target.value })} /></div>
          <div><Label>Nom du propriétaire</Label><Input value={form.owner_name || ""} onChange={(e) => setForm({ ...form, owner_name: e.target.value })} /></div>
          <div><Label>Adresse</Label><Input value={form.owner_address || ""} onChange={(e) => setForm({ ...form, owner_address: e.target.value })} /></div>
          <div><Label>Téléphone</Label><Input value={form.owner_phone || ""} onChange={(e) => setForm({ ...form, owner_phone: e.target.value })} /></div>
          <div><Label>Email</Label><Input type="email" value={form.owner_email || ""} onChange={(e) => setForm({ ...form, owner_email: e.target.value })} /></div>
        </div>
      </Card>

      {/* Financial */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center"><Settings className="w-4 h-4 text-emerald-600" /></div>
          <h2 className="text-sm font-semibold">Paramètres financiers</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label>Devise</Label>
            <Select value={form.currency || "XAF"} onValueChange={(v) => setForm({ ...form, currency: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="XAF">XAF (Franc CFA)</SelectItem>
                <SelectItem value="EUR">EUR (Euro)</SelectItem>
                <SelectItem value="USD">USD (Dollar)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Taux TVA (%)</Label>
            <Select value={String(form.tva_rate || 0)} onValueChange={(v) => setForm({ ...form, tva_rate: Number(v) })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">0%</SelectItem>
                <SelectItem value="18">18%</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Jour d'appel de loyer</Label>
            <Input type="number" min={1} max={31} value={form.payment_day || 1} onChange={(e) => setForm({ ...form, payment_day: Number(e.target.value) })} />
          </div>
        </div>
      </Card>

      {/* Notifications */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center"><Bell className="w-4 h-4 text-amber-600" /></div>
          <h2 className="text-sm font-semibold">Automatisation</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Appel de loyer automatique</p>
              <p className="text-xs text-slate-400">Génère automatiquement les appels de loyer</p>
            </div>
            <Switch checked={form.auto_rent_call || false} onCheckedChange={(v) => setForm({ ...form, auto_rent_call: v })} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Quittance automatique</p>
              <p className="text-xs text-slate-400">Génère une quittance à chaque encaissement</p>
            </div>
            <Switch checked={form.auto_receipt ?? true} onCheckedChange={(v) => setForm({ ...form, auto_receipt: v })} />
          </div>
          <div>
            <Label>Notification avant échéance (jours)</Label>
            <Input type="number" min={0} max={30} value={form.notification_days_before || 5} onChange={(e) => setForm({ ...form, notification_days_before: Number(e.target.value) })} className="max-w-[120px]" />
          </div>
        </div>
      </Card>

      {/* Branding */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-violet-100 flex items-center justify-center"><FileText className="w-4 h-4 text-violet-600" /></div>
          <h2 className="text-slate-700 text-sm font-semibold">Logo & Signature</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Logo</Label>
            {form.logo_url && <img src={form.logo_url} alt="Logo" className="w-24 h-24 object-contain rounded-lg border mb-2" />}
            <Input type="file" accept="image/*" onChange={(e) => setLogoFile(e.target.files?.[0])} />
          </div>
          <div>
            <Label>Signature</Label>
            {form.signature_url && <img src={form.signature_url} alt="Signature" className="w-24 h-24 object-contain rounded-lg border mb-2" />}
            <Input type="file" accept="image/*" onChange={(e) => setSignatureFile(e.target.files?.[0])} />
          </div>
        </div>
      </Card>

      {/* Internal Rules */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center"><ScrollText className="w-4 h-4 text-indigo-600" /></div>
            <div>
              <h2 className="text-slate-700 text-sm font-semibold">Règlement Intérieur</h2>
              <p className="text-xs text-slate-400">Visualisez et imprimez le règlement à remettre aux locataires</p>
            </div>
          </div>
          <Button variant="outline" className="gap-2 text-sm" onClick={() => setShowRulesModal(true)}>
            <ScrollText className="w-4 h-4" /> Voir & Imprimer
          </Button>
        </div>
      </Card>
      <InternalRulesModal settings={form} open={showRulesModal} onClose={() => setShowRulesModal(false)} />

      {/* Receipt customization */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-100 flex items-center justify-center"><Receipt className="w-4 h-4 text-teal-600" /></div>
            <h2 className="text-slate-700 text-sm font-semibold">Personnalisation de la quittance</h2>
          </div>
          <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => setShowReceiptPreview(!showReceiptPreview)}>
            <Eye className="w-3.5 h-3.5" /> {showReceiptPreview ? "Masquer" : "Aperçu"}
          </Button>
        </div>

        <div className="space-y-4">
          {/* Dynamic fields */}
          <div>
            <Label className="mb-2 block text-xs text-slate-500 uppercase tracking-wide">Champs à afficher</Label>
            <div className="flex flex-wrap gap-4">
              {DYNAMIC_FIELDS.map(({ key, label }) => (
                <div key={key} className="flex items-center gap-2">
                  <Checkbox
                    id={key}
                    checked={form[key] ?? true}
                    onCheckedChange={(v) => setForm({ ...form, [key]: !!v })}
                  />
                  <label htmlFor={key} className="text-sm text-slate-700 cursor-pointer">{label}</label>
                </div>
              ))}
            </div>
          </div>

          {/* Footer text */}
          <div>
            <Label>Texte de certification (pied de quittance)</Label>
            <Textarea
              value={form.receipt_footer_text || ""}
              onChange={(e) => setForm({ ...form, receipt_footer_text: e.target.value })}
              className="text-sm mt-1 h-20 resize-none"
              placeholder="Le bailleur certifie avoir reçu..."
            />
          </div>

          {/* Custom clause */}
          <div>
            <Label>Clause personnalisée (optionnel)</Label>
            <Textarea
              value={form.receipt_custom_clause || ""}
              onChange={(e) => setForm({ ...form, receipt_custom_clause: e.target.value })}
              className="text-sm mt-1 h-20 resize-none"
              placeholder="Ajoutez ici une clause spécifique qui apparaîtra sur toutes vos quittances..."
            />
          </div>
        </div>

        {/* Mini preview */}
        {showReceiptPreview && (
          <div className="mt-5 border border-slate-200 rounded-lg p-4 bg-slate-50 text-xs text-slate-600 space-y-2">
            <p className="font-bold text-[#0f2b4c] text-sm">{form.company_name || "Zenden Immo"}</p>
            {form.owner_address && <p>{form.owner_address}</p>}
            <div className="border border-[#0f2b4c] inline-block px-4 py-1 font-bold uppercase text-[#0f2b4c] text-xs mt-1">Quittance de Loyer</div>
            <div className="bg-[#0f2b4c] text-white rounded px-3 py-2 text-center">
              <span className="font-bold">XXX XXX XAF</span> <span className="opacity-70 text-[10px]">montant reçu</span>
            </div>
            {form.receipt_show_charges && <p className="text-[10px] text-slate-400">✓ Charges affichées</p>}
            {form.receipt_show_reference && <p className="text-[10px] text-slate-400">✓ Référence affichée</p>}
            <p className="text-[10px] italic text-slate-500 border-t pt-2">{form.receipt_footer_text || "..."}</p>
            {form.receipt_custom_clause && <p className="text-[10px] italic text-slate-500">{form.receipt_custom_clause}</p>}
            {form.signature_url && <img src={form.signature_url} alt="Signature" className="h-10 object-contain" />}
          </div>
        )}
      </Card>

      {/* Danger Zone */}
      <Card className="p-6 border-red-200 bg-red-50/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center"><AlertTriangle className="w-4 h-4 text-red-600" /></div>
          <h2 className="text-sm font-semibold text-red-700">Zone dangereuse</h2>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-800">Remise à zéro des données</p>
            <p className="text-xs text-slate-500">Supprime définitivement tous les locataires, biens, paiements, charges et baux.</p>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" className="gap-2">
                <Trash2 className="w-4 h-4" /> Remise à zéro
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirmer la remise à zéro</AlertDialogTitle>
                <AlertDialogDescription>
                  Cette action est <strong>irréversible</strong>. Toutes les données (biens, locataires, baux, paiements, charges, documents) seront définitivement supprimées.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annuler</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-red-600 hover:bg-red-700"
                  onClick={async () => {
                    const [tenants, properties, payments, charges, leases, docs] = await Promise.all([
                    base44.entities.Tenant.list(),
                    base44.entities.Property.list(),
                    base44.entities.Payment.list(),
                    base44.entities.Charge.list(),
                    base44.entities.Lease.list(),
                    base44.entities.Document.list()]
                    );
                    await Promise.all([
                    ...tenants.map((r) => base44.entities.Tenant.delete(r.id)),
                    ...properties.map((r) => base44.entities.Property.delete(r.id)),
                    ...payments.map((r) => base44.entities.Payment.delete(r.id)),
                    ...charges.map((r) => base44.entities.Charge.delete(r.id)),
                    ...leases.map((r) => base44.entities.Lease.delete(r.id)),
                    ...docs.map((r) => base44.entities.Document.delete(r.id))]
                    );
                    alert("Toutes les données ont été supprimées.");
                    window.location.reload();
                  }}>

                  Oui, tout supprimer
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
          <Save className="w-4 h-4 mr-2" /> {saving ? "Enregistrement..." : "Enregistrer les paramètres"}
        </Button>
      </div>
    </div>);

}