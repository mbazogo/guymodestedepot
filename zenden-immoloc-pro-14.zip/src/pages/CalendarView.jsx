import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, ChevronLeft, ChevronRight, AlertCircle, CheckCircle2, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";

const MONTHS = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
const WEEKDAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

const EVENT_TYPES = {
  lease_start: { label: "Début de bail", color: "bg-emerald-100 text-emerald-800 border-emerald-300", icon: "🎯" },
  lease_end: { label: "Fin de bail", color: "bg-red-100 text-red-800 border-red-300", icon: "⏹️" },
  renewal: { label: "Renouvellement", color: "bg-blue-100 text-blue-800 border-blue-300", icon: "🔄" },
  notice_required: { label: "Préavis requis", color: "bg-orange-100 text-orange-800 border-orange-300", icon: "⚠️" }
};

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  const { data: leases = [] } = useQuery({
    queryKey: ["leases"],
    queryFn: () => base44.entities.Lease.list()
  });

  const { data: tenants = [] } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list()
  });

  // Generate calendar events from leases
  const events = useMemo(() => {
    const allEvents = [];
    const today = new Date();

    leases.forEach(lease => {
      const tenant = tenants.find(t => t.id === lease.tenant_id);
      const startDate = lease.start_date ? new Date(lease.start_date) : null;
      const endDate = lease.end_date ? new Date(lease.end_date) : null;

      // Début de bail
      if (startDate) {
        allEvents.push({
          date: startDate,
          type: "lease_start",
          title: `Début: ${tenant?.first_name} ${tenant?.last_name}`,
          lease,
          tenant
        });
      }

      // Fin de bail
      if (endDate) {
        allEvents.push({
          date: endDate,
          type: "lease_end",
          title: `Fin: ${tenant?.first_name} ${tenant?.last_name}`,
          lease,
          tenant
        });

        // Préavis (3 mois avant la fin)
        const noticeDate = new Date(endDate);
        noticeDate.setMonth(noticeDate.getMonth() - 3);
        if (noticeDate > today) {
          allEvents.push({
            date: noticeDate,
            type: "notice_required",
            title: `Préavis: ${tenant?.first_name} ${tenant?.last_name}`,
            lease,
            tenant
          });
        }
      }

      // Renouvellement (tous les 2 ans par défaut)
      if (startDate && !lease.archived) {
        const renewalDate = new Date(startDate);
        renewalDate.setFullYear(renewalDate.getFullYear() + 2);

        // Afficher les renouvellements à venir
        if (renewalDate > today) {
          allEvents.push({
            date: renewalDate,
            type: "renewal",
            title: `Renouvellement: ${tenant?.first_name} ${tenant?.last_name}`,
            lease,
            tenant
          });
        }
      }
    });

    return allEvents;
  }, [leases, tenants]);

  // Get events for a specific date
  const getDateEvents = (date) => {
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate.toDateString() === date.toDateString();
    });
  };

  // Calendar generation
  const getDaysInMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const getFirstDayOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay();

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const days = [];

  // Previous month days
  const prevMonthDays = getDaysInMonth(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  for (let i = firstDay === 0 ? 6 : firstDay - 1; i > 0; i--) {
    days.push({ day: prevMonthDays - i + 1, isCurrentMonth: false });
  }

  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    days.push({ day: i, isCurrentMonth: true });
  }

  // Next month days
  const totalCells = Math.ceil(days.length / 7) * 7;
  for (let i = 1; i <= totalCells - days.length; i++) {
    days.push({ day: i, isCurrentMonth: false });
  }

  const weeks = [];
  for (let i = 0; i < days.length; i += 7) {
    weeks.push(days.slice(i, i + 7));
  }

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  // Get upcoming events
  const upcomingEvents = useMemo(() => {
    const today = new Date();
    return events
      .filter(e => new Date(e.date) >= today)
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .slice(0, 10);
  }, [events]);

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-700 text-white rounded-xl p-8 shadow-lg">
        <h1 className="text-3xl font-bold mb-2">Calendrier des Baux</h1>
        <p className="text-blue-100 text-sm">Visualisez les échéances, fins de bail et renouvellements</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Calendrier principal */}
        <div className="lg:col-span-2">
          <Card className="overflow-hidden">
            {/* Header du calendrier */}
            <div className="bg-slate-50 border-b border-slate-200 p-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-800">
                {MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handlePrevMonth}
                  className="h-8 w-8"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentDate(new Date())}
                  className="text-xs"
                >
                  Aujourd'hui
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleNextMonth}
                  className="h-8 w-8"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Jours de la semaine */}
            <div className="grid grid-cols-7 bg-slate-100 border-b border-slate-200">
              {WEEKDAYS.map(day => (
                <div key={day} className="p-3 text-center text-xs font-semibold text-slate-600">
                  {day}
                </div>
              ))}
            </div>

            {/* Grille du calendrier */}
            <div className="grid grid-cols-7 gap-px bg-slate-200 p-px">
              {weeks.map((week, weekIdx) =>
                week.map((dayObj, dayIdx) => {
                  const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), dayObj.day);
                  const dateEvents = dayObj.isCurrentMonth ? getDateEvents(date) : [];
                  const isToday = new Date().toDateString() === date.toDateString();
                  const isSelected = selectedDate?.toDateString() === date.toDateString();

                  return (
                    <div
                      key={`${weekIdx}-${dayIdx}`}
                      onClick={() => setSelectedDate(date)}
                      className={`bg-white p-2 min-h-24 cursor-pointer transition-all ${
                        isToday ? "bg-emerald-50 border-2 border-emerald-400" : ""
                      } ${isSelected ? "ring-2 ring-blue-500" : ""} ${
                        !dayObj.isCurrentMonth ? "bg-slate-50 text-slate-400" : ""
                      }`}
                    >
                      <div className={`text-sm font-semibold mb-1 ${!dayObj.isCurrentMonth ? "text-slate-400" : "text-slate-800"}`}>
                        {dayObj.day}
                      </div>
                      <div className="space-y-1">
                        {dateEvents.slice(0, 2).map((event, idx) => {
                          const cfg = EVENT_TYPES[event.type];
                          return (
                            <div
                              key={idx}
                              className={`text-[10px] px-1.5 py-0.5 rounded-full border truncate ${cfg.color}`}
                              title={event.title}
                            >
                              {cfg.icon} {event.type === "lease_start" ? "Début" : event.type === "lease_end" ? "Fin" : event.type === "renewal" ? "Renouvellement" : "Préavis"}
                            </div>
                          );
                        })}
                        {dateEvents.length > 2 && (
                          <div className="text-[10px] text-slate-600 px-1">+{dateEvents.length - 2} plus</div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </Card>

          {/* Légende */}
          <Card className="mt-4 p-4">
            <h3 className="font-semibold text-slate-800 mb-3">Légende</h3>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(EVENT_TYPES).map(([type, cfg]) => (
                <div key={type} className="flex items-center gap-2">
                  <span className="text-lg">{cfg.icon}</span>
                  <span className="text-sm text-slate-700">{cfg.label}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Détails du jour sélectionné + Événements à venir */}
        <div className="space-y-4">
          {/* Événements du jour sélectionné */}
          {selectedDate && (
            <Card className="p-4">
              <h3 className="font-semibold text-slate-800 mb-3">
                {selectedDate.toLocaleDateString("fr-FR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
              </h3>
              <div className="space-y-2">
                {getDateEvents(selectedDate).length > 0 ? (
                  getDateEvents(selectedDate).map((event, idx) => {
                    const cfg = EVENT_TYPES[event.type];
                    return (
                      <div key={idx} className={`p-3 rounded-lg border ${cfg.color}`}>
                        <p className="font-semibold text-sm">{cfg.icon} {cfg.label}</p>
                        <p className="text-xs mt-1">{event.tenant?.first_name} {event.tenant?.last_name}</p>
                        <p className="text-xs opacity-75">{event.lease?.property_name}</p>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-sm text-slate-500">Aucun événement</p>
                )}
              </div>
            </Card>
          )}

          {/* Événements à venir */}
          <Card className="p-4">
            <h3 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Prochains événements
            </h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {upcomingEvents.length > 0 ? (
                upcomingEvents.map((event, idx) => {
                  const cfg = EVENT_TYPES[event.type];
                  const daysFromNow = Math.ceil((new Date(event.date) - new Date()) / (1000 * 60 * 60 * 24));
                  return (
                    <div key={idx} className="p-2 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="flex items-start gap-2">
                        <span className="text-lg mt-0.5">{cfg.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-slate-700 truncate">{event.tenant?.first_name} {event.tenant?.last_name}</p>
                          <p className="text-[11px] text-slate-600">{cfg.label}</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">
                            {new Date(event.date).toLocaleDateString("fr-FR")} ({daysFromNow}j)
                          </p>
                        </div>
                        {daysFromNow <= 30 && (
                          <Badge variant="destructive" className="text-[10px] shrink-0">Urgent</Badge>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-slate-500">Aucun événement à venir</p>
              )}
            </div>
          </Card>

          {/* Statistiques */}
          <Card className="p-4 bg-blue-50 border-blue-200">
            <h3 className="font-semibold text-slate-800 mb-3">Statistiques</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Baux actifs</span>
                <span className="font-semibold">{leases.filter(l => l.status === "active").length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Fins à venir (30j)</span>
                <span className="font-semibold text-red-600">
                  {events.filter(e => e.type === "lease_end" && {
                    daysFromNow: Math.ceil((new Date(e.date) - new Date()) / (1000 * 60 * 60 * 24))
                  }.daysFromNow >= 0 && Math.ceil((new Date(e.date) - new Date()) / (1000 * 60 * 60 * 24)) <= 30).length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Renouvellements</span>
                <span className="font-semibold text-blue-600">
                  {events.filter(e => e.type === "renewal").length}
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}