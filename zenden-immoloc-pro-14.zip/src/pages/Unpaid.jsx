import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertTriangle, Mail, MessageSquare, Printer, Send,
  CheckCircle2, Clock, Search, Users, RefreshCw,
  ChevronRight, Eye, History, Filter, Zap, TrendingDown } from
"lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const MONTHS = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}
function formatDate(d) {return d ? new Date(d).toLocaleDateString("fr-FR") : "—";}

// Relance templates
const RELANCE_TEMPLATES = [
{
  id: "relance_1",
  label: "1ère relance (amiable)",
  tag: "1ère relance",
  tagColor: "bg-amber-100 text-amber-700",
  subject: "Rappel – Loyer impayé {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Sauf erreur de notre part, nous n'avons pas reçu votre loyer du mois de {mois} {annee}.

Montant dû : {loyer} XAF
Bien : {bien}

Nous vous demandons de bien vouloir régulariser votre situation dans les meilleurs délais.

En cas de difficultés, n'hésitez pas à nous contacter pour trouver une solution.

Cordialement,
{societe}`
},
{
  id: "relance_2",
  label: "2ème relance (formelle)",
  tag: "2ème relance",
  tagColor: "bg-orange-100 text-orange-700",
  subject: "2ème relance – Loyer impayé {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Malgré notre précédent rappel, nous constatons que votre loyer du mois de {mois} {annee} reste impayé.

Montant dû : {loyer} XAF
Bien : {bien}

Nous vous demandons de régulariser cette situation dans un délai de 8 jours à compter de la présente. Passé ce délai, nous nous verrons contraints d'engager les démarches légales prévues à cet effet.

Cordialement,
{societe}`
},
{
  id: "relance_3",
  label: "3ème relance (mise en demeure)",
  tag: "Mise en demeure",
  tagColor: "bg-red-100 text-red-700",
  subject: "MISE EN DEMEURE – Loyer impayé {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Par la présente, nous vous mettons en demeure de régler, dans un délai de 72 heures, la somme de {loyer} XAF correspondant à votre loyer du mois de {mois} {annee} pour le bien : {bien}.

À défaut de paiement dans ce délai, nous serons contraints d'engager une procédure judiciaire d'expulsion.

Cette lettre vaut mise en demeure au sens légal.

Cordialement,
{societe}`
},
{
  id: "custom",
  label: "Message personnalisé",
  tag: "Personnalisé",
  tagColor: "bg-slate-100 text-slate-600",
  subject: "",
  body: ""
}];


function fillTemplate(text, tenant, settings, payment) {
  const months = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
  const m = payment?.period_month ? months[payment.period_month - 1] : months[new Date().getMonth()];
  const y = payment?.period_year || new Date().getFullYear();
  return (text || "").
  replace(/{civilite}/g, tenant?.civility || "").
  replace(/{nom}/g, `${tenant?.first_name || ""} ${tenant?.last_name || ""}`.trim()).
  replace(/{loyer}/g, formatXAF(payment?.expected_amount || tenant?.rent_amount || 0)).
  replace(/{bien}/g, tenant?.property_name || payment?.property_name || "").
  replace(/{mois}/g, m).
  replace(/{annee}/g, y).
  replace(/{societe}/g, settings?.company_name || "Zenden ImmoLoc");
}

// ── Single Relance Dialog ──────────────────────────────────────────────────────
function RelanceDialog({ payment, tenant, settings, onClose, onSent }) {
  const [templateId, setTemplateId] = useState("relance_1");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const qc = useQueryClient();

  const tpl = RELANCE_TEMPLATES.find((t) => t.id === templateId);

  React.useEffect(() => {
    if (tpl && tenant) {
      setSubject(fillTemplate(tpl.subject, tenant, settings, payment));
      setBody(fillTemplate(tpl.body, tenant, settings, payment));
    } else {
      setSubject(tpl?.subject || "");
      setBody(tpl?.body || "");
    }
    setSent(false);
  }, [templateId, tenant?.id]);

  const saveInteraction = async (channel) => {
    await base44.entities.TenantInteraction.create({
      tenant_id: tenant.id,
      tenant_name: `${tenant.first_name} ${tenant.last_name}`,
      type: channel === "whatsapp" ? "sms" : "email",
      direction: "sortant",
      subject: subject,
      content: `[${tpl?.tag || "Relance"}] ${body.slice(0, 300)}...`,
      date: new Date().toISOString().split("T")[0],
      author: settings?.owner_name || "Gestionnaire"
    });
    qc.invalidateQueries({ queryKey: ["interactions", tenant.id] });
  };

  const handleEmail = async () => {
    if (!tenant?.email) return alert("Ce locataire n'a pas d'adresse email.");
    setSending(true);
    await base44.integrations.Core.SendEmail({
      to: tenant.email,
      subject,
      body: body.replace(/\n/g, "<br/>")
    });
    await saveInteraction("email");
    setSending(false);
    setSent(true);
    onSent && onSent();
  };

  const handleWhatsApp = async () => {
    if (!tenant?.phone) return alert("Ce locataire n'a pas de numéro de téléphone.");
    const phone = tenant.phone.replace(/[^0-9]/g, "");
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(body)}`, "_blank");
    await saveInteraction("whatsapp");
    onSent && onSent();
  };

  const handlePrint = () => {
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const today = new Date().toLocaleDateString("fr-FR");
    const html = `<html><head><title>${subject}</title>
    <style>body{font-family:Arial,sans-serif;padding:50px;color:#1e293b;font-size:12pt}
    .header{display:flex;justify-content:space-between;border-bottom:2px solid #0f2b4c;padding-bottom:16px;margin-bottom:32px}
    .title{text-align:center;margin:28px 0}.title h1{font-size:15px;font-weight:bold;text-transform:uppercase;color:#0f2b4c;display:inline-block;border:2px solid #0f2b4c;padding:6px 20px}
    .content{white-space:pre-wrap;font-size:12pt;line-height:1.8;margin:24px 0}
    .footer{margin-top:60px;display:flex;justify-content:flex-end}
    .sig-block{text-align:center}.sig-name{border-top:1px solid #1e293b;padding-top:6px;font-size:11px;font-weight:bold;min-width:200px}
    .legal{text-align:center;font-size:9px;color:#94a3b8;margin-top:40px;border-top:1px solid #e2e8f0;padding-top:10px}
    </style></head><body>
    <div class="header">
      <div><div style="font-size:18px;font-weight:bold;color:#0f2b4c;">${companyName}</div><div style="font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:2px">Gestion locative</div></div>
      <div style="text-align:right;font-size:11px;color:#64748b;line-height:1.8">
        <div><strong>Date :</strong> ${today}</div>
        <div><strong>Destinataire :</strong> ${tenant?.civility || ""} ${tenant?.first_name} ${tenant?.last_name}</div>
        <div><strong>Bien :</strong> ${tenant?.property_name || ""}</div>
      </div>
    </div>
    <div class="title"><h1>${subject}</h1></div>
    <div class="content">${(body || "").replace(/\n/g, "<br/>")}</div>
    <div class="footer"><div class="sig-block"><div style="height:50px"></div><div class="sig-name">${settings?.owner_name || companyName}</div><div style="font-size:10px;color:#64748b">Le Bailleur</div></div></div>
    <div class="legal">Document généré par ${companyName} • ${today}</div>
    </body></html>`;
    const w = window.open("", "_blank");w.document.write(html);w.document.close();w.print();
    saveInteraction("courrier");
  };

  return (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          Envoyer une relance — {tenant?.first_name} {tenant?.last_name}
        </DialogTitle>
      </DialogHeader>

      {/* Payment summary */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-3 text-sm">
        <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
        <div>
          <span className="font-semibold text-red-700">Loyer impayé :</span>
          <span className="text-red-600 ml-1">{formatXAF(payment?.expected_amount || 0)} XAF</span>
          {payment?.period_month && <span className="text-red-500 ml-1">— {MONTHS[payment.period_month - 1]} {payment.period_year}</span>}
          <span className="text-slate-500 ml-2">• {tenant?.property_name}</span>
        </div>
      </div>

      {/* Template selector */}
      <div>
        <Label className="text-xs text-slate-500 mb-2 block">Type de relance</Label>
        <div className="grid grid-cols-2 gap-2">
          {RELANCE_TEMPLATES.map((t) =>
          <button key={t.id} onClick={() => setTemplateId(t.id)}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-left text-sm transition-all ${templateId === t.id ? "border-red-400 bg-red-50" : "border-slate-200 hover:bg-slate-50"}`}>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${t.tagColor}`}>{t.tag}</span>
              <span className="text-slate-700 font-medium text-xs">{t.label}</span>
            </button>
          )}
        </div>
      </div>

      {/* Email composer */}
      <div className="space-y-3">
        <div>
          <Label className="text-xs text-slate-500 mb-1 block">Objet</Label>
          <Input value={subject} onChange={(e) => setSubject(e.target.value)} className="text-sm" />
        </div>
        <div>
          <Label className="text-xs text-slate-500 mb-1 block">Message</Label>
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={10} className="text-sm font-mono resize-none" />
        </div>
      </div>

      {sent &&
      <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg px-4 py-2.5 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" /> Relance envoyée et enregistrée dans l'historique du locataire !
        </div>
      }

      <DialogFooter className="flex-wrap gap-2">
        <Button variant="outline" onClick={onClose}>Annuler</Button>
        <Button variant="outline" onClick={handlePrint} className="gap-2">
          <Printer className="w-4 h-4" /> Imprimer
        </Button>
        <Button onClick={handleWhatsApp} disabled={!tenant?.phone} className="bg-[#25D366] hover:bg-[#20be5b] text-white gap-2">
          <MessageSquare className="w-4 h-4" /> WhatsApp
        </Button>
        <Button onClick={handleEmail} disabled={sending || !tenant?.email} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">
          <Mail className="w-4 h-4" /> {sending ? "Envoi..." : "Envoyer Email"}
        </Button>
      </DialogFooter>
    </DialogContent>);

}

// ── Bulk Send Dialog ───────────────────────────────────────────────────────────
function BulkRelanceDialog({ items, tenants, settings, onClose, onDone }) {
  const [templateId, setTemplateId] = useState("relance_1");
  const [sending, setSending] = useState(false);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);
  const qc = useQueryClient();

  const tpl = RELANCE_TEMPLATES.find((t) => t.id === templateId);
  const withEmail = items.filter(({ tenant }) => tenant?.email);

  const handleBulkSend = async () => {
    if (!confirm(`Envoyer ${withEmail.length} email(s) de relance ?`)) return;
    setSending(true);
    for (let i = 0; i < withEmail.length; i++) {
      const { payment, tenant } = withEmail[i];
      const subj = fillTemplate(tpl.subject, tenant, settings, payment);
      const body = fillTemplate(tpl.body, tenant, settings, payment);
      await base44.integrations.Core.SendEmail({ to: tenant.email, subject: subj, body: body.replace(/\n/g, "<br/>") });
      await base44.entities.TenantInteraction.create({
        tenant_id: tenant.id,
        tenant_name: `${tenant.first_name} ${tenant.last_name}`,
        type: "email", direction: "sortant",
        subject: subj,
        content: `[${tpl.tag} – Envoi groupé] ${body.slice(0, 300)}...`,
        date: new Date().toISOString().split("T")[0],
        author: settings?.owner_name || "Gestionnaire"
      });
      setProgress(i + 1);
    }
    qc.invalidateQueries({ queryKey: ["interactions"] });
    setSending(false);
    setDone(true);
    onDone && onDone();
  };

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-500" /> Envoi groupé de relances
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700">
          <strong>{items.length}</strong> impayé(s) sélectionné(s) — <strong>{withEmail.length}</strong> avec email renseigné
        </div>

        <div>
          <Label className="text-xs text-slate-500 mb-2 block">Type de relance</Label>
          <div className="space-y-1.5">
            {RELANCE_TEMPLATES.filter((t) => t.id !== "custom").map((t) =>
            <button key={t.id} onClick={() => setTemplateId(t.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-left transition-all ${templateId === t.id ? "border-amber-400 bg-amber-50" : "border-slate-200 hover:bg-slate-50"}`}>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium shrink-0 ${t.tagColor}`}>{t.tag}</span>
                <span className="text-sm text-slate-700">{t.label}</span>
              </button>
            )}
          </div>
        </div>

        {/* Preview list */}
        <div className="max-h-40 overflow-y-auto space-y-1">
          {withEmail.map(({ payment, tenant }) =>
          <div key={payment.id} className="flex items-center justify-between text-xs bg-slate-50 rounded-lg px-3 py-1.5">
              <span className="font-medium text-slate-700">{tenant?.first_name} {tenant?.last_name}</span>
              <span className="text-slate-400">{tenant?.email}</span>
              <span className="text-red-600 font-semibold">{formatXAF(payment.expected_amount)} XAF</span>
            </div>
          )}
          {items.filter(({ tenant }) => !tenant?.email).map(({ tenant }) =>
          <div key={tenant?.id} className="flex items-center gap-2 text-xs bg-slate-50 rounded-lg px-3 py-1.5 opacity-50">
              <span className="text-slate-500">{tenant?.first_name} {tenant?.last_name}</span>
              <span className="text-red-400">— pas d'email</span>
            </div>
          )}
        </div>

        {sending &&
        <div className="bg-blue-50 rounded-lg p-3 text-sm text-blue-700">
            Envoi en cours... {progress}/{withEmail.length}
            <div className="w-full bg-blue-200 rounded-full h-2 mt-2">
              <div className="bg-blue-500 h-2 rounded-full transition-all" style={{ width: `${progress / withEmail.length * 100}%` }} />
            </div>
          </div>
        }

        {done &&
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg px-4 py-2.5 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> {progress} relance(s) envoyée(s) et enregistrées !
          </div>
        }
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onClose}>{done ? "Fermer" : "Annuler"}</Button>
        {!done &&
        <Button onClick={handleBulkSend} disabled={sending || withEmail.length === 0} className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">
            <Send className="w-4 h-4" /> {sending ? "Envoi..." : `Envoyer ${withEmail.length} email(s)`}
          </Button>
        }
      </DialogFooter>
    </DialogContent>);

}

// ── History Panel ─────────────────────────────────────────────────────────────
function HistoryPanel({ tenant }) {
  const { data: interactions = [], isLoading } = useQuery({
    queryKey: ["interactions", tenant?.id],
    queryFn: () => base44.entities.TenantInteraction.filter({ tenant_id: tenant.id }, "-date"),
    enabled: !!tenant?.id
  });

  const relances = interactions.filter((i) => i.subject?.toLowerCase().includes("relance") || i.subject?.toLowerCase().includes("impayé") || i.subject?.toLowerCase().includes("mise en demeure"));

  if (isLoading) return <div className="animate-pulse h-20 bg-slate-100 rounded-lg" />;

  return (
    <div className="space-y-2 mt-2">
      {relances.length === 0 && <p className="text-xs text-slate-400 text-center py-4">Aucune relance enregistrée</p>}
      {relances.slice(0, 5).map((i) =>
      <div key={i.id} className="flex items-start gap-2 bg-slate-50 rounded-lg p-2.5 text-xs">
          <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-slate-700 truncate">{i.subject}</p>
            <p className="text-slate-400">{formatDate(i.date)}</p>
          </div>
        </div>
      )}
    </div>);

}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function Unpaid() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(new Set());
  const [relanceTarget, setRelanceTarget] = useState(null); // { payment, tenant }
  const [bulkOpen, setBulkOpen] = useState(false);
  const [expandedTenant, setExpandedTenant] = useState(null);
  const [tab, setTab] = useState("late");

  const { data: payments = [], isLoading: lp } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const tenantMap = useMemo(() => Object.fromEntries(tenants.map((t) => [t.id, t])), [tenants]);

  const unpaid = useMemo(() => {
    const statuses = tab === "late" ? ["late"] : tab === "pending" ? ["pending"] : ["late", "pending"];
    return payments.
    filter((p) => statuses.includes(p.status)).
    filter((p) =>
    p.tenant_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.property_name?.toLowerCase().includes(search.toLowerCase())
    ).
    sort((a, b) => {
      // Sort by year/month descending, then by late > pending
      if (a.period_year !== b.period_year) return b.period_year - a.period_year;
      if (a.period_month !== b.period_month) return b.period_month - a.period_month;
      return 0;
    });
  }, [payments, tab, search]);

  const totalOwed = unpaid.reduce((s, p) => s + (p.expected_amount || 0), 0);
  const lateCount = payments.filter((p) => p.status === "late").length;
  const pendingCount = payments.filter((p) => p.status === "pending").length;

  const toggleSelect = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  const toggleAll = () => {
    if (selected.size === unpaid.length) setSelected(new Set());else
    setSelected(new Set(unpaid.map((p) => p.id)));
  };

  const selectedItems = unpaid.
  filter((p) => selected.has(p.id)).
  map((p) => ({ payment: p, tenant: tenantMap[p.tenant_id] }));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-orange-600 text-xl font-bold flex items-center gap-2">Gestion des impayés


          </h1>
          <p className="text-sm text-slate-500">Relancez vos locataires en retard par email, WhatsApp ou courrier</p>
        </div>
        {selected.size > 0 &&
        <Button onClick={() => setBulkOpen(true)} className="bg-red-600 hover:bg-red-700 gap-2">
            <Send className="w-4 h-4" /> Relance groupée ({selected.size})
          </Button>
        }
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-3 gap-3">
        <Card className={`p-4 flex items-center gap-3 cursor-pointer transition-all ${tab === "late" ? "ring-2 ring-red-400" : ""}`} onClick={() => setTab("late")}>
          <div className="w-9 h-9 rounded-lg bg-red-100 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5 text-red-600" />
          </div>
          <div>
            <p className="text-xs text-slate-500">En retard</p>
            <p className="text-lg font-bold text-red-600">{lateCount}</p>
          </div>
        </Card>
        <Card className={`p-4 flex items-center gap-3 cursor-pointer transition-all ${tab === "pending" ? "ring-2 ring-amber-400" : ""}`} onClick={() => setTab("pending")}>
          <div className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <p className="text-xs text-slate-500">En attente</p>
            <p className="text-lg font-bold text-amber-600">{pendingCount}</p>
          </div>
        </Card>
        <Card className="p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
            <TrendingDown className="w-5 h-5 text-slate-600" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Total dû (filtré)</p>
            <p className="text-sm font-bold text-slate-800">{formatXAF(totalOwed)} XAF</p>
          </div>
        </Card>
      </div>

      {/* Filters row */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
        <Tabs value={tab} onValueChange={(v) => {setTab(v);setSelected(new Set());}}>
          <TabsList>
            <TabsTrigger value="late">En retard ({lateCount})</TabsTrigger>
            <TabsTrigger value="pending">En attente ({pendingCount})</TabsTrigger>
            <TabsTrigger value="all">Tous ({lateCount + pendingCount})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Rechercher locataire, bien..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {/* Table */}
      {lp ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div> :

      <Card className="overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50 border-b">
            <div className="flex items-center gap-3">
              <Checkbox checked={selected.size === unpaid.length && unpaid.length > 0} onCheckedChange={toggleAll} />
              <span className="text-xs text-slate-500 font-medium">{unpaid.length} impayé(s)</span>
              {selected.size > 0 &&
            <Badge variant="outline" className="text-xs border-red-300 text-red-600">{selected.size} sélectionné(s)</Badge>
            }
            </div>
            {selected.size > 0 &&
          <Button size="sm" onClick={() => setBulkOpen(true)} className="bg-red-600 hover:bg-red-700 h-7 text-xs gap-1.5">
                <Zap className="w-3.5 h-3.5" /> Relance groupée
              </Button>
          }
          </div>

          {unpaid.length === 0 ?
        <div className="text-center py-16 text-slate-400">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p className="font-medium">Aucun impayé dans cette catégorie</p>
            </div> :

        <div className="divide-y">
              {unpaid.map((payment) => {
            const tenant = tenantMap[payment.tenant_id];
            const isExpanded = expandedTenant === payment.id;
            const isLate = payment.status === "late";
            return (
              <div key={payment.id}>
                    <div className={`flex items-center gap-3 px-4 py-3.5 hover:bg-slate-50/80 transition-colors ${isLate ? "bg-red-50/30" : ""}`}>
                      <Checkbox checked={selected.has(payment.id)} onCheckedChange={() => toggleSelect(payment.id)} />

                      {/* Status indicator */}
                      <div className={`w-2 h-10 rounded-full shrink-0 ${isLate ? "bg-red-400" : "bg-amber-400"}`} />

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-slate-800 text-sm">{payment.tenant_name}</span>
                          <Badge className={isLate ? "bg-red-100 text-red-700 text-[10px]" : "bg-amber-100 text-amber-700 text-[10px]"}>
                            {isLate ? "En retard" : "En attente"}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5 flex-wrap">
                          <span>{payment.property_name}</span>
                          <span>•</span>
                          <span>{MONTHS[(payment.period_month || 1) - 1]} {payment.period_year}</span>
                          {payment.due_date && <span>• Échéance : {formatDate(payment.due_date)}</span>}
                        </div>
                      </div>

                      {/* Amount */}
                      <div className="text-right shrink-0">
                        <p className="font-bold text-red-600 text-sm">{formatXAF(payment.expected_amount)} XAF</p>
                        {payment.amount > 0 && payment.amount < payment.expected_amount &&
                    <p className="text-[10px] text-slate-400">Partiel : {formatXAF(payment.amount)} reçus</p>
                    }
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1 shrink-0">
                        <Button size="icon" variant="ghost" className="h-8 w-8" title="Historique relances"
                    onClick={() => setExpandedTenant(isExpanded ? null : payment.id)}>
                          <History className="w-4 h-4 text-slate-400" />
                        </Button>
                        {tenant &&
                    <Link to={createPageUrl("TenantDetail") + `?id=${tenant.id}`}>
                            <Button size="icon" variant="ghost" className="h-8 w-8" title="Voir le profil">
                              <Eye className="w-4 h-4 text-slate-400" />
                            </Button>
                          </Link>
                    }
                        <Button size="sm" onClick={() => setRelanceTarget({ payment, tenant })}
                    className="bg-red-600 hover:bg-red-700 h-7 text-xs px-2.5 gap-1">
                          <Send className="w-3.5 h-3.5" /> Relancer
                        </Button>
                      </div>
                    </div>

                    {/* History panel */}
                    {isExpanded && tenant &&
                <div className="px-10 pb-4 bg-slate-50/50 border-t">
                        <p className="text-xs font-semibold text-slate-500 mt-3 mb-1 flex items-center gap-1.5">
                          <History className="w-3.5 h-3.5" /> Historique des relances — {tenant.first_name} {tenant.last_name}
                        </p>
                        <HistoryPanel tenant={tenant} />
                        <Link to={createPageUrl("TenantDetail") + `?id=${tenant.id}`}
                  className="text-xs text-emerald-600 hover:underline mt-2 block">
                          Voir tout l'historique →
                        </Link>
                      </div>
                }
                  </div>);

          })}
            </div>
        }
        </Card>
      }

      {/* Single relance dialog */}
      {relanceTarget &&
      <Dialog open={!!relanceTarget} onOpenChange={() => setRelanceTarget(null)}>
          <RelanceDialog
          payment={relanceTarget.payment}
          tenant={relanceTarget.tenant}
          settings={settings}
          onClose={() => setRelanceTarget(null)}
          onSent={() => {}} />

        </Dialog>
      }

      {/* Bulk relance dialog */}
      {bulkOpen &&
      <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
          <BulkRelanceDialog
          items={selectedItems}
          tenants={tenants}
          settings={settings}
          onClose={() => setBulkOpen(false)}
          onDone={() => setSelected(new Set())} />

        </Dialog>
      }
    </div>);

}