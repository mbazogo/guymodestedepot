import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Bell, CheckCheck, AlertCircle, Calendar, Mail, Printer, MessageCircle, FileWarning, X, ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const MONTHS = [
"Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
"Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];


function generateNoticeHTML(tenant, payment, month, year, settings) {
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const ownerName = settings?.owner_name || companyName;
  const ownerPhone = settings?.owner_phone || "";
  const ownerEmail = settings?.owner_email || "";
  const ownerAddress = settings?.owner_address || "";
  const logoHtml = settings?.logo_url ? `<img src="${settings.logo_url}" style="height:50px;object-fit:contain;display:block;margin-bottom:6px;" />` : "";
  const signatureHtml = settings?.signature_url ? `<img src="${settings.signature_url}" style="height:50px;object-fit:contain;display:block;margin:6px auto;" />` : `<div style="height:50px;"></div>`;
  const today = new Date().toLocaleDateString("fr-FR");
  const dueDay = 5;
  const tenantFullName = `${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}`.trim();
  const rent = new Intl.NumberFormat("fr-FR").format(tenant.rent_amount || 0);
  const charges = new Intl.NumberFormat("fr-FR").format(payment?.expected_amount ? payment.expected_amount - (tenant.rent_amount || 0) : 0);
  const total = new Intl.NumberFormat("fr-FR").format(payment?.expected_amount || tenant.rent_amount || 0);
  const periodLabel = `${MONTHS[month - 1]} ${year}`;

  return `<html><head><title>Avis d'échéance ${periodLabel}</title>
  <style>
    body{font-family:Arial,sans-serif;padding:40px;color:#1e293b;font-size:12px;}
    .hdr{background:#0f2b4c;color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;border-radius:6px;margin-bottom:24px;}
    .title-box{text-align:center;margin:16px 0;}
    .title{font-size:16px;font-weight:bold;text-transform:uppercase;color:#0f2b4c;border:2px solid #0f2b4c;padding:6px 24px;display:inline-block;}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:16px 0;}
    .info-box{background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:6px;}
    .info-label{font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;}
    .amount-box{background:#0f2b4c;color:#fff;padding:14px 20px;border-radius:8px;margin:16px 0;display:flex;justify-content:space-between;align-items:center;}
    .due-box{background:#fef3c7;border:1px solid #fcd34d;padding:12px 16px;border-radius:6px;margin:16px 0;font-size:11px;color:#92400e;}
    .footer{margin-top:28px;border-top:1px solid #e2e8f0;padding-top:14px;display:flex;justify-content:space-between;align-items:flex-end;}
    .sig{text-align:center;}.sig-line{border-top:1px solid #1e293b;width:160px;margin:4px auto;font-size:10px;}
    @media print{body{padding:20px;}}
  </style></head><body>
  <div class="hdr">
    <div>${logoHtml}<div style="font-size:16px;font-weight:bold;">${companyName}</div><div style="font-size:9px;opacity:.7;">GESTION LOCATIVE</div></div>
    <div style="text-align:right;font-size:11px;"><div>Émis le ${today}</div>${ownerPhone ? `<div>${ownerPhone}</div>` : ""}${ownerEmail ? `<div>${ownerEmail}</div>` : ""}</div>
  </div>
  <div class="title-box"><div class="title">AVIS D'ÉCHÉANCE DE LOYER</div>
  <p style="color:#64748b;margin-top:8px;">Période : <strong>${periodLabel}</strong> — Date limite de paiement : <strong>${dueDay} ${MONTHS[month - 1]} ${year}</strong></p></div>
  <div class="info-grid">
    <div class="info-box"><div class="info-label">Bailleur</div><strong>${ownerName}</strong>${ownerAddress ? `<div style="font-size:10px;color:#64748b;">${ownerAddress}</div>` : ""}</div>
    <div class="info-box"><div class="info-label">Locataire</div><strong>${tenantFullName}</strong><div style="font-size:10px;color:#64748b;">${tenant.property_name || ""}</div></div>
  </div>
  <div class="amount-box">
    <div>
      <div style="font-size:10px;opacity:.7;">Loyer</div>
      <div style="font-size:16px;font-weight:bold;">${rent} XAF</div>
    </div>
    ${charges !== "0" ? `<div><div style="font-size:10px;opacity:.7;">Charges</div><div style="font-size:14px;font-weight:bold;">+ ${charges} XAF</div></div>` : ""}
    <div>
      <div style="font-size:10px;opacity:.7;">TOTAL À PAYER</div>
      <div style="font-size:20px;font-weight:bold;">${total} XAF</div>
    </div>
  </div>
  <div class="due-box">
    ⚠️ <strong>Date limite de paiement : le ${dueDay} ${MONTHS[month - 1]} ${year}</strong><br/>
    Passé ce délai, des pénalités de retard pourront être appliquées à hauteur de 5 000 FCFA par jour de retard suite au non-respect des termes du contrat de bail sur les délais de paiement.
  </div>
  <p style="font-size:11px;color:#64748b;">Le bailleur rappelle au preneur que le loyer du mois de <strong>${periodLabel}</strong> est échu et doit être réglé au plus tard le <strong>${dueDay} ${MONTHS[month - 1]} ${year}</strong>. Merci de vous acquitter de cette somme dans les délais impartis.</p>
  <div class="footer">
    <div style="font-size:10px;color:#64748b;max-width:55%;">Réf : ${payment?.reference || `LOYER-${String(month).padStart(2, "0")}${year}`}<br/>Bien : ${tenant.property_name || "—"}</div>
    <div class="sig">${signatureHtml}<div class="sig-line">${ownerName}</div></div>
  </div>
  <div style="text-align:center;font-size:9px;color:#94a3b8;margin-top:16px;">Document généré par ${companyName}</div>
  </body></html>`;
}

export default function RentCall() {
  const now = new Date();
  const [month, setMonth] = useState(String(now.getMonth() + 1));
  const [year, setYear] = useState(String(now.getFullYear()));
  const [selected, setSelected] = useState([]);
  const [noticeModal, setNoticeModal] = useState(null); // { tenant, payment }
  const [sendStep, setSendStep] = useState(null); // null | 'whatsapp' | 'email'
  const [sendContact, setSendContact] = useState("");

  const noticedKey = `noticedTenants_${month}_${year}`;
  const [noticedTenants, setNoticedTenants] = useState(() => {
    try { return JSON.parse(localStorage.getItem(noticedKey) || "{}"); } catch { return {}; }
  });

  // Reset state when period changes
  useEffect(() => {
    try { setNoticedTenants(JSON.parse(localStorage.getItem(noticedKey) || "{}")); } catch { setNoticedTenants({}); }
  }, [month, year]);
  const qc = useQueryClient();

  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const { data: tenants = [], isLoading: lt } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: payments = [], isLoading: lp } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });

  const markNoticed = (tenantId, type) => {
    setNoticedTenants((prev) => {
      const updated = { ...prev, [tenantId]: type || 'clicked' };
      try { localStorage.setItem(noticedKey, JSON.stringify(updated)); } catch {}
      return updated;
    });
  };

  const openSendStep = (type, tenant) => {
    setSendStep(type);
    setSendContact(type === 'whatsapp' ? tenant.phone || "" : tenant.email || "");
  };

  const closeSendStep = () => {setSendStep(null);setSendContact("");};

  const sendNoticeEmail = async (tenant, payment, emailOverride) => {
    const m = Number(month),y = Number(year);
    const total = new Intl.NumberFormat("fr-FR").format(payment?.expected_amount || tenant.rent_amount || 0);
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const to = emailOverride || tenant.email;
    const body = `Bonjour ${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name},\n\nNous vous adressons le présent avis d'échéance pour le loyer du mois de ${MONTHS[m - 1]} ${y}.\n\nMontant total à payer : ${total} XAF\nDate limite de paiement : 5 ${MONTHS[m - 1]} ${y}\n\nMerci de vous acquitter de ce règlement avant la date indiquée.\n\nCordialement,\n${companyName}`;
    await base44.integrations.Core.SendEmail({ to, subject: `Avis d'échéance de loyer — ${MONTHS[m - 1]} ${y}`, body });
    markNoticed(tenant.id, 'sent');
    alert("Avis d'échéance envoyé par email !");
    closeSendStep();
    setNoticeModal(null);
  };

  const printNotice = (tenant, payment) => {
    const html = generateNoticeHTML(tenant, payment, Number(month), Number(year), settings);
    const w = window.open("", "_blank");
    w.document.write(html);
    w.document.close();
    w.print();
    markNoticed(tenant.id, 'printed');
  };

  const sendNoticeWhatsApp = (tenant, payment, phoneOverride) => {
    const m = Number(month),y = Number(year);
    const total = new Intl.NumberFormat("fr-FR").format(payment?.expected_amount || tenant.rent_amount || 0);
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const text = encodeURIComponent(`Bonjour ${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name},\n\n*Avis d'échéance de loyer — ${MONTHS[m - 1]} ${y}*\n\nMontant à payer : *${total} XAF*\nDate limite : *5 ${MONTHS[m - 1]} ${y}*\n\nMerci de procéder au règlement avant cette date.\n\n_${companyName}_`);
    const phone = (phoneOverride || tenant.phone || "").replace(/\D/g, "");
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
    markNoticed(tenant.id, 'sent');
    closeSendStep();
    setNoticeModal(null);
  };

  const isLoading = lt || lp;

  const m = Number(month);
  const y = Number(year);

  // Active tenants that don't yet have a payment called for this period
  const activeTenants = tenants.filter((t) => t.status === "active");
  const alreadyCalled = payments.
  filter((p) => p.period_month === m && p.period_year === y).
  map((p) => p.tenant_id);

  const notYetCalled = activeTenants.filter((t) => !alreadyCalled.includes(t.id));
  const alreadyCalledTenants = activeTenants.filter((t) => alreadyCalled.includes(t.id));

  const callMutation = useMutation({
    mutationFn: async (tenantIds) => {
      const tenantsToCall = notYetCalled.filter((t) => tenantIds.includes(t.id));
      const dueDate = `${y}-${String(m).padStart(2, "0")}-05`;
      await Promise.all(
        tenantsToCall.map((t) =>
        base44.entities.Payment.create({
          tenant_id: t.id,
          tenant_name: `${t.first_name} ${t.last_name}`,
          property_id: t.property_id,
          property_name: t.property_name || "",
          amount: 0,
          expected_amount: t.rent_amount || 0,
          period_month: m,
          period_year: y,
          due_date: dueDate,
          status: "pending",
          type: "loyer",
          payment_method: "especes",
          reference: `LOYER-${String(m).padStart(2, "0")}${y}-${t.id.slice(-4).toUpperCase()}`
        })
        )
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payments"] });
      setSelected([]);
      alert(`Appel de loyer effectué pour ${selected.length} locataire(s). Les paiements sont maintenant en attente dans la section Paiements.`);
    }
  });

  const toggleAll = () => {
    if (selected.length === notYetCalled.length) setSelected([]);else
    setSelected(notYetCalled.map((t) => t.id));
  };

  const toggle = (id) => {
    setSelected((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  const currentYear = now.getFullYear();
  const years = [currentYear, currentYear + 1];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-emerald-600 text-xl font-bold">Appel à Loyer</h1>
        <p className="text-sm text-slate-500">Générez les appels de loyer groupés par période</p>
      </div>

      {/* Period selector */}
      <Card className="p-5">
        <div className="flex flex-col sm:flex-row gap-4 items-end">
          <div>
            <Label className="mb-3 ml-3 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 block">Mois</Label>
            <Select value={month} onValueChange={setMonth}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                {MONTHS.map((n, i) => <SelectItem key={i + 1} value={String(i + 1)}>{n}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="mb-2 px-3 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 block">Année</Label>
            <Select value={year} onValueChange={setYear}>
              <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
              <SelectContent>
                {years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-lg text-sm text-blue-700">
            <Calendar className="w-4 h-4" />
            Période : <strong>{MONTHS[m - 1]} {y}</strong>
          </div>
        </div>
      </Card>

      {isLoading ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div> :

      <>
          {/* Not yet called */}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-500" />
                <h2 className="text-blue-700 text-sm font-semibold">À appeler ({notYetCalled.length})</h2>
              </div>
              {notYetCalled.length > 0 &&
            <button onClick={toggleAll} className="text-xs text-blue-600 hover:underline">
                  {selected.length === notYetCalled.length ? "Tout désélectionner" : "Tout sélectionner"}
                </button>
            }
            </div>

            {notYetCalled.length === 0 ?
          <div className="text-center py-8 text-slate-400">
                <CheckCheck className="w-10 h-10 mx-auto mb-2 text-emerald-400" />
                <p className="text-sm">Tous les loyers ont déjà été appelés pour cette période.</p>
              </div> :

          <div className="space-y-2">
                {notYetCalled.map((t) =>
            <div key={t.id} className={`flex items-center justify-between p-3 rounded-lg border transition-colors cursor-pointer ${selected.includes(t.id) ? "border-blue-300 bg-blue-50" : "border-slate-100 hover:bg-slate-50"}`}
            onClick={() => toggle(t.id)}>
                    <div className="flex items-center gap-3">
                      <Checkbox checked={selected.includes(t.id)} onCheckedChange={() => toggle(t.id)} onClick={(e) => e.stopPropagation()} />
                      <div>
                        <p className="text-sm font-medium text-slate-800">{t.first_name} {t.last_name}</p>
                        <p className="text-xs text-slate-500">{t.property_name || "—"}</p>
                      </div>
                    </div>
                    <span className="font-semibold text-slate-700 text-sm">{formatXAF(t.rent_amount)} XAF</span>
                  </div>
            )}
              </div>
          }

            {selected.length > 0 &&
          <div className="mt-4 pt-4 border-t flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">{selected.length} locataire(s) sélectionné(s)</p>
                  <p className="text-xs text-slate-400">
                    Total attendu : {formatXAF(notYetCalled.filter((t) => selected.includes(t.id)).reduce((s, t) => s + (t.rent_amount || 0), 0))} XAF
                  </p>
                </div>
                <Button
              onClick={() => callMutation.mutate(selected)}
              disabled={callMutation.isPending}
              className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">

                  <Bell className="w-4 h-4 mr-2" />
                  {callMutation.isPending ? "En cours..." : "Lancer l'appel de loyer"}
                </Button>
              </div>
          }
          </Card>

          {/* Already called */}
          {alreadyCalledTenants.length > 0 &&
        <Card className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <CheckCheck className="w-4 h-4 text-emerald-500" />
                  <h2 className="text-sm font-semibold text-slate-800">Déjà appelés ({alreadyCalledTenants.length})</h2>
                </div>
                <div className="text-sky-700 text-xs flex items-center gap-1">
                  <FileWarning className="w-3.5 h-3.5 text-amber-500" />
                  Cliquez sur "Avis d'échéance" pour notifier le locataire
                </div>
              </div>
              <div className="space-y-2">
                {alreadyCalledTenants.map((t) => {
              const pay = payments.find((p) => p.tenant_id === t.id && p.period_month === m && p.period_year === y);
              const statusColors = { paid: "zd-badge-paid", partial: "zd-badge-pending", pending: "zd-badge-pending", late: "zd-badge-late" };
              const statusLabels = { paid: "Payé", partial: "Partiel", pending: "En attente", late: "En retard" };
              return (
                <div key={t.id} className="bg-teal-50 p-3 rounded-lg flex items-center justify-between border border-slate-100 gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-700">{t.first_name} {t.last_name}</p>
                        <p className="text-xs text-slate-400">{t.property_name || "—"}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-sm font-medium text-slate-600">{formatXAF(t.rent_amount)} XAF</span>
                        {pay && <span className={statusColors[pay.status] || "zd-badge-pending"}>{statusLabels[pay.status] || pay.status}</span>}
                        {(() => {
                      const noticeState = noticedTenants[t.id];
                      const isPrinted = noticeState === 'printed';
                      const isClicked = !!noticeState;
                      return (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {markNoticed(t.id, noticedTenants[t.id] || 'clicked');setNoticeModal({ tenant: t, payment: pay });}}
                          className={`gap-1 text-xs transition-all ${
                          isPrinted ?
                          "bg-green-700 text-white border-green-700 hover:bg-green-800" :
                          isClicked ?
                          "text-amber-700 border-amber-300 hover:bg-amber-50" :
                          "text-amber-700 border-amber-300 hover:bg-amber-50 animate-pulse"}`
                          }>

                              <FileWarning className="w-3.5 h-3.5" />
                              {isPrinted ? "Avis envoyé ✓" : "Avis d'échéance"}
                            </Button>);

                    })()}
                      </div>
                    </div>);
            })}
              </div>
            </Card>
        }

          {/* Notice Modal */}
          {noticeModal &&
        <Dialog open={!!noticeModal} onOpenChange={() => {setNoticeModal(null);closeSendStep();}}>
              <DialogContent className="max-w-sm">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <FileWarning className="w-4 h-4 text-amber-500" />
                    Avis d'échéance — {noticeModal.tenant.first_name} {noticeModal.tenant.last_name}
                  </DialogTitle>
                </DialogHeader>

                {!sendStep ?
            <div className="py-3 space-y-3">
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
                      <strong>Période :</strong> {MONTHS[m - 1]} {y}<br />
                      <strong>Montant :</strong> {formatXAF(noticeModal.payment?.expected_amount || noticeModal.tenant.rent_amount)} XAF<br />
                      <strong>Échéance :</strong> 5 {MONTHS[m - 1]} {y}
                    </div>
                    <p className="text-sm text-slate-500">Choisissez le mode d'envoi :</p>
                    <div className="flex flex-col gap-2">
                      <Button
                  onClick={() => openSendStep('email', noticeModal.tenant)}
                  className="justify-start gap-2 bg-blue-600 hover:bg-blue-700">

                        <Mail className="w-4 h-4" /> Envoyer par Email
                      </Button>
                      <Button
                  onClick={() => openSendStep('whatsapp', noticeModal.tenant)}
                  className="justify-start gap-2 bg-green-600 hover:bg-green-700">

                        <MessageCircle className="w-4 h-4" /> Envoyer via WhatsApp
                      </Button>
                      <Button
                  variant="outline"
                  onClick={() => {printNotice(noticeModal.tenant, noticeModal.payment);setNoticeModal(null);}}
                  className="justify-start gap-2 border-slate-300 hover:bg-slate-50">

                        <Printer className="w-4 h-4" /> Imprimer / PDF
                      </Button>
                    </div>
                  </div> :

            <div className="py-3 space-y-3">
                    <button onClick={closeSendStep} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-700">
                      <ArrowLeft className="w-3.5 h-3.5" /> Retour
                    </button>
                    {sendStep === 'whatsapp' ?
              <>
                        <p className="text-sm font-medium text-slate-700">Numéro WhatsApp du locataire</p>
                        <p className="text-xs text-slate-400">Saisissez le numéro avec l'indicatif pays (ex : +24177...)</p>
                        <Input
                  value={sendContact}
                  onChange={(e) => setSendContact(e.target.value)}
                  placeholder="+241 77 00 00 00"
                  type="tel" />

                        <Button
                  className="w-full bg-green-600 hover:bg-green-700 gap-2"
                  disabled={!sendContact.trim()}
                  onClick={() => sendNoticeWhatsApp(noticeModal.tenant, noticeModal.payment, sendContact)}>

                          <MessageCircle className="w-4 h-4" /> Ouvrir WhatsApp
                        </Button>
                      </> :

              <>
                        <p className="text-sm font-medium text-slate-700">Adresse email du locataire</p>
                        <p className="text-xs text-slate-400">Vérifiez ou modifiez l'email avant l'envoi</p>
                        <Input
                  value={sendContact}
                  onChange={(e) => setSendContact(e.target.value)}
                  placeholder="email@exemple.com"
                  type="email" />

                        <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
                  disabled={!sendContact.trim()}
                  onClick={() => sendNoticeEmail(noticeModal.tenant, noticeModal.payment, sendContact)}>

                          <Mail className="w-4 h-4" /> Envoyer l'email
                        </Button>
                      </>
              }
                  </div>
            }

                <DialogFooter>
                  <Button variant="outline" onClick={() => {setNoticeModal(null);closeSendStep();}}>Fermer</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
        }
        </>
      }
    </div>);

}