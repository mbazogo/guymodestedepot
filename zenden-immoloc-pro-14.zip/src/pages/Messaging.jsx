import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Mail, MessageSquare, Send, FileText, AlertCircle, Receipt, ChevronRight, Search, User, Printer } from "lucide-react";

const TEMPLATES = [
{
  id: "quittance",
  label: "Quittance de loyer",
  icon: Receipt,
  color: "emerald",
  subject: "Quittance de loyer – {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Nous vous adressons ci-joint votre quittance de loyer pour le mois de {mois} {annee}.

Montant du loyer : {loyer} XAF
Bien : {bien}

Nous vous remercions pour votre paiement.

Cordialement,
{societe}`
},
{
  id: "avis_echeance",
  label: "Avis d'échéance",
  icon: AlertCircle,
  color: "amber",
  subject: "Avis d'échéance de loyer – {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Nous vous rappelons que votre loyer du mois de {mois} {annee} est à régler avant le {jour_echeance}.

Montant à régler : {loyer} XAF
Bien : {bien}

Merci de procéder au règlement dans les délais.

Cordialement,
{societe}`
},
{
  id: "relance",
  label: "Relance impayé",
  icon: AlertCircle,
  color: "red",
  subject: "Relance – Loyer impayé {mois} {annee}",
  body: `Bonjour {civilite} {nom},

Sauf erreur de notre part, nous n'avons pas reçu votre loyer du mois de {mois} {annee}.

Montant dû : {loyer} XAF
Bien : {bien}

Nous vous demandons de régulariser votre situation dans les plus brefs délais.

Cordialement,
{societe}`
},
{
  id: "conge",
  label: "Congé / Résiliation de bail",
  icon: FileText,
  color: "violet",
  subject: "Notification de résiliation de bail",
  body: `Bonjour {civilite} {nom},

Nous vous informons que votre bail concernant le bien {bien} arrivera à échéance.

Nous vous demandons de bien vouloir libérer les lieux à la date de fin de bail et de nous remettre les clés.

Pour toute question, n'hésitez pas à nous contacter.

Cordialement,
{societe}`
},
{
  id: "libre",
  label: "Message libre",
  icon: Mail,
  color: "blue",
  subject: "",
  body: ""
}];


const MONTHS = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

function fillTemplate(text, tenant, settings) {
  const now = new Date();
  return text.
  replace(/{civilite}/g, tenant?.civility || "").
  replace(/{nom}/g, `${tenant?.first_name || ""} ${tenant?.last_name || ""}`.trim()).
  replace(/{loyer}/g, new Intl.NumberFormat("fr-FR").format(tenant?.rent_amount || 0)).
  replace(/{bien}/g, tenant?.property_name || "").
  replace(/{mois}/g, MONTHS[now.getMonth()]).
  replace(/{annee}/g, now.getFullYear()).
  replace(/{jour_echeance}/g, settings?.payment_day || "1").
  replace(/{societe}/g, settings?.company_name || "");
}

export default function Messaging() {
  const [search, setSearch] = useState("");
  const [selectedTenant, setSelectedTenant] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const activeTenants = tenants.filter((t) => t.status === "active");
  const filtered = activeTenants.filter((t) =>
  `${t.first_name} ${t.last_name} ${t.property_name}`.toLowerCase().includes(search.toLowerCase())
  );

  const selectTemplate = (tpl) => {
    setSelectedTemplate(tpl);
    if (selectedTenant) {
      setSubject(fillTemplate(tpl.subject, selectedTenant, settings));
      setBody(fillTemplate(tpl.body, selectedTenant, settings));
    } else {
      setSubject(tpl.subject);
      setBody(tpl.body);
    }
    setSent(false);
  };

  const selectTenant = (tenant) => {
    setSelectedTenant(tenant);
    if (selectedTemplate) {
      setSubject(fillTemplate(selectedTemplate.subject, tenant, settings));
      setBody(fillTemplate(selectedTemplate.body, tenant, settings));
    }
    setSent(false);
  };

  const handleSendEmail = async () => {
    if (!selectedTenant?.email) return alert("Ce locataire n'a pas d'adresse email.");
    if (!subject || !body) return alert("Veuillez saisir un objet et un message.");
    setSending(true);
    await base44.integrations.Core.SendEmail({
      to: selectedTenant.email,
      subject,
      body: body.replace(/\n/g, "<br/>")
    });
    setSending(false);
    setSent(true);
  };

  const handlePrint = () => {
    if (!subject && !body) return alert("Veuillez saisir un objet et un message.");
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const ownerName = settings?.owner_name || companyName;
    const today = new Date().toLocaleDateString("fr-FR");
    const tenant = selectedTenant;

    const logoHtml = settings?.logo_url ?
    `<img src="${settings.logo_url}" style="height:56px;object-fit:contain;display:block;margin-bottom:6px;" crossorigin="anonymous" />` :
    `<div style="font-size:20px;font-weight:bold;color:#0f2b4c;">${companyName}</div>`;

    const signatureHtml = settings?.signature_url ?
    `<div style="margin-bottom:6px;"><img src="${settings.signature_url}" style="height:60px;object-fit:contain;" crossorigin="anonymous" /></div>` :
    `<div style="height:60px;"></div>`;

    const html = `<html><head><title>${subject || "Courrier"}</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 50px; color: #1e293b; font-size: 12pt; }
      .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f2b4c; padding-bottom: 16px; margin-bottom: 32px; }
      .company-sub { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 2px; margin-top:2px; }
      .ref { text-align: right; font-size: 11px; color: #64748b; line-height: 1.8; }
      .title { text-align: center; margin: 28px 0; }
      .title h1 { font-size: 16px; font-weight: bold; text-transform: uppercase; color: #0f2b4c; display: inline-block; border: 2px solid #0f2b4c; padding: 6px 20px; }
      .content { white-space: pre-wrap; font-size: 12pt; line-height: 1.8; margin: 24px 0; }
      .footer { margin-top: 60px; display: flex; justify-content: flex-end; }
      .sig-block { text-align: center; }
      .sig-name { border-top: 1px solid #1e293b; padding-top: 6px; font-size: 11px; font-weight: bold; color: #0f2b4c; min-width: 200px; }
      .sig-title { font-size: 10px; color: #64748b; }
      .legal { text-align: center; font-size: 9px; color: #94a3b8; margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 10px; }
      @media print { body { padding: 30px; } }
    </style></head><body>
    <div class="header">
      <div>
        ${logoHtml}
        <div class="company-sub">Gestion locative</div>
      </div>
      <div class="ref">
        <div><strong>Date :</strong> ${today}</div>
        ${tenant ? `<div><strong>Destinataire :</strong> ${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}</div>` : ""}
        ${tenant?.property_name ? `<div><strong>Bien :</strong> ${tenant.property_name}</div>` : ""}
        ${settings?.owner_address ? `<div>${settings.owner_address}</div>` : ""}
        ${settings?.owner_phone ? `<div>Tél : ${settings.owner_phone}</div>` : ""}
      </div>
    </div>
    <div class="title"><h1>${subject || "Courrier"}</h1></div>
    <div class="content">${(body || "").replace(/\n/g, "<br/>")}</div>
    <div class="footer">
      <div class="sig-block">
        ${signatureHtml}
        <div class="sig-name">${ownerName}</div>
        <div class="sig-title">Le Bailleur</div>
      </div>
    </div>
    <div class="legal">Document généré par ${companyName} • ${today}</div>
    </body></html>`;
    const w = window.open("", "_blank");
    w.document.write(html);
    w.document.close();
    w.print();
  };

  const handleWhatsApp = () => {
    if (!selectedTenant?.phone) return alert("Ce locataire n'a pas de numéro de téléphone.");
    const phone = selectedTenant.phone.replace(/[^0-9]/g, "");
    const msg = encodeURIComponent(body || subject);
    window.open(`https://wa.me/${phone}?text=${msg}`, "_blank");
  };

  const colorMap = { emerald: "bg-emerald-100 text-emerald-700", amber: "bg-amber-100 text-amber-700", red: "bg-red-100 text-red-700", violet: "bg-violet-100 text-violet-700", blue: "bg-blue-100 text-blue-700" };
  const iconColorMap = { emerald: "bg-emerald-500", amber: "bg-amber-500", red: "bg-red-500", violet: "bg-violet-500", blue: "bg-blue-500" };

  return (
    <div className="space-y-5 max-w-6xl">
      <div>
        <h1 className="text-teal-600 text-xl font-bold">Messagerie</h1>
        <p className="text-sm text-slate-500">Communiquez avec vos locataires par email ou WhatsApp</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: tenant + template selection */}
        <div className="space-y-4">
          {/* Tenant selector */}
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4">
            <h2 className="text-blue-700 mb-3 text-sm font-semibold flex items-center gap-2">Choisir le Locataire</h2>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <Input placeholder="Rechercher..." className="pl-8 h-8 text-sm" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="space-y-1 max-h-56 overflow-y-auto">
              {filtered.map((t) =>
              <button
                key={t.id}
                onClick={() => selectTenant(t)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all flex items-center justify-between ${selectedTenant?.id === t.id ? "bg-teal-50 text-teal-700 font-medium" : "hover:bg-slate-50 text-slate-700"}`}>

                  <div>
                    <p className="font-medium">{t.civility} {t.first_name} {t.last_name}</p>
                    <p className="text-xs text-slate-400">{t.property_name}</p>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
                </button>
              )}
              {filtered.length === 0 && <p className="text-xs text-slate-400 text-center py-4">Aucun locataire actif</p>}
            </div>
          </div>

          {/* Templates */}
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4">
            <h2 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400" /> Modèles</h2>
            <div className="space-y-1.5">
              {TEMPLATES.map((tpl) => {
                const Icon = tpl.icon;
                return (
                  <button
                    key={tpl.id}
                    onClick={() => selectTemplate(tpl)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all flex items-center gap-3 border ${selectedTemplate?.id === tpl.id ? "border-teal-300 bg-teal-50" : "border-transparent hover:bg-slate-50"}`}>

                    <div className={`w-7 h-7 rounded-lg ${iconColorMap[tpl.color]} flex items-center justify-center shrink-0`}>
                      <Icon className="w-3.5 h-3.5 text-white" />
                    </div>
                    <span className="font-medium text-slate-700">{tpl.label}</span>
                  </button>);

              })}
            </div>
          </div>
        </div>

        {/* Right: compose */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-100 shadow-sm p-5 flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-slate-700 flex items-center gap-2"><Mail className="w-4 h-4 text-slate-400" /> Composer le message</h2>

          {selectedTenant &&
          <div className="bg-teal-50 rounded-lg px-4 py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-teal-500 flex items-center justify-center text-white text-xs font-bold">
                {selectedTenant.first_name?.[0]}{selectedTenant.last_name?.[0]}
              </div>
              <div>
                <p className="text-sm font-semibold text-teal-800">{selectedTenant.civility} {selectedTenant.first_name} {selectedTenant.last_name}</p>
                <p className="text-xs text-teal-600">{selectedTenant.email || "Pas d'email"} {selectedTenant.phone ? `• ${selectedTenant.phone}` : ""}</p>
              </div>
            </div>
          }

          {!selectedTenant &&
          <div className="flex-1 flex items-center justify-center text-slate-400 text-sm py-8">
              Sélectionnez un locataire et un modèle pour commencer
            </div>
          }

          {selectedTenant &&
          <>
              <div>
                <Label className="text-xs text-slate-500 mb-1 block">Objet</Label>
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Objet du message" className="text-sm" />
              </div>
              <div className="flex-1">
                <Label className="text-xs text-slate-500 mb-1 block">Message</Label>
                <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Rédigez votre message..."
                className="text-sm min-h-[260px] resize-none" />

              </div>

              {sent &&
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg px-4 py-2.5 flex items-center gap-2">
                  <Send className="w-4 h-4" /> Email envoyé avec succès !
                </div>
            }

              <div className="flex flex-wrap gap-3 pt-1">
                <Button
                onClick={handleSendEmail}
                disabled={sending || !selectedTenant.email}
                className="bg-[#0f2b4c] hover:bg-[#1a3d6e] gap-2">

                  <Mail className="w-4 h-4" /> {sending ? "Envoi..." : "Envoyer par Email"}
                </Button>
                <Button
                onClick={handleWhatsApp}
                disabled={!selectedTenant.phone}
                className="bg-[#25D366] hover:bg-[#20be5b] text-white gap-2">

                  <MessageSquare className="w-4 h-4" /> WhatsApp
                </Button>
                <Button
                onClick={handlePrint}
                variant="outline"
                className="gap-2">

                  <Printer className="w-4 h-4" /> Imprimer / PDF
                </Button>
                {!selectedTenant.email && <p className="text-xs text-red-500 self-center">Aucun email renseigné</p>}
                {!selectedTenant.phone && <p className="text-xs text-red-500 self-center">Aucun téléphone renseigné</p>}
              </div>
            </>
          }
        </div>
      </div>
    </div>);

}