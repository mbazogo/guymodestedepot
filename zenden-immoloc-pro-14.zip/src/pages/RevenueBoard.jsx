import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Wallet, TrendingUp, TrendingDown, Building2 } from "lucide-react";
import StatCard from "../components/dashboard/StatCard";
import { Skeleton } from "@/components/ui/skeleton";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const MONTHS = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];
const COLORS = ["#10b981", "#3b82f6", "#8b5cf6", "#f59e0b", "#ef4444", "#ec4899", "#06b6d4", "#84cc16"];

export default function RevenueBoard() {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  const [year, setYear] = useState(String(currentYear));

  const { data: payments = [], isLoading: lp } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: charges = [], isLoading: lc } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });

  const isLoading = lp || lc;
  const y = Number(year);

  const yearPayments = payments.filter((p) => p.period_year === y && (p.status === "paid" || p.status === "partial"));
  const yearCharges = charges.filter((c) => new Date(c.date).getFullYear() === y);

  const totalRevenue = yearPayments.reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpense = yearCharges.reduce((s, c) => s + (c.amount || 0), 0);
  const monthRevenue = yearPayments.filter((p) => p.period_month === currentMonth).reduce((s, p) => s + (p.amount || 0), 0);

  // Per-tenant annual
  const tenantAnnual = tenants.filter((t) => t.status === "active").map((t) => {
    const paid = yearPayments.filter((p) => p.tenant_id === t.id).reduce((s, p) => s + (p.amount || 0), 0);
    const expected = (t.rent_amount || 0) * (y === currentYear ? currentMonth : 12);
    return { name: `${t.first_name} ${t.last_name}`, paid, expected, percent: expected > 0 ? Math.round(paid / expected * 100) : 0, property: t.property_name };
  });

  // Revenue by property for pie
  const revenueByProperty = {};
  yearPayments.forEach((p) => {
    revenueByProperty[p.property_name || "Autre"] = (revenueByProperty[p.property_name || "Autre"] || 0) + (p.amount || 0);
  });
  const pieData = Object.entries(revenueByProperty).map(([name, value]) => ({ name, value }));

  // Monthly comparison
  const monthlyData = MONTHS.map((m, i) => ({
    name: m,
    revenus: yearPayments.filter((p) => p.period_month === i + 1).reduce((s, p) => s + (p.amount || 0), 0),
    depenses: yearCharges.filter((c) => new Date(c.date).getMonth() === i).reduce((s, c) => s + (c.amount || 0), 0)
  }));

  if (isLoading) return <div className="space-y-4">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="bg-emerald-50 text-emerald-600 text-xl font-bold">Encaissements</h1>
          <p className="text-sm text-slate-500">Suivi détaillé des encaissements</p>
        </div>
        <Select value={year} onValueChange={setYear}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[currentYear, currentYear - 1, currentYear - 2].map((y) =>
            <SelectItem key={y} value={String(y)}>{y}</SelectItem>
            )}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Revenus du mois" value={`${formatXAF(monthRevenue)} XAF`} icon={Wallet} color="emerald" />
        <StatCard title="Cumul annuel" value={`${formatXAF(totalRevenue)} XAF`} icon={TrendingUp} color="blue" />
        <StatCard title="Dépenses annuelles" value={`${formatXAF(totalExpense)} XAF`} icon={TrendingDown} color="red" />
        <StatCard title="Résultat net" value={`${formatXAF(totalRevenue - totalExpense)} XAF`} icon={Building2} color={totalRevenue - totalExpense >= 0 ? "emerald" : "red"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly chart */}
        <Card className="lg:col-span-2 p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Revenus vs Dépenses mensuels</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={(v) => v / 1000 + "k"} />
              <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "10px", border: "1px solid #e2e8f0", fontSize: "12px" }} />
              <Bar dataKey="revenus" name="Revenus" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="depenses" name="Dépenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Pie */}
        <Card className="p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Revenus par bien</h3>
          {pieData.length > 0 ?
          <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "10px", border: "1px solid #e2e8f0", fontSize: "12px" }} />
              </PieChart>
            </ResponsiveContainer> :

          <p className="text-sm text-slate-400 text-center py-12">Pas de données</p>
          }
          <div className="space-y-1.5 mt-2">
            {pieData.map((d, i) =>
            <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-slate-600">{d.name}</span>
                </div>
                <span className="font-medium">{formatXAF(d.value)} XAF</span>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Per tenant - two panels side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Récapitulatif mensuel */}
        <Card className="p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Récapitulatif loyers encaissés — {MONTHS[currentMonth - 1]} {y}</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 text-slate-500">Locataire</th>
                  <th className="text-left py-2 text-slate-500">Bien</th>
                  <th className="text-right py-2 text-slate-500">Attendu</th>
                  <th className="text-right py-2 text-slate-500">Encaissé</th>
                  <th className="text-right py-2 text-slate-500">Statut</th>
                </tr>
              </thead>
              <tbody>
                {tenantAnnual.map((t, i) => {
                  const monthPay = payments.filter((p) => p.tenant_id === tenants.find((tn) => `${tn.first_name} ${tn.last_name}` === t.name)?.id && p.period_month === currentMonth && p.period_year === y && (p.status === "paid" || p.status === "partial")).reduce((s, p) => s + (p.amount || 0), 0);
                  const monthExpected = tenants.find((tn) => `${tn.first_name} ${tn.last_name}` === t.name)?.rent_amount || 0;
                  const ok = monthPay >= monthExpected && monthExpected > 0;
                  return (
                    <tr key={i} className="border-b border-slate-50">
                      <td className="py-2 font-medium text-slate-700">{t.name}</td>
                      <td className="py-2 text-slate-500">{t.property}</td>
                      <td className="py-2 text-right">{formatXAF(monthExpected)}</td>
                      <td className="py-2 text-right font-semibold text-emerald-700">{formatXAF(monthPay)}</td>
                      <td className="py-2 text-right">
                        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${ok ? "bg-emerald-100 text-emerald-700" : monthPay > 0 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
                          {ok ? "Payé" : monthPay > 0 ? "Partiel" : "Non payé"}
                        </span>
                      </td>
                    </tr>);

                })}
                {tenantAnnual.length === 0 && <tr><td colSpan={5} className="text-center py-6 text-slate-400">Aucun locataire actif</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Cumul annuel */}
        <Card className="p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Cumul annuel par locataire — {y}</h3>
          <div className="space-y-4">
            {tenantAnnual.map((t, i) =>
            <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="font-medium text-slate-700">{t.name}</span>
                    <span className="text-slate-400 ml-2">({t.property})</span>
                  </div>
                  <span className="text-slate-600">{formatXAF(t.paid)} / {formatXAF(t.expected)} XAF</span>
                </div>
                <div className="flex items-center gap-2">
                  <Progress value={t.percent} className="h-2 flex-1" />
                  <span className={`text-xs font-bold ${t.percent >= 80 ? "text-emerald-600" : t.percent >= 50 ? "text-amber-600" : "text-red-600"}`}>
                    {t.percent}%
                  </span>
                </div>
              </div>
            )}
            {tenantAnnual.length === 0 && <p className="text-sm text-slate-400 text-center py-6">Aucun locataire actif</p>}
          </div>
        </Card>
      </div>
    </div>);

}