import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Wallet, TrendingUp, AlertTriangle, Building2, CreditCard, FileText } from "lucide-react";
import StatCard from "../components/dashboard/StatCard";
import KpiStrip from "../components/dashboard/KpiStrip";
import OccupancyWidget from "../components/dashboard/OccupancyWidget";
import UnpaidRentWidget from "../components/dashboard/UnpaidRentWidget";
import MonthlyRevenueChart from "../components/dashboard/MonthlyRevenueChart";
import RevenueChart from "../components/dashboard/RevenueChart";
import TenantProgress from "../components/dashboard/TenantProgress";
import LatestPayments from "../components/dashboard/LatestPayments";
import DueAlerts from "../components/dashboard/DueAlerts";
import RentRevisionAlert from "../components/dashboard/RentRevisionAlert";
import FiscalYearBanner from "../components/dashboard/FiscalYearBanner";
import UrgentReminders from "../components/dashboard/UrgentReminders";
import LeasesSummary from "../components/dashboard/LeasesSummary";
import DemoDataBanner from "../components/dashboard/DemoDataBanner";
import { Skeleton } from "@/components/ui/skeleton";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

function formatXAF(value) {
  return new Intl.NumberFormat("fr-FR").format(value || 0);
}

export default function Dashboard() {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const { data: properties = [], isLoading: loadingProps } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list()
  });

  const { data: tenants = [], isLoading: loadingTenants } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list()
  });

  const { data: payments = [], isLoading: loadingPayments } = useQuery({
    queryKey: ["payments"],
    queryFn: () => base44.entities.Payment.list()
  });

  const { data: charges = [], isLoading: loadingCharges } = useQuery({
    queryKey: ["charges"],
    queryFn: () => base44.entities.Charge.list()
  });

  const { data: leases = [], isLoading: loadingLeases } = useQuery({
    queryKey: ["leases"],
    queryFn: () => base44.entities.Lease.list()
  });

  const isLoading = loadingProps || loadingTenants || loadingPayments || loadingCharges || loadingLeases;

  // Calculations
  const monthRevenue = payments.
  filter((p) => p.period_year === currentYear && p.period_month === currentMonth && (p.status === "paid" || p.status === "partial")).
  reduce((sum, p) => sum + (p.amount || 0), 0);

  const yearRevenue = payments.
  filter((p) => p.period_year === currentYear && (p.status === "paid" || p.status === "partial")).
  reduce((sum, p) => sum + (p.amount || 0), 0);

  const yearExpenses = charges.
  filter((c) => new Date(c.date).getFullYear() === currentYear).
  reduce((sum, c) => sum + (c.amount || 0), 0);

  const monthExpenses = charges.
  filter((c) => new Date(c.date).getFullYear() === currentYear && new Date(c.date).getMonth() + 1 === currentMonth).
  reduce((sum, c) => sum + (c.amount || 0), 0);

  const latePayments = payments.filter((p) => p.status === "late");
  const pendingPayments = payments.filter((p) => p.status === "pending");
  const activeTenants = tenants.filter((t) => t.status === "active");

  // Expected monthly revenue = sum of rent_amount of active tenants
  const expectedMonthRevenue = activeTenants.reduce((sum, t) => sum + (t.rent_amount || 0), 0);
  const collectedPercent = expectedMonthRevenue > 0 ? Math.round(monthRevenue / expectedMonthRevenue * 100) : 0;

  // Baux à réviser : expirent dans les 2 prochains mois ou actifs depuis > 12 mois sans date de fin
  const today = new Date();
  const in2months = new Date(today);
  in2months.setMonth(in2months.getMonth() + 2);
  const leasesToRevise = leases.filter((l) => {
    if (l.status !== "active") return false;
    if (l.end_date) {
      const end = new Date(l.end_date);
      return end >= today && end <= in2months;
    }
    if (l.start_date) {
      const start = new Date(l.start_date);
      const months = (today.getFullYear() - start.getFullYear()) * 12 + (today.getMonth() - start.getMonth());
      return months >= 12;
    }
    return false;
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) =>
          <Skeleton key={i} className="h-28 rounded-xl" />
          )}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Skeleton className="h-80 rounded-xl col-span-2" />
          <Skeleton className="h-80 rounded-xl" />
        </div>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-teal-600 mx-1 text-3xl font-bold">Tableau de bord</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Vue d'ensemble de votre patrimoine immobilier
        </p>
      </div>

      {/* Demo data banner */}
      <DemoDataBanner properties={properties} />

      {/* KPI Strip — real-time */}
      <KpiStrip properties={properties} tenants={tenants} payments={payments} leases={leases} />

      {/* Fiscal Year Banner */}
      <FiscalYearBanner payments={payments} charges={charges} currentYear={currentYear} />

      {/* Rent revision alert */}
      <RentRevisionAlert tenants={tenants} leases={leases} />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Revenus du mois"
          value={`${formatXAF(monthRevenue)} XAF`}
          icon={Wallet}
          color="emerald"
          subtitle={`Attendu: ${formatXAF(expectedMonthRevenue)} XAF`} />

        <StatCard
          title="Cumul annuel"
          value={`${formatXAF(yearRevenue)} XAF`}
          icon={TrendingUp}
          color="blue"
          subtitle={`Net: ${formatXAF(yearRevenue - yearExpenses)} XAF`} />

        <StatCard
          title="Charges du mois"
          value={`${formatXAF(monthExpenses)} XAF`}
          icon={CreditCard}
          color="red"
          subtitle={`Cumul annuel: ${formatXAF(yearExpenses)} XAF`} />

        <StatCard
          title="Biens / Locataires"
          value={`${properties.length} / ${activeTenants.length}`}
          icon={Building2}
          color="violet"
          subtitle={`${properties.filter((p) => p.status === "vacant").length} vacant(s)`} />
      </div>

      {/* Revenue collection indicator */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-500" /> Taux de collecte du mois
          </h3>
          <span className={`text-lg font-bold ${collectedPercent >= 80 ? "text-emerald-600" : collectedPercent >= 50 ? "text-amber-600" : "text-red-600"}`}>
            {collectedPercent}%
          </span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-3">
          <div
            className={`h-3 rounded-full transition-all duration-500 ${collectedPercent >= 80 ? "bg-emerald-500" : collectedPercent >= 50 ? "bg-amber-500" : "bg-red-500"}`}
            style={{ width: `${Math.min(collectedPercent, 100)}%` }} />

        </div>
        <div className="flex justify-between text-xs text-slate-400 mt-1.5">
          <span>Collecté : {formatXAF(monthRevenue)} XAF</span>
          <span>Attendu : {formatXAF(expectedMonthRevenue)} XAF</span>
        </div>
      </div>

      {/* Paiements status */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
          <Wallet className="w-4 h-4 text-emerald-500" /> Statuts des paiements
        </h3>
        <div className="grid grid-cols-4 gap-2">
          {[
          { label: "Payés", count: payments.filter((p) => p.status === "paid").length, color: "emerald" },
          { label: "En attente", count: payments.filter((p) => p.status === "pending").length, color: "amber" },
          { label: "En retard", count: payments.filter((p) => p.status === "late").length, color: "red" },
          { label: "Partiel", count: payments.filter((p) => p.status === "partial").length, color: "blue" }].
          map(({ label, count, color }) =>
          <div key={label} className={`bg-${color}-50 rounded-lg p-3 text-center`}>
              <p className="text-emerald-700 text-lg font-bold">{count}</p>
              <p className={`text-xs text-${color}-600 mt-0.5`}>{label}</p>
            </div>
          )}
        </div>
      </div>

      {/* Baux à réviser */}
      {leasesToRevise.length > 0 &&
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-400 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-amber-800">
                {leasesToRevise.length} bail{leasesToRevise.length > 1 ? "x" : ""} à réviser
              </p>
              <p className="text-xs text-amber-600">
                {leasesToRevise.map((l) => l.tenant_name || l.property_name).join(", ")}
              </p>
            </div>
          </div>
          <Link
          to={createPageUrl("Leases")}
          className="text-xs font-semibold text-amber-700 hover:text-amber-900 bg-amber-100 hover:bg-amber-200 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap">
            Voir les baux →
          </Link>
        </div>
      }

      {/* New widgets row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <OccupancyWidget properties={properties} />
        <UnpaidRentWidget payments={payments} tenants={tenants} />
        <MonthlyRevenueChart payments={payments} year={currentYear} />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <RevenueChart payments={payments} charges={charges} year={currentYear} />
        </div>
        <TenantProgress tenants={tenants} payments={payments} year={currentYear} />
      </div>

      {/* Baux summary + Urgent reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <LeasesSummary leases={leases} />
        <UrgentReminders />
      </div>

      {/* Alerts + Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <LatestPayments payments={payments} />
        </div>
        <DueAlerts latePayments={latePayments} pendingPayments={pendingPayments} />
      </div>
    </div>);

}