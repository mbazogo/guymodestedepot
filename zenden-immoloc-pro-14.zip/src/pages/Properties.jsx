import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Pencil, Trash2, Building2, Search, MapPin, Home, ChevronRight, Archive } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import ArchiveButton from "../components/archive/ArchiveButton";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const typeLabels = {
  appartement: "Appartement", maison: "Maison", studio: "Studio",
  local_commercial: "Local commercial", parking: "Parking", autre: "Autre"
};
const buildingTypeLabels = { immeuble: "Immeuble", maison: "Maison", villa: "Villa", residence: "Résidence", autre: "Autre" };
const statusColors = { occupied: "bg-emerald-100 text-emerald-700", vacant: "bg-amber-100 text-amber-700", maintenance: "bg-red-100 text-red-700" };
const statusLabels = { occupied: "Occupé", vacant: "Vacant", maintenance: "En travaux" };

const emptyProperty = { name: "", address: "", city: "", type: "appartement", building_id: "", surface: "", rooms: "", furnished: false, rent_amount: "", charges_amount: "", status: "vacant", notes: "", tantiemes: "" };
const emptyBuilding = { name: "", address: "", city: "", type: "immeuble", floors: "", total_units: "", notes: "" };

export default function Properties() {
  const [tab, setTab] = useState("biens");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [buildingDialogOpen, setBuildingDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyProperty);
  const [buildingForm, setBuildingForm] = useState(emptyBuilding);
  const [editingId, setEditingId] = useState(null);
  const [editingBuildingId, setEditingBuildingId] = useState(null);
  const [search, setSearch] = useState("");
  const qc = useQueryClient();

  const { data: properties = [], isLoading } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: buildings = [], isLoading: lb } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId ? base44.entities.Property.update(editingId, data) : base44.entities.Property.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["properties"] });setDialogOpen(false);setForm(emptyProperty);setEditingId(null);}
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Property.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["properties"] })
  });

  const saveBuildingMutation = useMutation({
    mutationFn: (data) => editingBuildingId ? base44.entities.Building.update(editingBuildingId, data) : base44.entities.Building.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["buildings"] });setBuildingDialogOpen(false);setBuildingForm(emptyBuilding);setEditingBuildingId(null);}
  });

  const deleteBuildingMutation = useMutation({
    mutationFn: (id) => base44.entities.Building.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["buildings"] })
  });

  const [showArchived, setShowArchived] = useState(false);

  const archiveMutation = useMutation({
    mutationFn: ({ id, archived }) => base44.entities.Property.update(id, { archived }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["properties"] })
  });

  const openEdit = (p) => {setForm({ ...p });setEditingId(p.id);setDialogOpen(true);};
  const openNew = () => {setForm(emptyProperty);setEditingId(null);setDialogOpen(true);};
  const openEditBuilding = (b) => {setBuildingForm({ ...b });setEditingBuildingId(b.id);setBuildingDialogOpen(true);};
  const openNewBuilding = () => {setBuildingForm(emptyBuilding);setEditingBuildingId(null);setBuildingDialogOpen(true);};

  const handleSave = () => {
    const building = buildings.find((b) => b.id === form.building_id);
    saveMutation.mutate({
      ...form,
      building_name: building?.name || "",
      rent_amount: Number(form.rent_amount) || 0,
      charges_amount: Number(form.charges_amount) || 0,
      surface: Number(form.surface) || 0,
      rooms: Number(form.rooms) || 0,
      tantiemes: Number(form.tantiemes) || 0
    });
  };

  const handleSaveBuilding = () => {
    saveBuildingMutation.mutate({ ...buildingForm, floors: Number(buildingForm.floors) || 0, total_units: Number(buildingForm.total_units) || 0 });
  };

  const visibleProperties = properties.filter((p) => showArchived ? p.archived : !p.archived);
  const filtered = visibleProperties.filter((p) =>
  p.name?.toLowerCase().includes(search.toLowerCase()) ||
  p.address?.toLowerCase().includes(search.toLowerCase()) ||
  p.city?.toLowerCase().includes(search.toLowerCase()) ||
  p.building_name?.toLowerCase().includes(search.toLowerCase())
  );

  const filteredBuildings = buildings.filter((b) =>
  b.name?.toLowerCase().includes(search.toLowerCase()) ||
  b.address?.toLowerCase().includes(search.toLowerCase()) ||
  b.city?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-teal-600 text-xl font-bold">Biens immobiliers</h1>
          <p className="text-sm text-slate-500">
            {properties.length} bien(s) ·{" "}
            <span className="text-emerald-600 font-medium">{properties.filter((p) => p.status === "occupied").length} occupé(s)</span>
            {" · "}
            <span className="text-amber-600 font-medium">{properties.filter((p) => p.status === "vacant").length} vacant(s)</span>
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowArchived(!showArchived)} className={showArchived ? "border-amber-300 text-amber-700 bg-amber-50" : ""}>
            <Archive className="w-4 h-4 mr-2" /> {showArchived ? "Vue archivés" : "Archives"}
          </Button>
          {!showArchived &&
          <Button onClick={tab === "biens" ? openNew : openNewBuilding} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              <Plus className="w-4 h-4 mr-2" /> {tab === "biens" ? "Ajouter un bien" : "Ajouter un bâtiment"}
            </Button>
          }
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="biens">Lots / Biens</TabsTrigger>
            <TabsTrigger value="batiments">Immeubles & Maisons</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* BIENS TAB */}
      {tab === "biens" && (
      isLoading ?
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div> :
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) =>
        <Card key={p.id} className="p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-slate-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-sm">{p.name}</h3>
                    <p className="text-xs text-slate-500">{typeLabels[p.type] || p.type}</p>
                    {p.building_name &&
                <p className="text-xs text-blue-500 flex items-center gap-1">
                        <Home className="w-3 h-3" />{p.building_name}
                      </p>
                }
                  </div>
                </div>
                <Badge className={`${statusColors[p.status]} text-[10px]`}>{statusLabels[p.status]}</Badge>
              </div>
              {p.address &&
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-3">
                  <MapPin className="w-3 h-3" />
                  <span>{p.address}{p.city ? `, ${p.city}` : ""}</span>
                </div>
          }
              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <div>
                  <p className="text-slate-600 text-sm font-bold">{formatXAF(p.rent_amount)} XAF</p>
                  <p className="text-[10px] text-slate-400">Loyer mensuel</p>
                </div>
                <div className="flex gap-1">
                  {!p.archived && <Button size="icon" variant="ghost" onClick={() => openEdit(p)}><Pencil className="w-4 h-4 text-slate-500" /></Button>}
                  <ArchiveButton item={p} onArchive={(id, archived) => archiveMutation.mutate({ id, archived })} />
                  {!p.archived &&
              <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ce bien ?")) deleteMutation.mutate(p.id);}}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
              }
                </div>
              </div>
            </Card>
        )}
          {filtered.length === 0 &&
        <div className="col-span-full text-center py-16 text-slate-400">
              <Building2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun bien trouvé</p>
            </div>
        }
        </div>)
      }

      {/* BATIMENTS TAB */}
      {tab === "batiments" && (
      lb ?
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div> :
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBuildings.map((b) => {
          const units = properties.filter((p) => p.building_id === b.id);
          const occupied = units.filter((p) => p.status === "occupied").length;
          return (
            <Card key={b.id} className="p-5 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                      <Home className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 text-sm">{b.name}</h3>
                      <p className="text-xs text-slate-500">{buildingTypeLabels[b.type] || b.type}</p>
                    </div>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700 text-[10px]">{units.length} lot(s)</Badge>
                </div>
                {b.address &&
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-3">
                    <MapPin className="w-3 h-3" />
                    <span>{b.address}{b.city ? `, ${b.city}` : ""}</span>
                  </div>
              }
                {units.length > 0 &&
              <div className="mb-3 space-y-1">
                    {units.slice(0, 4).map((u) =>
                <div key={u.id} className="flex items-center justify-between text-xs text-slate-600 px-2 py-1 bg-slate-50 rounded">
                        <span className="flex items-center gap-1"><ChevronRight className="w-3 h-3" />{u.name}</span>
                        <Badge className={`${statusColors[u.status]} text-[9px] py-0`}>{statusLabels[u.status]}</Badge>
                      </div>
                )}
                    {units.length > 4 && <p className="text-xs text-slate-400 pl-2">+{units.length - 4} autre(s)...</p>}
                  </div>
              }
                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <p className="text-xs text-slate-500">{occupied}/{units.length} occupé(s)</p>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => openEditBuilding(b)}><Pencil className="w-4 h-4 text-slate-500" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ce bâtiment ?")) deleteBuildingMutation.mutate(b.id);}}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </Card>);

        })}
          {filteredBuildings.length === 0 &&
        <div className="col-span-full text-center py-16 text-slate-400">
              <Home className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun bâtiment trouvé. Créez votre premier immeuble ou maison.</p>
            </div>
        }
        </div>)
      }

      {/* Property Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le bien" : "Nouveau bien"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Nom du bien *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex: Apt A1" />
              </div>
              <div>
                <Label>Type *</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(typeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            {(form.type === "appartement" || form.type === "studio") &&
            <div>
                <Label>Immeuble / Bâtiment parent</Label>
                <Select value={form.building_id || ""} onValueChange={(v) => setForm({ ...form, building_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Aucun (bien indépendant)" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Aucun</SelectItem>
                    {buildings.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            }
            <div>
              <Label>Adresse</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Ville</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
              <div><Label>Surface (m²)</Label><Input type="number" value={form.surface} onChange={(e) => setForm({ ...form, surface: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Loyer mensuel (XAF) *</Label><Input type="number" value={form.rent_amount} onChange={(e) => setForm({ ...form, rent_amount: e.target.value })} /></div>
              <div><Label>Charges (XAF)</Label><Input type="number" value={form.charges_amount} onChange={(e) => setForm({ ...form, charges_amount: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Statut</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vacant">Vacant</SelectItem>
                    <SelectItem value="occupied">Occupé</SelectItem>
                    <SelectItem value="maintenance">En travaux</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Pièces</Label><Input type="number" value={form.rooms} onChange={(e) => setForm({ ...form, rooms: e.target.value })} /></div>
            </div>
            <div><Label>Notes</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Building Dialog */}
      <Dialog open={buildingDialogOpen} onOpenChange={setBuildingDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editingBuildingId ? "Modifier le bâtiment" : "Nouveau bâtiment"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Nom *</Label>
                <Input value={buildingForm.name} onChange={(e) => setBuildingForm({ ...buildingForm, name: e.target.value })} placeholder="Ex: Résidence Les Palmiers" />
              </div>
              <div>
                <Label>Type *</Label>
                <Select value={buildingForm.type} onValueChange={(v) => setBuildingForm({ ...buildingForm, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(buildingTypeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Adresse</Label><Input value={buildingForm.address} onChange={(e) => setBuildingForm({ ...buildingForm, address: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Ville</Label><Input value={buildingForm.city} onChange={(e) => setBuildingForm({ ...buildingForm, city: e.target.value })} /></div>
              <div><Label>Nombre d'étages</Label><Input type="number" value={buildingForm.floors} onChange={(e) => setBuildingForm({ ...buildingForm, floors: e.target.value })} /></div>
            </div>
            <div><Label>Nombre total de lots</Label><Input type="number" value={buildingForm.total_units} onChange={(e) => setBuildingForm({ ...buildingForm, total_units: e.target.value })} /></div>
            <div><Label>Notes</Label><Input value={buildingForm.notes} onChange={(e) => setBuildingForm({ ...buildingForm, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBuildingDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSaveBuilding} disabled={saveBuildingMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveBuildingMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}