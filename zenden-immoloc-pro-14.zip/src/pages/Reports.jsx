import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from
"recharts";
import {
  Download, FileText, TrendingUp, TrendingDown, Wallet,
  Filter, X, BarChart2, PieChart as PieIcon, Building2, Users,
  FileSpreadsheet, ChevronRight, RefreshCw, Calendar, Home, CreditCard } from
"lucide-react";

// ─── Constants ────────────────────────────────────────────────────────────────
const MONTHS = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];
const COLORS = ["#10b981", "#3b82f6", "#8b5cf6", "#f59e0b", "#ef4444", "#ec4899", "#06b6d4", "#84cc16", "#f97316", "#a855f7"];
const PAYMENT_STATUSES = { paid: "Payé", partial: "Partiel", pending: "En attente", late: "En retard", cancelled: "Annulé" };
const LEASE_STATUSES = { active: "Actif", expired: "Expiré", terminated: "Résilié", draft: "Brouillon" };
const LEASE_TYPES = { non_meuble: "Non meublé", meuble: "Meublé", bnb: "BnB", commercial: "Commercial", autre: "Autre" };
const CHARGE_CATEGORIES = {
  maintenance: "Maintenance", plomberie: "Plomberie", peinture: "Peinture", electricite: "Électricité",
  assurance: "Assurance", taxe_fonciere: "Taxe foncière", eau: "Eau", gardiennage: "Gardiennage",
  nettoyage: "Nettoyage", menuiserie: "Menuiserie", serrurerie: "Serrurerie", electricite_commune: "Élec. commune", autre: "Autre"
};
const PROPERTY_STATUSES = { vacant: "Vacant", occupied: "Occupé", maintenance: "En maintenance" };
const PROPERTY_TYPES = { appartement: "Appartement", maison: "Maison", studio: "Studio", local_commercial: "Local commercial", parking: "Parking", autre: "Autre" };

// Predefined report templates
const REPORT_TEMPLATES = [
{ id: "custom", label: "Rapport personnalisé", icon: Filter, desc: "Configurez vos propres filtres et entités" },
{ id: "monthly_summary", label: "Bilan mensuel", icon: Calendar, desc: "Revenus, charges et résultat net du mois" },
{ id: "property_performance", label: "Performance par bien", icon: Home, desc: "Taux d'occupation et revenus par propriété" },
{ id: "tenant_ledger", label: "Grand livre locataire", icon: Users, desc: "Historique complet des paiements par locataire" },
{ id: "unpaid_report", label: "Rapport impayés", icon: TrendingDown, desc: "Tous les loyers en retard ou en attente" },
{ id: "lease_overview", label: "État des baux", icon: FileText, desc: "Statut et échéances de tous les baux actifs" }];


// Entity selector config
const ENTITIES = [
{ id: "payments", label: "Paiements", icon: Wallet, color: "emerald" },
{ id: "charges", label: "Charges", icon: CreditCard, color: "red" },
{ id: "leases", label: "Baux", icon: FileText, color: "blue" },
{ id: "properties", label: "Biens", icon: Building2, color: "violet" }];


function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}
function formatDate(d) {return d ? new Date(d).toLocaleDateString("fr-FR") : "—";}

// ─── Export Helpers ────────────────────────────────────────────────────────────
function exportCSV(rows, columns, filename) {
  const header = columns.map((c) => `"${c.label}"`).join(";");
  const body = rows.map((r) => columns.map((c) => `"${(r[c.key] ?? "").toString().replace(/"/g, '""')}"`).join(";")).join("\n");
  const blob = new Blob(["\uFEFF" + header + "\n" + body], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");a.href = url;a.download = filename + ".csv";a.click();
  URL.revokeObjectURL(url);
}

function exportPDF(sections, title) {
  const sectionHtml = sections.map(({ label, rows, columns }) => {
    const thead = columns.map((c) => `<th style="padding:6px 10px;background:#0f2b4c;color:#fff;font-size:11px;text-align:left">${c.label}</th>`).join("");
    const tbody = rows.map((r, ri) =>
    `<tr style="background:${ri % 2 === 0 ? '#fff' : '#f8fafc'}">
        ${columns.map((c) => `<td style="padding:5px 10px;border-bottom:1px solid #e2e8f0;font-size:11px">${r[c.key] ?? ""}</td>`).join("")}
      </tr>`
    ).join("");
    return `<h3 style="color:#0f2b4c;margin-top:24px;font-size:13px">${label} (${rows.length} ligne(s))</h3>
    <table style="border-collapse:collapse;width:100%;margin-top:8px"><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>`;
  }).join("");

  const html = `<html><head><title>${title}</title>
    <style>body{font-family:Arial,sans-serif;padding:30px;color:#1e293b}h2{color:#0f2b4c;border-bottom:2px solid #10b981;padding-bottom:8px}</style>
    </head><body>
    <h2>${title}</h2>
    <p style="color:#64748b;font-size:11px;margin-bottom:20px">Généré le ${new Date().toLocaleDateString("fr-FR")} à ${new Date().toLocaleTimeString("fr-FR")}</p>
    ${sectionHtml}
    </body></html>`;
  const w = window.open("", "_blank");
  w.document.write(html);w.document.close();w.print();
}

// ─── Filter Panel ─────────────────────────────────────────────────────────────
function FilterPanel({ filters, onChange, tenants, properties, selectedEntities }) {
  const currentYear = new Date().getFullYear();
  const years = [currentYear, currentYear - 1, currentYear - 2, currentYear - 3];
  const reset = () => onChange({
    year: String(currentYear), yearTo: String(currentYear),
    monthFrom: "all", monthTo: "all",
    tenantId: "all", propertyId: "all",
    paymentStatus: "all", leaseStatus: "all", leaseType: "all", chargeCategory: "all"
  });

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-sm font-semibold text-slate-700">Filtres</span>
        </div>
        <Button size="sm" variant="ghost" className="h-7 text-xs text-slate-400 hover:text-slate-600" onClick={reset}>
          <RefreshCw className="w-3 h-3 mr-1" /> Réinitialiser
        </Button>
      </div>
      <div className="flex flex-wrap gap-3">
        {/* Period */}
        <div className="min-w-[100px]">
          <Label className="text-xs mb-1 block text-slate-500">Année</Label>
          <Select value={filters.year} onValueChange={(v) => onChange({ ...filters, year: v })}>
            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>{years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="min-w-[110px]">
          <Label className="text-xs mb-1 block text-slate-500">Mois début</Label>
          <Select value={filters.monthFrom} onValueChange={(v) => onChange({ ...filters, monthFrom: v })}>
            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous</SelectItem>
              {MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="min-w-[110px]">
          <Label className="text-xs mb-1 block text-slate-500">Mois fin</Label>
          <Select value={filters.monthTo} onValueChange={(v) => onChange({ ...filters, monthTo: v })}>
            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous</SelectItem>
              {MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Entity-specific filters */}
        {(selectedEntities.includes("payments") || selectedEntities.includes("leases")) &&
        <div className="min-w-[150px]">
            <Label className="text-xs mb-1 block text-slate-500">Locataire</Label>
            <Select value={filters.tenantId} onValueChange={(v) => onChange({ ...filters, tenantId: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                {tenants.map((t) => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        }
        {(selectedEntities.includes("payments") || selectedEntities.includes("charges") || selectedEntities.includes("leases")) &&
        <div className="min-w-[150px]">
            <Label className="text-xs mb-1 block text-slate-500">Bien</Label>
            <Select value={filters.propertyId} onValueChange={(v) => onChange({ ...filters, propertyId: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                {properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        }
        {selectedEntities.includes("payments") &&
        <div className="min-w-[130px]">
            <Label className="text-xs mb-1 block text-slate-500">Statut paiement</Label>
            <Select value={filters.paymentStatus} onValueChange={(v) => onChange({ ...filters, paymentStatus: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                {Object.entries(PAYMENT_STATUSES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        }
        {selectedEntities.includes("leases") &&
        <>
            <div className="min-w-[120px]">
              <Label className="text-xs mb-1 block text-slate-500">Statut bail</Label>
              <Select value={filters.leaseStatus} onValueChange={(v) => onChange({ ...filters, leaseStatus: v })}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  {Object.entries(LEASE_STATUSES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="min-w-[130px]">
              <Label className="text-xs mb-1 block text-slate-500">Type de bail</Label>
              <Select value={filters.leaseType} onValueChange={(v) => onChange({ ...filters, leaseType: v })}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  {Object.entries(LEASE_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </>
        }
        {selectedEntities.includes("charges") &&
        <div className="min-w-[140px]">
            <Label className="text-xs mb-1 block text-slate-500">Catégorie charge</Label>
            <Select value={filters.chargeCategory} onValueChange={(v) => onChange({ ...filters, chargeCategory: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                {Object.entries(CHARGE_CATEGORIES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        }
      </div>
    </div>);

}

// ─── Entity Selector ──────────────────────────────────────────────────────────
function EntitySelector({ selected, onChange }) {
  const toggle = (id) => {
    if (selected.includes(id)) onChange(selected.filter((e) => e !== id));else
    onChange([...selected, id]);
  };
  return (
    <div className="flex flex-wrap gap-2">
      {ENTITIES.map(({ id, label, icon: Icon, color }) => {
        const active = selected.includes(id);
        return (
          <button key={id} onClick={() => toggle(id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition-all ${
          active ? `bg-${color}-50 border-${color}-300 text-${color}-700` : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"}`
          }>
            <Icon className="w-3.5 h-3.5" />
            {label}
            {active && <X className="w-3 h-3 ml-0.5 opacity-60" />}
          </button>);

      })}
    </div>);

}

// ─── KPI Strip ────────────────────────────────────────────────────────────────
function KpiStrip({ totalRevenue, totalExpense, paymentCount, chargeCount, leaseCount }) {
  const net = totalRevenue - totalExpense;
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      {[
      { label: "Revenus", value: `${formatXAF(totalRevenue)} XAF`, icon: TrendingUp, color: "emerald", sub: `${paymentCount} pmt(s)` },
      { label: "Charges", value: `${formatXAF(totalExpense)} XAF`, icon: TrendingDown, color: "red", sub: `${chargeCount} charge(s)` },
      { label: "Résultat net", value: `${net >= 0 ? "+" : ""}${formatXAF(net)} XAF`, icon: Wallet, color: net >= 0 ? "emerald" : "red", sub: "" },
      { label: "Baux filtrés", value: leaseCount, icon: FileText, color: "blue", sub: "" },
      { label: "Taux encaiss.", value: paymentCount > 0 ? `${Math.round(totalRevenue / (totalRevenue + totalExpense) * 100)}%` : "—", icon: BarChart2, color: "violet", sub: "" }].
      map(({ label, value, icon: Icon, color, sub }) =>
      <Card key={label} className="p-3 flex items-center gap-2.5">
          <div className={`w-8 h-8 rounded-lg bg-${color}-100 flex items-center justify-center shrink-0`}>
            <Icon className={`w-4 h-4 text-${color}-600`} />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 leading-tight">{label}</p>
            <p className="text-slate-800 text-sm font-bold leading-tight">{value}</p>
            {sub && <p className="text-[10px] text-slate-400">{sub}</p>}
          </div>
        </Card>
      )}
    </div>);

}

// ─── Data Table ───────────────────────────────────────────────────────────────
function DataTable({ rows, columns, onExportCsv, onExportPdf, label }) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b bg-slate-50">
        <p className="text-sm font-semibold text-slate-700">{label} — {rows.length} ligne(s)</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={onExportCsv}>
            <FileSpreadsheet className="w-3.5 h-3.5 mr-1" /> CSV
          </Button>
          <Button size="sm" className="bg-[#0f2b4c] hover:bg-[#1a3d6e]" onClick={onExportPdf}>
            <FileText className="w-3.5 h-3.5 mr-1" /> PDF
          </Button>
        </div>
      </div>
      <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-slate-50 z-10 border-b">
            <tr>{columns.map((c) => <th key={c.key} className="text-left py-2.5 px-3 font-medium text-slate-500 whitespace-nowrap">{c.label}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r, i) =>
            <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/70">
                {columns.map((c) =>
              <td key={c.key} className="py-2 px-3 text-slate-700 whitespace-nowrap">
                    {c.render ? c.render(r[c.key], r) : r[c.key]}
                  </td>
              )}
              </tr>
            )}
            {rows.length === 0 &&
            <tr><td colSpan={columns.length} className="text-center py-12 text-slate-400">Aucune donnée</td></tr>
            }
          </tbody>
        </table>
      </div>
    </Card>);

}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Reports() {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const [template, setTemplate] = useState("custom");
  const [selectedEntities, setSelectedEntities] = useState(["payments", "charges"]);
  const [filters, setFilters] = useState({
    year: String(currentYear), monthFrom: "all", monthTo: "all",
    tenantId: "all", propertyId: "all",
    paymentStatus: "all", leaseStatus: "all", leaseType: "all", chargeCategory: "all"
  });
  const [activeTab, setActiveTab] = useState("charts");

  // Data fetching
  const { data: payments = [], isLoading: lp } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: charges = [], isLoading: lc } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: leases = [] } = useQuery({ queryKey: ["leases"], queryFn: () => base44.entities.Lease.list() });

  // Apply template presets
  const applyTemplate = (id) => {
    setTemplate(id);
    const y = String(currentYear);
    const m = String(currentMonth);
    const base = { year: y, monthFrom: "all", monthTo: "all", tenantId: "all", propertyId: "all", paymentStatus: "all", leaseStatus: "all", leaseType: "all", chargeCategory: "all" };
    if (id === "monthly_summary") {setSelectedEntities(["payments", "charges"]);setFilters({ ...base, monthFrom: m, monthTo: m });} else
    if (id === "property_performance") {setSelectedEntities(["payments", "properties"]);setFilters(base);} else
    if (id === "tenant_ledger") {setSelectedEntities(["payments"]);setFilters(base);} else
    if (id === "unpaid_report") {setSelectedEntities(["payments"]);setFilters({ ...base, paymentStatus: "late" });} else
    if (id === "lease_overview") {setSelectedEntities(["leases"]);setFilters({ ...base, leaseStatus: "active" });} else
    {setSelectedEntities(["payments", "charges"]);setFilters(base);}
  };

  const y = Number(filters.year);
  const mFrom = filters.monthFrom === "all" ? 1 : Number(filters.monthFrom);
  const mTo = filters.monthTo === "all" ? 12 : Number(filters.monthTo);

  // Filtered data
  const filteredPayments = useMemo(() => payments.filter((p) => {
    if (p.period_year !== y) return false;
    if (p.period_month < mFrom || p.period_month > mTo) return false;
    if (filters.tenantId !== "all" && p.tenant_id !== filters.tenantId) return false;
    if (filters.propertyId !== "all" && p.property_id !== filters.propertyId) return false;
    if (filters.paymentStatus !== "all" && p.status !== filters.paymentStatus) return false;
    return true;
  }), [payments, y, mFrom, mTo, filters]);

  const filteredCharges = useMemo(() => charges.filter((c) => {
    const d = new Date(c.date);
    const cm = d.getMonth() + 1;
    if (d.getFullYear() !== y) return false;
    if (cm < mFrom || cm > mTo) return false;
    if (filters.propertyId !== "all" && c.property_id !== filters.propertyId) return false;
    if (filters.chargeCategory !== "all" && c.category !== filters.chargeCategory) return false;
    return true;
  }), [charges, y, mFrom, mTo, filters]);

  const filteredLeases = useMemo(() => leases.filter((l) => {
    if (filters.leaseStatus !== "all" && l.status !== filters.leaseStatus) return false;
    if (filters.leaseType !== "all" && l.type !== filters.leaseType) return false;
    if (filters.tenantId !== "all" && l.tenant_id !== filters.tenantId) return false;
    if (filters.propertyId !== "all" && l.property_id !== filters.propertyId) return false;
    return true;
  }), [leases, filters]);

  const filteredProperties = useMemo(() => {
    if (filters.propertyId !== "all") return properties.filter((p) => p.id === filters.propertyId);
    return properties;
  }, [properties, filters.propertyId]);

  const totalRevenue = filteredPayments.filter((p) => p.status === "paid" || p.status === "partial").reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpense = filteredCharges.reduce((s, c) => s + (c.amount || 0), 0);

  // Chart data
  const monthlyData = MONTHS.map((name, i) => {
    const m = i + 1;
    if (m < mFrom || m > mTo) return null;
    const rev = filteredPayments.filter((p) => p.period_month === m && (p.status === "paid" || p.status === "partial")).reduce((s, p) => s + (p.amount || 0), 0);
    const dep = filteredCharges.filter((c) => new Date(c.date).getMonth() === i).reduce((s, c) => s + (c.amount || 0), 0);
    return { name, revenus: rev, depenses: dep, net: rev - dep };
  }).filter(Boolean);

  const revByProp = {};
  filteredPayments.filter((p) => p.status === "paid" || p.status === "partial").forEach((p) => {
    revByProp[p.property_name || "Autre"] = (revByProp[p.property_name || "Autre"] || 0) + (p.amount || 0);
  });
  const pieData = Object.entries(revByProp).map(([name, value]) => ({ name, value }));

  const chargesByCat = {};
  filteredCharges.forEach((c) => {
    const cat = CHARGE_CATEGORIES[c.category] || c.category || "Autre";
    chargesByCat[cat] = (chargesByCat[cat] || 0) + (c.amount || 0);
  });
  const chargesPieData = Object.entries(chargesByCat).map(([name, value]) => ({ name, value }));

  // Table rows
  const paymentRows = filteredPayments.map((p) => ({
    date: formatDate(p.payment_date || p.due_date),
    locataire: p.tenant_name || "",
    bien: p.property_name || "",
    periode: `${MONTHS[(p.period_month || 1) - 1]} ${p.period_year}`,
    montant: formatXAF(p.amount) + " XAF",
    attendu: formatXAF(p.expected_amount) + " XAF",
    statut: PAYMENT_STATUSES[p.status] || p.status,
    mode: p.payment_method || "",
    reference: p.reference || ""
  }));

  const chargeRows = filteredCharges.map((c) => ({
    date: formatDate(c.date),
    bien: c.property_name || "—",
    categorie: CHARGE_CATEGORIES[c.category] || c.category,
    description: c.description || "",
    montant: formatXAF(c.amount) + " XAF",
    fournisseur: c.supplier || "",
    statut: c.status === "paid" ? "Payé" : c.status === "pending" ? "En attente" : "Annulé",
    deductible: c.is_deductible ? "Oui" : "Non"
  }));

  const leaseRows = filteredLeases.map((l) => ({
    locataire: l.tenant_name || "",
    bien: l.property_name || "",
    type: LEASE_TYPES[l.type] || l.type,
    debut: formatDate(l.start_date),
    fin: formatDate(l.end_date),
    loyer: formatXAF(l.rent_amount) + " XAF",
    charges: formatXAF(l.charges_amount) + " XAF",
    depot: formatXAF(l.deposit_amount) + " XAF",
    statut: LEASE_STATUSES[l.status] || l.status,
    tva: l.tva_applicable ? `Oui (${l.tva_rate}%)` : "Non"
  }));

  const propertyRows = filteredProperties.map((p) => {
    const propPayments = payments.filter((pmt) => pmt.property_id === p.id && pmt.period_year === y && (pmt.status === "paid" || pmt.status === "partial"));
    const propRevenue = propPayments.reduce((s, pmt) => s + (pmt.amount || 0), 0);
    const propCharges = charges.filter((c) => c.property_id === p.id && new Date(c.date).getFullYear() === y).reduce((s, c) => s + (c.amount || 0), 0);
    return {
      nom: p.name,
      type: PROPERTY_TYPES[p.type] || p.type,
      ville: p.city || "—",
      statut: PROPERTY_STATUSES[p.status] || p.status,
      loyer: formatXAF(p.rent_amount) + " XAF",
      revenus: formatXAF(propRevenue) + " XAF",
      charges: formatXAF(propCharges) + " XAF",
      net: formatXAF(propRevenue - propCharges) + " XAF"
    };
  });

  // Column definitions
  const paymentCols = [
  { key: "date", label: "Date" }, { key: "locataire", label: "Locataire" }, { key: "bien", label: "Bien" },
  { key: "periode", label: "Période" }, { key: "montant", label: "Montant" }, { key: "attendu", label: "Attendu" },
  { key: "statut", label: "Statut", render: (v) =>
    <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${v === "Payé" ? "bg-emerald-100 text-emerald-700" : v === "En retard" ? "bg-red-100 text-red-700" : v === "En attente" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{v}</span>
  },
  { key: "mode", label: "Mode" }, { key: "reference", label: "Référence" }];

  const chargeCols = [
  { key: "date", label: "Date" }, { key: "bien", label: "Bien" }, { key: "categorie", label: "Catégorie" },
  { key: "description", label: "Description" }, { key: "montant", label: "Montant" },
  { key: "fournisseur", label: "Fournisseur" }, { key: "statut", label: "Statut" }, { key: "deductible", label: "Déductible" }];

  const leaseCols = [
  { key: "locataire", label: "Locataire" }, { key: "bien", label: "Bien" }, { key: "type", label: "Type" },
  { key: "debut", label: "Début" }, { key: "fin", label: "Fin" }, { key: "loyer", label: "Loyer" },
  { key: "charges", label: "Charges" }, { key: "depot", label: "Dépôt" },
  { key: "statut", label: "Statut", render: (v) =>
    <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${v === "Actif" ? "bg-emerald-100 text-emerald-700" : v === "Expiré" ? "bg-red-100 text-red-700" : v === "Brouillon" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{v}</span>
  },
  { key: "tva", label: "TVA" }];

  const propertyCols = [
  { key: "nom", label: "Bien" }, { key: "type", label: "Type" }, { key: "ville", label: "Ville" },
  { key: "statut", label: "Statut", render: (v) =>
    <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${v === "Occupé" ? "bg-emerald-100 text-emerald-700" : v === "Vacant" ? "bg-slate-100 text-slate-600" : "bg-amber-100 text-amber-700"}`}>{v}</span>
  },
  { key: "loyer", label: "Loyer/mois" }, { key: "revenus", label: `Revenus ${y}` },
  { key: "charges", label: `Charges ${y}` }, { key: "net", label: "Net" }];


  const reportTitle = `Rapport_${filters.year}${filters.monthFrom !== "all" ? `_${MONTHS[mFrom - 1]}` : ""}${filters.monthTo !== "all" && filters.monthTo !== filters.monthFrom ? `-${MONTHS[mTo - 1]}` : ""}`;

  const buildPdfSections = () => {
    const sections = [];
    if (selectedEntities.includes("payments")) sections.push({ label: "Paiements", rows: paymentRows, columns: paymentCols.map((c) => ({ ...c, render: undefined })) });
    if (selectedEntities.includes("charges")) sections.push({ label: "Charges", rows: chargeRows, columns: chargeCols });
    if (selectedEntities.includes("leases")) sections.push({ label: "Baux", rows: leaseRows, columns: leaseCols.map((c) => ({ ...c, render: undefined })) });
    if (selectedEntities.includes("properties")) sections.push({ label: "Biens", rows: propertyRows, columns: propertyCols.map((c) => ({ ...c, render: undefined })) });
    return sections;
  };

  const exportAllCSV = () => {
    if (selectedEntities.includes("payments")) exportCSV(paymentRows, paymentCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_paiements`);
    if (selectedEntities.includes("charges")) exportCSV(chargeRows, chargeCols, `${reportTitle}_charges`);
    if (selectedEntities.includes("leases")) exportCSV(leaseRows, leaseCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_baux`);
    if (selectedEntities.includes("properties")) exportCSV(propertyRows, propertyCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_biens`);
  };

  if (lp || lc) return (
    <div className="space-y-4">
      {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
    </div>);


  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Rapports personnalisés</h1>
          <p className="text-sm text-slate-500">Sélectionnez un modèle ou configurez votre rapport manuellement</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={exportAllCSV}>
            <FileSpreadsheet className="w-4 h-4 mr-1.5" /> Tout CSV
          </Button>
          <Button size="sm" className="bg-[#0f2b4c] hover:bg-[#1a3d6e]" onClick={() => exportPDF(buildPdfSections(), `${reportTitle} — ${new Date().toLocaleDateString("fr-FR")}`)}>
            <FileText className="w-4 h-4 mr-1.5" /> Exporter PDF
          </Button>
        </div>
      </div>

      {/* Template Selector */}
      <div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Modèles de rapports</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {REPORT_TEMPLATES.map(({ id, label, icon: Icon, desc }) =>
          <button key={id} onClick={() => applyTemplate(id)}
          className={`flex flex-col items-start gap-1.5 p-3 rounded-xl border text-left transition-all ${
          template === id ?
          "bg-[#0f2b4c] border-[#0f2b4c] text-white" :
          "bg-white border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50"}`
          }>
              <Icon className={`w-4 h-4 ${template === id ? "text-emerald-400" : "text-slate-400"}`} />
              <span className="text-xs font-semibold leading-tight">{label}</span>
              <span className={`text-[10px] leading-tight ${template === id ? "text-slate-300" : "text-slate-400"}`}>{desc}</span>
            </button>
          )}
        </div>
      </div>

      {/* Entity Selector */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5">Entités à inclure</p>
        <EntitySelector selected={selectedEntities} onChange={setSelectedEntities} />
      </div>

      {/* Filters */}
      <FilterPanel filters={filters} onChange={setFilters} tenants={tenants} properties={properties} selectedEntities={selectedEntities} />

      {/* KPIs */}
      <KpiStrip totalRevenue={totalRevenue} totalExpense={totalExpense}
      paymentCount={filteredPayments.length} chargeCount={filteredCharges.length} leaseCount={filteredLeases.length} />

      {/* Main tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="flex-wrap h-auto gap-1 bg-slate-100">
          <TabsTrigger value="charts"><BarChart2 className="w-3.5 h-3.5 mr-1" />Graphiques</TabsTrigger>
          {selectedEntities.includes("payments") && <TabsTrigger value="payments"><Wallet className="w-3.5 h-3.5 mr-1" />Paiements</TabsTrigger>}
          {selectedEntities.includes("charges") && <TabsTrigger value="charges"><CreditCard className="w-3.5 h-3.5 mr-1" />Charges</TabsTrigger>}
          {selectedEntities.includes("leases") && <TabsTrigger value="leases"><FileText className="w-3.5 h-3.5 mr-1" />Baux</TabsTrigger>}
          {selectedEntities.includes("properties") && <TabsTrigger value="properties"><Building2 className="w-3.5 h-3.5 mr-1" />Biens</TabsTrigger>}
        </TabsList>

        {/* Charts Tab */}
        <TabsContent value="charts" className="mt-4 space-y-4">
          {(selectedEntities.includes("payments") || selectedEntities.includes("charges")) &&
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="p-5">
                <h3 className="text-sm font-semibold text-slate-700 mb-4">Revenus vs Dépenses / mois</h3>
                {monthlyData.length > 0 ?
              <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />
                      <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={(v) => v >= 1000 ? (v / 1000).toFixed(0) + "k" : v} />
                      <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                      <Legend wrapperStyle={{ fontSize: "12px" }} />
                      {selectedEntities.includes("payments") && <Bar dataKey="revenus" name="Revenus" fill="#10b981" radius={[3, 3, 0, 0]} />}
                      {selectedEntities.includes("charges") && <Bar dataKey="depenses" name="Dépenses" fill="#ef4444" radius={[3, 3, 0, 0]} />}
                    </BarChart>
                  </ResponsiveContainer> :
              <p className="text-sm text-slate-400 text-center py-16">Aucune donnée sur la période</p>}
              </Card>
              <Card className="p-5">
                <h3 className="text-sm font-semibold text-slate-700 mb-4">Résultat net mensuel</h3>
                {monthlyData.length > 0 ?
              <ResponsiveContainer width="100%" height={240}>
                    <AreaChart data={monthlyData}>
                      <defs>
                        <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />
                      <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={(v) => v >= 1000 ? (v / 1000).toFixed(0) + "k" : v} />
                      <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                      <Area type="monotone" dataKey="net" name="Net" stroke="#6366f1" strokeWidth={2} fill="url(#netGrad)" />
                    </AreaChart>
                  </ResponsiveContainer> :
              <p className="text-sm text-slate-400 text-center py-16">Aucune donnée</p>}
              </Card>
            </div>
          }
          {selectedEntities.includes("payments") &&
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="p-5">
                <h3 className="text-sm font-semibold text-slate-700 mb-4">Revenus par bien</h3>
                {pieData.length > 0 ?
              <>
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                          {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                        </Pie>
                        <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="space-y-1.5 mt-2">
                      {pieData.slice(0, 6).map((d, i) =>
                  <div key={i} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                            <span className="truncate max-w-[150px]">{d.name}</span>
                          </div>
                          <span className="font-semibold shrink-0">{formatXAF(d.value)} XAF</span>
                        </div>
                  )}
                    </div>
                  </> :
              <p className="text-sm text-slate-400 text-center py-16">Aucun paiement</p>}
              </Card>
              {selectedEntities.includes("charges") &&
            <Card className="p-5">
                  <h3 className="text-sm font-semibold text-slate-700 mb-4">Charges par catégorie</h3>
                  {chargesPieData.length > 0 ?
              <>
                      <ResponsiveContainer width="100%" height={200}>
                        <PieChart>
                          <Pie data={chargesPieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                            {chargesPieData.map((_, i) => <Cell key={i} fill={COLORS[(i + 4) % COLORS.length]} />)}
                          </Pie>
                          <Tooltip formatter={(v) => formatXAF(v) + " XAF"} contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="space-y-1.5 mt-2">
                        {chargesPieData.slice(0, 6).map((d, i) =>
                  <div key={i} className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full shrink-0" style={{ background: COLORS[(i + 4) % COLORS.length] }} />
                              <span>{d.name}</span>
                            </div>
                            <span className="font-semibold">{formatXAF(d.value)} XAF</span>
                          </div>
                  )}
                      </div>
                    </> :
              <p className="text-sm text-slate-400 text-center py-16">Aucune charge</p>}
                </Card>
            }
            </div>
          }
        </TabsContent>

        {/* Payments Table */}
        {selectedEntities.includes("payments") &&
        <TabsContent value="payments" className="mt-4">
            <DataTable rows={paymentRows} columns={paymentCols} label="Paiements"
          onExportCsv={() => exportCSV(paymentRows, paymentCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_paiements`)}
          onExportPdf={() => exportPDF([{ label: "Paiements", rows: paymentRows, columns: paymentCols.map((c) => ({ key: c.key, label: c.label })) }], `Rapport paiements — ${filters.year}`)} />

          </TabsContent>
        }

        {/* Charges Table */}
        {selectedEntities.includes("charges") &&
        <TabsContent value="charges" className="mt-4">
            <DataTable rows={chargeRows} columns={chargeCols} label="Charges"
          onExportCsv={() => exportCSV(chargeRows, chargeCols, `${reportTitle}_charges`)}
          onExportPdf={() => exportPDF([{ label: "Charges", rows: chargeRows, columns: chargeCols }], `Rapport charges — ${filters.year}`)} />

          </TabsContent>
        }

        {/* Leases Table */}
        {selectedEntities.includes("leases") &&
        <TabsContent value="leases" className="mt-4">
            <DataTable rows={leaseRows} columns={leaseCols} label="Baux"
          onExportCsv={() => exportCSV(leaseRows, leaseCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_baux`)}
          onExportPdf={() => exportPDF([{ label: "Baux", rows: leaseRows, columns: leaseCols.map((c) => ({ key: c.key, label: c.label })) }], `Rapport baux — ${filters.year}`)} />

          </TabsContent>
        }

        {/* Properties Table */}
        {selectedEntities.includes("properties") &&
        <TabsContent value="properties" className="mt-4">
            <DataTable rows={propertyRows} columns={propertyCols} label="Biens"
          onExportCsv={() => exportCSV(propertyRows, propertyCols.map((c) => ({ key: c.key, label: c.label })), `${reportTitle}_biens`)}
          onExportPdf={() => exportPDF([{ label: "Biens immobiliers", rows: propertyRows, columns: propertyCols.map((c) => ({ key: c.key, label: c.label })) }], `Rapport biens — ${filters.year}`)} />

          </TabsContent>
        }
      </Tabs>
    </div>);

}