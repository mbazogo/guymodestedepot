import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Pencil, Trash2, Search, Wallet, Printer, Download, FileSpreadsheet, LayoutList } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import ReceiptPrint from "../components/payments/ReceiptPrint";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const statusLabels = { paid: "Payé", partial: "Partiel", pending: "En attente", late: "En retard", cancelled: "Annulé" };
const statusColors = { paid: "zd-badge-paid", partial: "zd-badge-pending", pending: "zd-badge-pending", late: "zd-badge-late", cancelled: "bg-slate-100 text-slate-500" };
const methodLabels = { especes: "Espèces", virement: "Virement", cheque: "Chèque", mobile_money: "Mobile Money", autre: "Autre" };

export default function Payments() {
  const urlParams = new URLSearchParams(window.location.search);
  const initialFilter = urlParams.get("filter") || "all";

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState(initialFilter);
  const [groupBy, setGroupBy] = useState("none");
  const [receiptPayment, setReceiptPayment] = useState(null);
  const qc = useQueryClient();

  const { data: payments = [], isLoading } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const saveMutation = useMutation({
    mutationFn: (data) => editingId ? base44.entities.Payment.update(editingId, data) : base44.entities.Payment.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["payments"] });setDialogOpen(false);}
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Payment.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["payments"] })
  });

  const openNew = () => {
    const now = new Date();
    setForm({ tenant_id: "", property_id: "", amount: "", expected_amount: "", payment_date: now.toISOString().slice(0, 10), due_date: "", period_month: now.getMonth() + 1, period_year: now.getFullYear(), payment_method: "especes", status: "paid", reference: "", notes: "", type: "loyer" });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (p) => {
    const today = new Date().toISOString().slice(0, 10);
    setForm({ ...p, payment_date: p.payment_date || today });
    setEditingId(p.id);
    setDialogOpen(true);
  };

  const handleSave = () => {
    const tenant = tenants.find((t) => t.id === form.tenant_id);
    const prop = properties.find((p) => p.id === form.property_id);
    saveMutation.mutate({
      ...form,
      tenant_name: tenant ? `${tenant.first_name} ${tenant.last_name}` : "",
      property_name: prop?.name || "",
      amount: Number(form.amount) || 0,
      expected_amount: Number(form.expected_amount) || 0,
      period_month: Number(form.period_month) || 1,
      period_year: Number(form.period_year) || new Date().getFullYear()
    });
  };

  const filtered = payments.
  filter((p) => filter === "all" || p.status === filter).
  filter((p) =>
  p.tenant_name?.toLowerCase().includes(search.toLowerCase()) ||
  p.property_name?.toLowerCase().includes(search.toLowerCase()) ||
  p.reference?.toLowerCase().includes(search.toLowerCase())
  ).
  sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  // Export to Excel (CSV)
  const exportToExcel = () => {
    const headers = ["Locataire", "Bien", "Période", "Montant (XAF)", "Mode", "Statut", "Référence", "Date paiement"];
    const rows = filtered.map((p) => [
    p.tenant_name || "",
    p.property_name || "",
    `${String(p.period_month).padStart(2, "0")}/${p.period_year}`,
    p.amount || 0,
    methodLabels[p.payment_method] || p.payment_method || "",
    statusLabels[p.status] || p.status || "",
    p.reference || "",
    p.payment_date || ""]
    );
    const csv = [headers, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;a.download = `paiements_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();URL.revokeObjectURL(url);
  };

  // Print payments list
  const printList = () => {
    const tableRows = filtered.map((p) =>
    `<tr><td>${p.tenant_name || ""}</td><td>${p.property_name || ""}</td><td>${String(p.period_month).padStart(2, "0")}/${p.period_year}</td><td style="text-align:right">${new Intl.NumberFormat("fr-FR").format(p.amount || 0)} XAF</td><td>${methodLabels[p.payment_method] || ""}</td><td>${statusLabels[p.status] || ""}</td></tr>`
    ).join("");
    const html = `<html><head><title>Liste des paiements</title><style>body{font-family:Arial,sans-serif;font-size:11px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:6px 8px;text-align:left}th{background:#f1f5f9;font-weight:600}tr:nth-child(even){background:#f8fafc}h2{margin-bottom:12px}</style></head><body><h2>Liste des paiements — ${new Date().toLocaleDateString("fr-FR")}</h2><table><thead><tr><th>Locataire</th><th>Bien</th><th>Période</th><th>Montant</th><th>Mode</th><th>Statut</th></tr></thead><tbody>${tableRows}</tbody></table></body></html>`;
    const w = window.open("", "_blank");w.document.write(html);w.document.close();w.print();
  };

  // Group payments
  const groupedPayments = () => {
    if (groupBy === "none") return { "": filtered };
    const groups = {};
    filtered.forEach((p) => {
      const key = groupBy === "property" ? p.property_name || "Sans bien" : groupBy === "building" ? properties.find((pr) => pr.id === p.property_id)?.building_name || "Sans bâtiment" : `${String(p.period_month).padStart(2, "0")}/${p.period_year}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(p);
    });
    return groups;
  };

  // When tenant is selected, auto-fill property and amount
  const handleTenantChange = (tenantId) => {
    const tenant = tenants.find((t) => t.id === tenantId);
    setForm({
      ...form,
      tenant_id: tenantId,
      property_id: tenant?.property_id || form.property_id,
      expected_amount: tenant?.rent_amount || form.expected_amount,
      amount: tenant?.rent_amount || form.amount
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Paiements</h1>
          <p className="text-sm text-slate-500">{payments.length} paiement(s)</p>
        </div>
        <Button onClick={openNew} className="bg-[#0f2b4c] text-primary-foreground px-4 py-2 text-base font-medium rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 shadow h-9 hover:bg-[#1a3d6e]">
          <Plus className="w-4 h-4 mr-2" /> Enregistrer un paiement
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Tabs value={filter} onValueChange={setFilter}>
          <TabsList>
            <TabsTrigger value="all">Tous</TabsTrigger>
            <TabsTrigger value="paid">Payés</TabsTrigger>
            <TabsTrigger value="pending">En attente</TabsTrigger>
            <TabsTrigger value="late">En retard</TabsTrigger>
          </TabsList>
        </Tabs>
        <Select value={groupBy} onValueChange={setGroupBy}>
          <SelectTrigger className="w-44">
            <LayoutList className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
            <SelectValue placeholder="Grouper par..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Sans groupement</SelectItem>
            <SelectItem value="property">Par lot / bien</SelectItem>
            <SelectItem value="building">Par bâtiment</SelectItem>
            <SelectItem value="period">Par période</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={printList} title="Imprimer la liste">
            <Printer className="w-4 h-4 mr-1.5" /> Imprimer
          </Button>
          <Button variant="outline" size="sm" onClick={exportToExcel} title="Exporter en Excel">
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-emerald-600" /> Excel
          </Button>
        </div>
      </div>

      {isLoading ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div> :

      <div className="space-y-4">
        {Object.entries(groupedPayments()).map(([group, items]) =>
        <Card key={group} className="overflow-hidden">
            {group &&
          <div className="px-4 py-2 bg-slate-100 border-b text-xs font-semibold text-slate-600 uppercase tracking-wide">
                {group}
              </div>
          }
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Locataire</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Bien</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Période</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">À payer</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Payé</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Solde</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Mode</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Statut</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((p) => {
                  const solde = (p.amount || 0) - (p.expected_amount || 0);
                  const rowClass = p.status === "pending" || p.status === "late" ?
                  "border-b border-red-100 bg-red-50/40 hover:bg-red-50" :
                  p.status === "paid" && solde >= 0 ?
                  "border-b border-emerald-50 bg-emerald-50/20 hover:bg-emerald-50/40" :
                  "border-b border-slate-50 hover:bg-slate-50/50";
                  return (
                    <tr key={p.id} className={rowClass}>
                        <td className="px-4 py-3 font-medium">{p.tenant_name}</td>
                        <td className="text-slate-500 px-1 py-3">{p.property_name}</td>
                        <td className="text-slate-500 px-2 py-3">{String(p.period_month).padStart(2, "0")}/{p.period_year}</td>
                        <td className="py-3 px-4 text-right text-slate-600">{formatXAF(p.expected_amount || 0)} XAF</td>
                        <td className="text-emerald-700 px-3 py-3 font-semibold text-right">{formatXAF(p.amount)} XAF</td>
                        <td className={`py-3 px-4 text-right font-semibold ${solde >= 0 ? "text-emerald-700" : "text-red-600"}`}>{formatXAF(solde)} XAF</td>
                        <td className="text-slate-500 py-3">{methodLabels[p.payment_method] || p.payment_method}</td>
                        <td className="px-3 py-3 text-right"><span className={statusColors[p.status]}>{statusLabels[p.status]}</span></td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex justify-end gap-1">
                            {(p.status === "paid" || p.status === "partial") &&
                          <Button size="icon" variant="ghost" title="Imprimer la quittance" onClick={() => setReceiptPayment(p)}><Printer className="w-3.5 h-3.5 text-emerald-600" /></Button>
                          }
                            <Button size="icon" variant="ghost" onClick={() => openEdit(p)}><Pencil className="w-3.5 h-3.5 text-slate-500" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ?")) deleteMutation.mutate(p.id);}}><Trash2 className="w-3.5 h-3.5 text-red-500" /></Button>
                          </div>
                        </td>
                      </tr>);

                })}
                  {items.length === 0 &&
                <tr><td colSpan={9} className="text-center py-8 text-slate-400">Aucun paiement</td></tr>
                }
                  {group && items.length > 0 &&
                <tr className="bg-slate-50 font-semibold text-xs">
                      <td colSpan={3} className="py-2 px-4 text-slate-500">Sous-total {group}</td>
                      <td className="py-2 px-4 text-right text-slate-600">{formatXAF(items.reduce((s, p) => s + (p.expected_amount || 0), 0))} XAF</td>
                      <td className="py-2 px-4 text-right text-emerald-700">{formatXAF(items.reduce((s, p) => s + (p.amount || 0), 0))} XAF</td>
                      <td colSpan={4} />
                    </tr>
                }
                </tbody>
              </table>
            </div>
          </Card>
        )}
        {filtered.length === 0 &&
        <Card className="p-12 text-center text-slate-400"><Wallet className="w-10 h-10 mx-auto mb-2 text-slate-300" /><p>Aucun paiement</p></Card>
        }
      </div>
      }

      <ReceiptPrint payment={receiptPayment} settings={settings} onClose={() => setReceiptPayment(null)} />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le paiement" : "Enregistrer un paiement"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Locataire *</Label>
              <Select value={form.tenant_id || ""} onValueChange={handleTenantChange}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>{tenants.filter((t) => t.status === "active").map((t) => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Bien *</Label>
              <Select value={form.property_id || ""} onValueChange={(v) => setForm({ ...form, property_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>{properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Montant payé (XAF) *</Label><Input type="number" value={form.amount || ""} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
              <div><Label>Montant attendu (XAF)</Label><Input type="number" value={form.expected_amount || ""} onChange={(e) => setForm({ ...form, expected_amount: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Mois</Label><Input type="number" min="1" max="12" value={form.period_month || ""} onChange={(e) => setForm({ ...form, period_month: e.target.value })} /></div>
              <div><Label>Année</Label><Input type="number" value={form.period_year || ""} onChange={(e) => setForm({ ...form, period_year: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Date paiement</Label><Input type="date" value={form.payment_date || ""} onChange={(e) => setForm({ ...form, payment_date: e.target.value })} /></div>
              <div><Label>Date échéance</Label><Input type="date" value={form.due_date || ""} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Mode de paiement</Label>
                <Select value={form.payment_method || "especes"} onValueChange={(v) => setForm({ ...form, payment_method: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(methodLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Statut</Label>
                <Select value={form.status || "paid"} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(statusLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Référence</Label><Input value={form.reference || ""} onChange={(e) => setForm({ ...form, reference: e.target.value })} /></div>
            <div><Label>Notes</Label><Input value={form.notes || ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}