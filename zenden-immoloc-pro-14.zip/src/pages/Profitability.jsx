import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, TrendingDown, Building2, Home, Percent, Target, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}
function pct(v) {return isNaN(v) || !isFinite(v) ? "—" : `${v.toFixed(1)}%`;}

function RentabilityBadge({ value }) {
  if (!isFinite(value) || isNaN(value)) return <Badge variant="outline">—</Badge>;
  if (value >= 8) return <Badge className="bg-emerald-100 text-emerald-700">Excellent ({pct(value)})</Badge>;
  if (value >= 5) return <Badge className="bg-blue-100 text-blue-700">Bon ({pct(value)})</Badge>;
  if (value >= 3) return <Badge className="bg-amber-100 text-amber-700">Moyen ({pct(value)})</Badge>;
  return <Badge className="bg-red-100 text-red-700">Faible ({pct(value)})</Badge>;
}

export default function Profitability() {
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const y = Number(year);
  const currentYear = new Date().getFullYear();

  const { data: properties = [], isLoading: lp } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: buildings = [], isLoading: lb } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list() });
  const { data: payments = [], isLoading: lpay } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: charges = [], isLoading: lc } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });

  const isLoading = lp || lb || lpay || lc;

  const yearPayments = payments.filter((p) => p.period_year === y && (p.status === "paid" || p.status === "partial"));
  const yearCharges = charges.filter((c) => new Date(c.date).getFullYear() === y);

  // Per-property stats
  const propertyStats = useMemo(() => properties.map((prop) => {
    const revenue = yearPayments.filter((p) => p.property_id === prop.id).reduce((s, p) => s + (p.amount || 0), 0);
    const expense = yearCharges.filter((c) => c.property_id === prop.id).reduce((s, c) => s + (c.amount || 0), 0);
    const net = revenue - expense;
    const annualRent = (prop.rent_amount || 0) * 12;
    // Rendement brut = (loyers annuels théoriques / valeur bien) — sans valeur on utilise le ratio loyer/charges
    const grossYield = annualRent > 0 ? revenue / annualRent * 100 : 0; // taux d'encaissement
    // Occupation : mois où un paiement a été fait / 12
    const paidMonths = new Set(yearPayments.filter((p) => p.property_id === prop.id).map((p) => p.period_month)).size;
    const occupancyRate = paidMonths / 12 * 100;
    const netYield = annualRent > 0 ? net / annualRent * 100 : 0;
    const building = buildings.find((b) => b.id === prop.building_id);
    const tenant = tenants.find((t) => t.property_id === prop.id && t.status === "active");
    return { ...prop, revenue, expense, net, annualRent, grossYield, netYield, occupancyRate, paidMonths, building, tenant };
  }), [properties, yearPayments, yearCharges, buildings, tenants]);

  // Per-building stats
  const buildingStats = useMemo(() => buildings.map((bld) => {
    const bldProperties = propertyStats.filter((p) => p.building_id === bld.id);
    const revenue = bldProperties.reduce((s, p) => s + p.revenue, 0);
    const expense = bldProperties.reduce((s, p) => s + p.expense, 0);
    // Also add global charges attached to the building (no property_id)
    const globalExpense = yearCharges.filter((c) => !c.property_id && c.is_global).reduce((s, c) => s + (c.amount || 0), 0) / (buildings.length || 1);
    const net = revenue - expense - globalExpense;
    const annualRent = bldProperties.reduce((s, p) => s + p.annualRent, 0);
    const grossYield = annualRent > 0 ? revenue / annualRent * 100 : 0;
    const netYield = annualRent > 0 ? net / annualRent * 100 : 0;
    const occupancyRate = bldProperties.length > 0 ? bldProperties.reduce((s, p) => s + p.occupancyRate, 0) / bldProperties.length : 0;
    const occupied = bldProperties.filter((p) => p.status === "occupied").length;
    return { ...bld, bldProperties, revenue, expense, net, annualRent, grossYield, netYield, occupancyRate, occupied, total: bldProperties.length };
  }), [buildings, propertyStats, yearCharges]);

  const chartData = propertyStats.
  filter((p) => p.annualRent > 0).
  map((p) => ({ name: p.name.length > 14 ? p.name.slice(0, 14) + "…" : p.name, revenus: p.revenue, charges: p.expense, net: p.net })).
  sort((a, b) => b.revenus - a.revenus).
  slice(0, 12);

  if (isLoading) return <div className="space-y-4">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}</div>;

  const totalRevenue = propertyStats.reduce((s, p) => s + p.revenue, 0);
  const totalExpense = propertyStats.reduce((s, p) => s + p.expense, 0);
  const totalAnnualRent = propertyStats.reduce((s, p) => s + p.annualRent, 0);
  const avgOccupancy = propertyStats.length > 0 ? propertyStats.reduce((s, p) => s + p.occupancyRate, 0) / propertyStats.length : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Analyse de rentabilité</h1>
          <p className="text-sm text-slate-500">Rendement par bien et par immeuble</p>
        </div>
        <Select value={year} onValueChange={setYear}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[currentYear, currentYear - 1, currentYear - 2].map((yy) => <SelectItem key={yy} value={String(yy)}>{yy}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* KPIs globaux */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 flex items-center justify-center"><TrendingUp className="w-5 h-5 text-emerald-600" /></div>
            <div>
              <p className="text-xs text-slate-500">Revenus encaissés</p>
              <p className="text-sm font-bold">{formatXAF(totalRevenue)} XAF</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-red-100 flex items-center justify-center"><TrendingDown className="w-5 h-5 text-red-600" /></div>
            <div>
              <p className="text-xs text-slate-500">Charges totales</p>
              <p className="text-sm font-bold">{formatXAF(totalExpense)} XAF</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center"><Percent className="w-5 h-5 text-blue-600" /></div>
            <div>
              <p className="text-xs text-slate-500">Taux d'encaissement</p>
              <p className="text-sm font-bold">{totalAnnualRent > 0 ? pct(totalRevenue / totalAnnualRent * 100) : "—"}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-violet-100 flex items-center justify-center"><Target className="w-5 h-5 text-violet-600" /></div>
            <div>
              <p className="text-xs text-slate-500">Taux d'occupation moy.</p>
              <p className="text-sm font-bold">{pct(avgOccupancy)}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Graphique */}
      {chartData.length > 0 &&
      <Card className="p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Revenus vs Charges par bien ({year})</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData} barGap={2}>
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => formatXAF(v)} width={80} />
              <Tooltip formatter={(v) => formatXAF(v) + " XAF"} />
              <Bar dataKey="revenus" fill="#10b981" radius={[4, 4, 0, 0]} name="Revenus" />
              <Bar dataKey="charges" fill="#f87171" radius={[4, 4, 0, 0]} name="Charges" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      }

      <Tabs defaultValue="properties">
        <TabsList>
          <TabsTrigger value="properties"><Home className="w-4 h-4 mr-1.5" />Par bien</TabsTrigger>
          <TabsTrigger value="buildings"><Building2 className="w-4 h-4 mr-1.5" />Par immeuble</TabsTrigger>
        </TabsList>

        {/* Par bien */}
        <TabsContent value="properties" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Bien</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Locataire</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Loyer théorique/an</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Encaissé {year}</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Charges</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Net</th>
                    <th className="text-center py-3 px-4 text-xs font-medium text-slate-500">Occupation</th>
                    <th className="text-center py-3 px-4 text-xs font-medium text-slate-500">Rentabilité</th>
                  </tr>
                </thead>
                <tbody>
                  {propertyStats.map((p) =>
                  <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                      <td className="py-3 px-4">
                        <p className="px-2 font-medium">{p.name}</p>
                        <p className="text-[10px] text-slate-400">{p.building_name || p.city || ""}</p>
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-xs">{p.tenant ? `${p.tenant.first_name} ${p.tenant.last_name}` : <span className="text-amber-500">Vacant</span>}</td>
                      <td className="py-3 px-4 text-right text-slate-500">{formatXAF(p.annualRent)}</td>
                      <td className="py-3 px-4 text-right text-emerald-600 font-medium">{formatXAF(p.revenue)}</td>
                      <td className="py-3 px-4 text-right text-red-500">{formatXAF(p.expense)}</td>
                      <td className={`py-3 px-4 text-right font-bold ${p.net >= 0 ? "text-emerald-700" : "text-red-600"}`}>{formatXAF(p.net)}</td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <div className="w-20 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(p.occupancyRate, 100)}%` }} />
                          </div>
                          <span className="text-[10px] text-slate-500">{pct(p.occupancyRate)}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <RentabilityBadge value={p.netYield} />
                      </td>
                    </tr>
                  )}
                  {propertyStats.length === 0 &&
                  <tr><td colSpan={8} className="text-center py-10 text-slate-400"><AlertCircle className="w-8 h-8 mx-auto mb-2 text-slate-300" /><p>Aucun bien enregistré</p></td></tr>
                  }
                </tbody>
              </table>
            </div>
          </Card>
          <p className="text-xs text-slate-400 mt-2">* La rentabilité nette est calculée sur la base des loyers théoriques annuels. Pour obtenir le rendement réel, renseignez la valeur d'achat dans les paramètres du bien.</p>
        </TabsContent>

        {/* Par immeuble */}
        <TabsContent value="buildings" className="mt-4">
          {buildingStats.length === 0 ?
          <Card className="p-12 text-center text-slate-400">
              <Building2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun immeuble enregistré</p>
            </Card> :

          <div className="space-y-4">
              {buildingStats.map((bld) =>
            <Card key={bld.id} className="overflow-hidden">
                  <div className="px-5 py-4 bg-gradient-to-r from-slate-700 to-slate-800 text-white flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-5 h-5 text-emerald-400" />
                      <div>
                        <p className="font-semibold">{bld.name}</p>
                        <p className="text-xs text-slate-300">{bld.city} — {bld.total} lot(s) — {bld.occupied} occupé(s)</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6 text-right">
                      <div>
                        <p className="text-xs text-slate-400">Revenus {year}</p>
                        <p className="font-bold text-emerald-400">{formatXAF(bld.revenue)} XAF</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400">Net</p>
                        <p className={`font-bold ${bld.net >= 0 ? "text-emerald-400" : "text-red-400"}`}>{formatXAF(bld.net)} XAF</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400">Rentabilité</p>
                        <p className="font-bold text-white">{pct(bld.netYield)}</p>
                      </div>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-slate-50">
                          <th className="text-left py-2 px-4 text-xs font-medium text-slate-500">Lot</th>
                          <th className="text-left py-2 px-4 text-xs font-medium text-slate-500">Locataire</th>
                          <th className="text-right py-2 px-4 text-xs font-medium text-slate-500">Encaissé</th>
                          <th className="text-right py-2 px-4 text-xs font-medium text-slate-500">Charges</th>
                          <th className="text-right py-2 px-4 text-xs font-medium text-slate-500">Net</th>
                          <th className="text-center py-2 px-4 text-xs font-medium text-slate-500">Occupation</th>
                        </tr>
                      </thead>
                      <tbody>
                        {bld.bldProperties.map((p) =>
                    <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                            <td className="py-2 px-4 font-medium text-sm">{p.name}</td>
                            <td className="py-2 px-4 text-xs text-slate-500">{p.tenant ? `${p.tenant.first_name} ${p.tenant.last_name}` : <span className="text-amber-500">Vacant</span>}</td>
                            <td className="py-2 px-4 text-right text-emerald-600">{formatXAF(p.revenue)}</td>
                            <td className="py-2 px-4 text-right text-red-500">{formatXAF(p.expense)}</td>
                            <td className={`py-2 px-4 text-right font-semibold ${p.net >= 0 ? "text-emerald-700" : "text-red-600"}`}>{formatXAF(p.net)}</td>
                            <td className="py-2 px-4 text-center text-xs text-slate-500">{pct(p.occupancyRate)}</td>
                          </tr>
                    )}
                        {bld.bldProperties.length === 0 &&
                    <tr><td colSpan={6} className="py-4 text-center text-slate-400 text-xs">Aucun lot rattaché</td></tr>
                    }
                      </tbody>
                    </table>
                  </div>
                </Card>
            )}
            </div>
          }
        </TabsContent>
      </Tabs>
    </div>);

}