import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, Mail, MessageCircle, Printer, Loader } from "lucide-react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const INTERNAL_RULES_CONTENT = {
  title: "Règlement Intérieur",
  subtitle: "Des Locataires",
  preamble: "Le présent règlement intérieur a pour but de garantir la bonne entente entre les locataires, le respect du voisinage, ainsi qu'un cadre de vie agréable et sécurisé pour tous. Il complète les dispositions du contrat de bail et doit être respecté par tous les occupants, y compris les enfants.",
  articles: [
    {
      num: 1,
      title: "Respect du voisinage et du vivre ensemble",
      content: "Tout locataire s'engage à adopter un comportement respectueux envers ses voisins.\n\nLes nuisances sonores sont interdites à toute heure. Une tolérance de jeux calmes est autorisée aux enfants entre 16h00 et 18h00, dans le respect du silence.\n\nLes comportements inappropriés, tels qu'uriner depuis les balcons ou lancer des objets par les fenêtres, sont strictement interdits. Ces actes sont considérés comme graves et peuvent entraîner la résiliation du bail.\n\nIl est demandé à chaque locataire de veiller à ce que ses enfants respectent les règles élémentaires de vie en communauté."
    },
    {
      num: 2,
      title: "Propreté et entretien des espaces communs",
      content: "Chaque locataire est responsable de la propreté de son logement et des espaces communs de l'immeuble (escaliers, couloirs, cour, etc.).\n\nL'élimination des ordures doit se faire conformément aux horaires définis par le syndic ou le bailleur.\n\nLa surcharge des poubelles ou le dépôt d'ordures en dehors des conteneurs est strictement interdit.\n\nL'utilisation des espaces communs doit respecter le calendrier de nettoyage établi. Chaque locataire participe à l'entretien collectif selon les modalités prévues."
    },
    {
      num: 3,
      title: "Animaux domestiques",
      content: "Les animaux domestiques sont autorisés dans le logement, sous réserve de l'accord préalable écrit du bailleur et du respect des conditions du bail.\n\nLe locataire est responsable de son animal et doit éviter tout désagrément aux voisins (bruit, saleté, agressivité).\n\nLes frais de nettoyage ou de réparation occasionnés par un animal restent à la charge du locataire."
    },
    {
      num: 4,
      title: "Stationnement et circulation",
      content: "Le stationnement des véhicules doit se faire conformément à la réglementation en vigueur et aux indications de l'immeuble.\n\nL'entretien et la réparation des véhicules dans les espaces communs sont interdits.\n\nLes deux-roues (motos, scooters, vélos) doivent être garés de manière à ne pas entraver la circulation ou la sécurité des résidents."
    },
    {
      num: 5,
      title: "Modification et aménagement du logement",
      content: "Toute modification du logement (peinture, pose de clous, installation de rayonnages, etc.) doit être préalablement autorisée par le bailleur par écrit.\n\nLes travaux importants de rénovation doivent respecter les horaires autorisés et ne pas causer de nuisances aux voisins.\n\nLes installations (climatiseurs, paraboles, etc.) doivent être conformes aux règles de l'immeuble et à la sécurité."
    },
    {
      num: 6,
      title: "Accès et visites",
      content: "Les visites doivent être limitées à des horaires raisonnables et ne doivent pas perturber le voisinage.\n\nLe bailleur ou son représentant se réserve le droit d'accéder au logement dans les conditions prévues par le bail (visites, réparations, inspections).\n\nUn préavis de 48 heures doit être donné sauf urgence."
    },
    {
      num: 7,
      title: "Interdictions spécifiques",
      content: "L'exercice d'une activité professionnelle ou commerciale au sein du logement est interdit, sauf autorisation préalable du bailleur.\n\nLa fabrication, la possession ou la consommation de substances illicites est strictement interdite.\n\nLa possession ou l'utilisation d'armes est soumise à la réglementation en vigueur.\n\nL'hébergement prolongé de personnes non-locataires sans l'accord du bailleur est interdit."
    },
    {
      num: 8,
      title: "Sécurité et incendie",
      content: "Tout locataire doit respecter les règles de sécurité incendie et ne pas obstruer les issues de secours.\n\nLes équipements de sécurité (extincteurs, détecteurs de fumée) ne doivent pas être endommagés ou désactivés.\n\nEn cas d'incendie ou d'urgence, les procédures d'évacuation doivent être immédiatement suivies."
    },
    {
      num: 9,
      title: "Paiement des loyers et charges",
      content: "Les loyers et charges doivent être payés à la date convenue, selon les modalités stipulées au contrat de bail.\n\nTout retard de paiement entraînera des pénalités conformément à la législation en vigueur.\n\nLes factures d'eau, d'électricité et autres services doivent être réglées par le locataire dans les délais impartis."
    },
    {
      num: 10,
      title: "Sanctions et résiliation",
      content: "Le non-respect du présent règlement peut entraîner des avertissements ou une mise en demeure.\n\nEn cas de violation grave ou répétée, le bailleur se réserve le droit de résilier le bail conformément à la législation applicable.\n\nLe locataire peut être tenu responsable des dommages causés à l'immeuble ou au bien d'autrui."
    }
  ]
};

export default function InternalRules() {
  const [loading, setLoading] = useState(false);
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const generatePDFFromHTML = async () => {
    const element = document.getElementById("rules-document");
    if (!element) return null;

    const canvas = await html2canvas(element, { 
      scale: 2,
      useCORS: true,
      logging: false
    });
    
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({
      orientation: "p",
      unit: "mm",
      format: "a4"
    });
    
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 10;
    const imgWidth = pageWidth - (margin * 2);
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    let yPosition = margin;
    let imgPosition = 0;
    const pageHeightAvailable = pageHeight - (margin * 2);
    
    pdf.addImage(imgData, "PNG", margin, yPosition, imgWidth, imgHeight);
    
    let totalHeight = imgHeight;
    while (totalHeight > pageHeightAvailable) {
      totalHeight -= pageHeightAvailable;
      pdf.addPage();
      yPosition = margin - (imgHeight - totalHeight);
      pdf.addImage(imgData, "PNG", margin, yPosition, imgWidth, imgHeight);
    }
    
    return pdf;
  };

  const handlePrintPDF = async () => {
    setLoading(true);
    try {
      const pdf = await generatePDFFromHTML();
      if (pdf) {
        pdf.save("Reglement_Interieur.pdf");
      }
    } catch (error) {
      console.error("Erreur PDF:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    setLoading(true);
    try {
      const pdf = await generatePDFFromHTML();
      if (pdf) pdf.save("Reglement_Interieur.pdf");
    } catch (error) {
      console.error("Erreur PDF:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsApp = async () => {
    setLoading(true);
    try {
      await generatePDFFromHTML();
      const text = `📋 *${INTERNAL_RULES_CONTENT.title}*\n\nVeuillez prendre connaissance du règlement intérieur de l'immeuble.\n\nCordialement,\n${settings?.owner_name || "La direction"}`;
      const link = `https://wa.me/?text=${encodeURIComponent(text)}`;
      window.open(link, "_blank");
    } catch (error) {
      console.error("Erreur:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEmail = () => {
    const subject = `${INTERNAL_RULES_CONTENT.title} - ${settings?.company_name || "Zenden Immo"}`;
    const body = `Madame, Monsieur,\n\nVeuillez trouver ci-joint le règlement intérieur de l'immeuble que vous occupez.\n\nVous êtes tenu de respecter les dispositions qui y sont mentionnées.\n\nCordialement,\n${settings?.owner_name || "La direction"}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const generateDocumentHTML = () => {
    return `
      <!DOCTYPE html>
      <html lang="fr">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${INTERNAL_RULES_CONTENT.title}</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px 20px; color: #333; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 3px solid #0f2b4c; padding-bottom: 20px; }
          .company-name { font-size: 12px; color: #666; margin-bottom: 10px; }
          .title { font-size: 28px; font-weight: bold; color: #0f2b4c; margin: 0; }
          .subtitle { font-size: 16px; color: #10b981; margin: 5px 0 0 0; }
          .preamble { font-style: italic; color: #555; margin: 30px 0; padding: 15px; background: #f8fafc; border-left: 4px solid #10b981; }
          .article { margin: 25px 0; page-break-inside: avoid; }
          .article-header { font-weight: bold; color: #0f2b4c; margin-bottom: 10px; }
          .article-num { color: #10b981; font-weight: bold; }
          .article-content { text-align: justify; }
          .footer { margin-top: 50px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #e2e8f0; padding-top: 20px; }
          .signature-line { margin-top: 60px; display: flex; justify-content: space-between; }
          .signature-block { width: 40%; text-align: center; }
          .signature-block p { margin: 30px 0 0 0; border-top: 1px solid #333; padding-top: 10px; font-size: 12px; }
          @media print { body { padding: 0; } .no-print { display: none; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${settings?.company_name || "Zenden Immo"}</div>
          <h1 class="title">${INTERNAL_RULES_CONTENT.title}</h1>
          <p class="subtitle">${INTERNAL_RULES_CONTENT.subtitle}</p>
        </div>

        <div class="preamble">
          ${INTERNAL_RULES_CONTENT.preamble}
        </div>

        ${INTERNAL_RULES_CONTENT.articles.map(article => `
          <div class="article">
            <div class="article-header">
              <span class="article-num">Article ${article.num}</span> – ${article.title}
            </div>
            <div class="article-content">
              ${article.content.split('\n\n').map(p => `<p>${p}</p>`).join('')}
            </div>
          </div>
        `).join('')}

        <div class="signature-line">
          <div class="signature-block">
            <p>Le locataire</p>
          </div>
          <div class="signature-block">
            <p>Le bailleur<br/>${settings?.owner_name || ''}</p>
          </div>
        </div>

        <div class="footer">
          <p>Document établi le ${new Date().toLocaleDateString('fr-FR')}</p>
          <p>© ${new Date().getFullYear()} ${settings?.company_name || "Zenden Immo"} - Tous droits réservés</p>
        </div>
      </body>
      </html>
    `;
  };

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-700 text-white rounded-xl p-8 shadow-lg">
        <h1 className="text-3xl font-bold mb-2">Règlement Intérieur</h1>
        <p className="text-blue-100 text-sm">Document à distribuer à chaque locataire</p>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 no-print">
        <Button 
          onClick={handlePrintPDF} 
          variant="outline" 
          className="gap-2 h-auto flex-col py-3"
          disabled={loading}
        >
          {loading ? <Loader className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          <span className="text-xs">PDF</span>
        </Button>
        <Button 
          onClick={handleDownload} 
          variant="outline" 
          className="gap-2 h-auto flex-col py-3"
          disabled={loading}
        >
          {loading ? <Loader className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          <span className="text-xs">Télécharger</span>
        </Button>
        <Button 
          onClick={handleWhatsApp} 
          variant="outline" 
          className="gap-2 h-auto flex-col py-3"
          disabled={loading}
        >
          {loading ? <Loader className="w-4 h-4 animate-spin" /> : <MessageCircle className="w-4 h-4" />}
          <span className="text-xs">WhatsApp</span>
        </Button>
        <Button 
          onClick={handleEmail} 
          variant="outline" 
          className="gap-2 h-auto flex-col py-3"
          disabled={loading}
        >
          <Mail className="w-4 h-4" />
          <span className="text-xs">Email</span>
        </Button>
      </div>

      {/* Document - Printable Area */}
      <div id="rules-document" className="bg-white rounded-lg shadow-sm" style={{ padding: '40px 30px' }}>
        {/* Header */}
        <div className="text-center mb-8 pb-6 border-b-2 border-slate-300">
          <p className="text-xs text-slate-600 mb-2 uppercase tracking-wide font-semibold">{settings?.company_name || "Zenden Immo"}</p>
          <h1 className="text-2xl font-bold text-blue-900 mb-1">{INTERNAL_RULES_CONTENT.title}</h1>
          <p className="text-sm text-emerald-600 font-medium">{INTERNAL_RULES_CONTENT.subtitle}</p>
        </div>

        {/* Preamble */}
        <div className="mb-8 p-4 bg-blue-50 border-l-4 border-emerald-500">
          <p className="text-sm text-slate-700 leading-relaxed italic">
            {INTERNAL_RULES_CONTENT.preamble}
          </p>
        </div>

        {/* Articles */}
        <div className="space-y-6 mb-12">
          {INTERNAL_RULES_CONTENT.articles.map((article) => (
            <div key={article.num} className="page-break-inside-avoid">
              <h3 className="font-bold text-slate-800 mb-2">
                <span className="text-emerald-600">Article {article.num}</span> – {article.title}
              </h3>
              <div className="text-sm text-slate-700 space-y-2">
                {article.content.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-justify leading-relaxed">{paragraph}</p>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Signatures */}
         <div className="mt-16 pt-8 border-t border-slate-300">
           <div className="grid grid-cols-2 gap-8">
             <div className="text-center">
               <div className="h-16 mb-2"></div>
               <div className="border-t-2 border-slate-800 pt-3">
                 <p className="text-xs font-semibold text-slate-700">Le locataire</p>
               </div>
             </div>
             <div className="text-center">
               {settings?.signature_url && (
                 <img src={settings.signature_url} alt="Signature" className="h-16 mx-auto mb-2 object-contain" />
               )}
               {!settings?.signature_url && <div className="h-16 mb-2"></div>}
               <div className="border-t-2 border-slate-800 pt-3">
                 <p className="text-xs font-semibold text-slate-700">{settings?.owner_name || "Le bailleur / La direction"}</p>
               </div>
             </div>
           </div>
         </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-500 mt-8 pt-4 border-t border-slate-200">
          <p>Document établi le {new Date().toLocaleDateString('fr-FR')}</p>
          <p>© {new Date().getFullYear()} {settings?.company_name || "Zenden Immo"}</p>
        </div>
      </div>
    </div>
  );
}