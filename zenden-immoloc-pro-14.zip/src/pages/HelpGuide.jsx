import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

const HELP_SECTIONS = [
  {
    id: "dashboard",
    title: "Tableau de bord",
    icon: "📊",
    content: "Le tableau de bord affiche un aperçu global de vos propriétés, loyers et paiements. Consultez les KPI principaux et les alertes importantes pour une gestion efficace.",
    items: [
      "Vue d'ensemble des revenus et encaissements",
      "Statut des paiements en retard",
      "Alertes locataires (fins de bail, impayés)",
      "Derniers paiements reçus"
    ]
  },
  {
    id: "tenants",
    title: "Gestion des locataires",
    icon: "👥",
    content: "Gérez les informations de vos locataires, leurs contrats et leur historique de paiement.",
    items: [
      "Ajouter ou modifier un locataire",
      "Consulter l'historique des paiements",
      "Voir les documents (baux, EDL, quittances)",
      "Suivre les interactions et communications",
      "Archiver les locataires inactifs"
    ]
  },
  {
    id: "payments",
    title: "Suivi des paiements",
    icon: "💰",
    content: "Enregistrez et suivez tous les paiements de loyers. Générez des quittances et suivez les impayés.",
    items: [
      "Créer un paiement manuellement",
      "Générer une quittance (imprimer ou PDF)",
      "Envoyer une quittance par email ou WhatsApp",
      "Filtrer par statut (payé, partiel, en retard)",
      "Grouper par propriété ou période"
    ]
  },
  {
    id: "leases",
    title: "Gestion des baux",
    icon: "📄",
    content: "Créez et gérez les contrats de bail. Générez des documents professionnels prêts à être signés.",
    items: [
      "Créer un nouveau bail",
      "Utiliser des modèles de contrats",
      "Générer un contrat PDF",
      "Ajouter des clauses spécifiques",
      "Archiver les baux expirés"
    ]
  },
  {
    id: "appel-loyer",
    title: "Appel à loyer",
    icon: "🔔",
    content: "Générez et envoyez les avis d'échéance de loyer à vos locataires mensuellement.",
    items: [
      "Créer l'appel de loyer du mois",
      "Voir le statut des avis envoyés",
      "Envoyer par email ou WhatsApp",
      "Imprimer les avis",
      "Suivre qui a reçu l'avis"
    ]
  },
  {
    id: "charges",
    title: "Charges et dépenses",
    icon: "💸",
    content: "Enregistrez toutes vos dépenses et charges liées aux propriétés.",
    items: [
      "Ajouter une charge (maintenance, réparation, etc.)",
      "Catégoriser les charges",
      "Joindre les justificatifs",
      "Calculer les allocations par locataire",
      "Générer des rapports de charges"
    ]
  },
  {
    id: "edl",
    title: "États des lieux (EDL)",
    icon: "📋",
    content: "Documentez l'état des propriétés à l'entrée et à la sortie des locataires.",
    items: [
      "Créer un EDL d'entrée",
      "Créer un EDL de sortie",
      "Documenter l'état par pièce",
      "Enregistrer les lectures de compteurs",
      "Imprimer ou générer en PDF"
    ]
  },
  {
    id: "documents",
    title: "Gestion des documents (GED)",
    icon: "📁",
    content: "Centralisez tous vos documents : baux, quittances, correspondances, etc.",
    items: [
      "Uploader des documents",
      "Organiser par type et catégorie",
      "Associer aux locataires et propriétés",
      "Versionner les documents",
      "Télécharger ou archiver"
    ]
  },
  {
    id: "rappels",
    title: "Rappels et alertes",
    icon: "⏰",
    content: "Configurer des rappels automatiques pour les événements importants.",
    items: [
      "Rappels de fins de bail à venir",
      "Alertes de loyers impayés",
      "Notifications de documents manquants",
      "Rappels de renouvellement d'assurance",
      "Personnaliser les délais de notification"
    ]
  },
  {
    id: "finances",
    title: "Rapports financiers",
    icon: "📈",
    content: "Analysez vos finances et générez des rapports pour la comptabilité.",
    items: [
      "Tableau des encaissements",
      "Statistiques financières mensuelles et annuelles",
      "Rentabilité par propriété",
      "Grand livre et balance",
      "Exporter les données en CSV"
    ]
  },
  {
    id: "reglement",
    title: "Règlement intérieur",
    icon: "📜",
    content: "Créez et distribuez le règlement intérieur à vos locataires.",
    items: [
      "Générer le document PDF",
      "Télécharger le règlement",
      "Envoyer par email ou WhatsApp",
      "Personnaliser les règles",
      "Faire signer les locataires"
    ]
  },
  {
    id: "parametres",
    title: "Paramètres de l'application",
    icon: "⚙️",
    content: "Configurez les paramètres généraux de votre application.",
    items: [
      "Informations de l'entreprise",
      "Paramètres de facturation",
      "Signature numérique",
      "Logo personnalisé",
      "Taux TVA par défaut"
    ]
  }
];

export default function HelpGuide() {
  const [expandedId, setExpandedId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const filtered = HELP_SECTIONS.filter(section =>
    section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.items?.some(item => item.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-700 text-white rounded-xl p-8 shadow-lg">
        <h1 className="text-3xl font-bold mb-2">Aide & Mode d'emploi</h1>
        <p className="text-blue-100 text-sm">Trouvez les réponses à vos questions sur l'utilisation de l'application</p>
      </div>

      {/* Barre de recherche */}
      <div className="relative">
        <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
        <Input
          placeholder="Rechercher dans l'aide..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 h-10"
        />
      </div>

      {/* Sections d'aide */}
      <div className="space-y-3">
        {filtered.map(section => (
          <Card key={section.id} className="overflow-hidden hover:shadow-md transition-shadow">
            <button
              onClick={() => setExpandedId(expandedId === section.id ? null : section.id)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors text-left"
            >
              <div className="flex items-center gap-3 flex-1">
                <span className="text-2xl">{section.icon}</span>
                <div>
                  <h3 className="font-semibold text-slate-800">{section.title}</h3>
                  <p className="text-xs text-slate-500 line-clamp-1">{section.content}</p>
                </div>
              </div>
              <ChevronDown
                className={`w-5 h-5 text-slate-400 transition-transform shrink-0 ${
                  expandedId === section.id ? "rotate-180" : ""
                }`}
              />
            </button>

            {expandedId === section.id && (
              <div className="border-t border-slate-100 bg-slate-50 p-4 space-y-3">
                <p className="text-sm text-slate-700">{section.content}</p>

                {section.items && section.items.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Points clés :</p>
                    <ul className="space-y-1.5">
                      {section.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                          <span className="text-emerald-600 font-bold mt-0.5">✓</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </Card>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-500">Aucune section d'aide ne correspond à votre recherche.</p>
          </div>
        )}
      </div>

      {/* Section FAQ / Conseils */}
      <Card className="bg-blue-50 border-blue-200 p-6">
        <h3 className="font-semibold text-slate-800 mb-4">💡 Conseils pratiques</h3>
        <ul className="space-y-2 text-sm text-slate-700">
          <li>• <strong>Mises à jour mensuelles :</strong> Pensez à créer l'appel de loyer et les paiements chaque mois.</li>
          <li>• <strong>Sauvegardes :</strong> Les documents importants (baux, EDL) sont conservés dans la section Documents.</li>
          <li>• <strong>Notifications :</strong> Configurez les rappels pour ne rien oublier (fins de bail, renouvellements).</li>
          <li>• <strong>Exports :</strong> Vous pouvez exporter vos rapports financiers en CSV pour vos déclarations.</li>
          <li>• <strong>Archivage :</strong> Archivez les locataires et propriétés inactifs pour garder votre base propre.</li>
        </ul>
      </Card>
    </div>
  );
}