import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, AlertTriangle, Building2, Calendar } from "lucide-react";
import { Card } from "@/components/ui/card";

const MONTHS_FR = ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"];
const TYPE_LABELS = { appartement: "Appartement", maison: "Maison", studio: "Studio", local_commercial: "Local comm.", parking: "Parking", autre: "Autre" };
const PIE_COLORS = ["#10b981","#3b82f6","#f59e0b","#ef4444","#8b5cf6","#06b6d4"];

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(Math.round(v || 0)); }

export default function FinancialStats() {
  const { data: payments = [] } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: leases = [] } = useQuery({ queryKey: ["leases"], queryFn: () => base44.entities.Lease.list() });

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  // 1. Revenus par type de bien
  const revenueByType = useMemo(() => {
    const map = {};
    payments.filter(p => p.status === "paid" || p.status === "partial").forEach(p => {
      const prop = properties.find(pr => pr.id === p.property_id);
      const type = prop?.type || "autre";
      map[type] = (map[type] || 0) + (p.amount || 0);
    });
    return Object.entries(map).map(([type, total]) => ({
      name: TYPE_LABELS[type] || type,
      total,
      fill: PIE_COLORS[Object.keys(TYPE_LABELS).indexOf(type) % PIE_COLORS.length] || "#94a3b8"
    })).sort((a, b) => b.total - a.total);
  }, [payments, properties]);

  // 2. Taux d'impayés par mois (12 derniers mois)
  const unpaidRateByMonth = useMemo(() => {
    const months = [];
    for (let i = 11; i >= 0; i--) {
      let m = currentMonth - i;
      let y = currentYear;
      if (m <= 0) { m += 12; y -= 1; }
      const monthPayments = payments.filter(p => p.period_month === m && p.period_year === y);
      const total = monthPayments.length;
      const unpaid = monthPayments.filter(p => p.status === "late" || p.status === "pending").length;
      const rate = total > 0 ? Math.round((unpaid / total) * 100) : 0;
      months.push({ label: `${MONTHS_FR[m - 1]} ${y === currentYear ? "" : y}`.trim(), rate, total, unpaid });
    }
    return months;
  }, [payments, currentYear, currentMonth]);

  // 3. Projection annuelle basée sur les baux actifs
  const annualProjection = useMemo(() => {
    const activeLeases = leases.filter(l => l.status === "active");
    const monthlyRevenue = activeLeases.reduce((s, l) => s + (l.rent_amount || 0) + (l.charges_amount || 0), 0);
    const annualProjected = monthlyRevenue * 12;

    // Revenus réels mois par mois pour l'année courante
    const realByMonth = MONTHS_FR.map((label, idx) => {
      const m = idx + 1;
      const collected = payments
        .filter(p => p.period_month === m && p.period_year === currentYear && (p.status === "paid" || p.status === "partial"))
        .reduce((s, p) => s + (p.amount || 0), 0);
      const projected = monthlyRevenue;
      return { label, collecté: collected, projeté: projected };
    });

    return { annualProjected, monthlyRevenue, activeLeases: activeLeases.length, realByMonth };
  }, [leases, payments, currentYear]);

  // KPIs
  const totalCollectedYear = payments
    .filter(p => p.period_year === currentYear && (p.status === "paid" || p.status === "partial"))
    .reduce((s, p) => s + (p.amount || 0), 0);

  const avgUnpaidRate = unpaidRateByMonth.length > 0
    ? Math.round(unpaidRateByMonth.reduce((s, m) => s + m.rate, 0) / unpaidRateByMonth.filter(m => m.total > 0).length || 0)
    : 0;

  const collectionRate = annualProjection.annualProjected > 0
    ? Math.round((totalCollectedYear / annualProjection.annualProjected) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Projection annuelle</p>
              <p className="font-bold text-slate-800 text-sm">{formatXAF(annualProjection.annualProjected)} XAF</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Encaissé {currentYear}</p>
              <p className="font-bold text-slate-800 text-sm">{formatXAF(totalCollectedYear)} XAF</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${avgUnpaidRate > 20 ? "bg-red-100" : "bg-amber-100"}`}>
              <AlertTriangle className={`w-5 h-5 ${avgUnpaidRate > 20 ? "text-red-600" : "text-amber-600"}`} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Taux impayés moy.</p>
              <p className={`font-bold text-sm ${avgUnpaidRate > 20 ? "text-red-600" : "text-amber-700"}`}>{avgUnpaidRate}%</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Taux de collecte</p>
              <p className={`font-bold text-sm ${collectionRate >= 80 ? "text-emerald-600" : "text-red-600"}`}>{collectionRate}%</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Graphiques ligne 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Répartition par type de bien */}
        <Card className="p-5">
          <h3 className="font-semibold text-slate-800 mb-1 text-sm">Revenus par type de bien</h3>
          <p className="text-xs text-slate-400 mb-4">Cumul des encaissements par catégorie de logement</p>
          {revenueByType.length === 0 ? (
            <div className="flex items-center justify-center h-48 text-slate-400 text-sm">Aucune donnée disponible</div>
          ) : (
            <div className="flex flex-col md:flex-row items-center gap-4">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={revenueByType} dataKey="total" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }) => `${name} ${Math.round(percent * 100)}%`} labelLine={false}>
                    {revenueByType.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip formatter={(v) => `${formatXAF(v)} XAF`} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 min-w-[140px]">
                {revenueByType.map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span className="w-3 h-3 rounded-full shrink-0" style={{ background: item.fill }} />
                    <span className="text-slate-600 truncate">{item.name}</span>
                    <span className="ml-auto font-semibold text-slate-800 whitespace-nowrap">{formatXAF(item.total)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>

        {/* Taux d'impayés par mois */}
        <Card className="p-5">
          <h3 className="font-semibold text-slate-800 mb-1 text-sm">Taux d'impayés par mois</h3>
          <p className="text-xs text-slate-400 mb-4">% de paiements en retard ou en attente — 12 derniers mois</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={unpaidRateByMonth} margin={{ top: 4, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} unit="%" domain={[0, 100]} />
              <Tooltip
                formatter={(v, n, p) => [`${v}% (${p.payload.unpaid}/${p.payload.total})`, "Taux impayés"]}
              />
              <Bar dataKey="rate" name="Taux impayés" radius={[4, 4, 0, 0]}>
                {unpaidRateByMonth.map((entry, i) => (
                  <Cell key={i} fill={entry.rate > 30 ? "#ef4444" : entry.rate > 15 ? "#f59e0b" : "#10b981"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Données mensuelles détaillées */}
      <Card className="p-5">
        <h3 className="font-semibold text-slate-800 mb-1 text-sm">Données mensuelles — {currentYear}</h3>
        <p className="text-xs text-slate-400 mb-4">Détail mois par mois : attendu, encaissé, impayés et taux de collecte</p>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="text-left py-2 px-3 text-slate-500 font-semibold">Mois</th>
                <th className="text-right py-2 px-3 text-slate-500 font-semibold">Attendu (XAF)</th>
                <th className="text-right py-2 px-3 text-slate-500 font-semibold">Encaissé (XAF)</th>
                <th className="text-right py-2 px-3 text-slate-500 font-semibold">Impayés (XAF)</th>
                <th className="text-right py-2 px-3 text-slate-500 font-semibold">Taux collecte</th>
                <th className="text-center py-2 px-3 text-slate-500 font-semibold">Statut</th>
              </tr>
            </thead>
            <tbody>
              {MONTHS_FR.map((label, idx) => {
                const m = idx + 1;
                const monthPayments = payments.filter(p => p.period_month === m && p.period_year === currentYear);
                const collected = monthPayments.filter(p => p.status === "paid" || p.status === "partial").reduce((s, p) => s + (p.amount || 0), 0);
                const expected = monthPayments.reduce((s, p) => s + (p.expected_amount || p.amount || 0), 0);
                const unpaidAmt = monthPayments.filter(p => p.status === "late" || p.status === "pending").reduce((s, p) => s + (p.expected_amount || p.amount || 0), 0);
                const rate = expected > 0 ? Math.round((collected / expected) * 100) : null;
                const isFuture = m > currentMonth;
                return (
                  <tr key={m} className={`border-b border-slate-50 hover:bg-slate-50 transition-colors ${isFuture ? "opacity-40" : ""}`}>
                    <td className="py-2.5 px-3 font-medium text-slate-700">{label}</td>
                    <td className="py-2.5 px-3 text-right text-slate-600">{expected > 0 ? formatXAF(expected) : "—"}</td>
                    <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">{collected > 0 ? formatXAF(collected) : "—"}</td>
                    <td className="py-2.5 px-3 text-right text-red-600">{unpaidAmt > 0 ? formatXAF(unpaidAmt) : "—"}</td>
                    <td className="py-2.5 px-3 text-right">
                      {rate !== null ? (
                        <span className={`font-bold ${rate >= 90 ? "text-emerald-600" : rate >= 60 ? "text-amber-600" : "text-red-600"}`}>{rate}%</span>
                      ) : "—"}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {isFuture ? (
                        <span className="text-slate-300 text-[10px]">à venir</span>
                      ) : rate === null ? (
                        <span className="text-slate-300 text-[10px]">aucun paiement</span>
                      ) : rate >= 90 ? (
                        <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full text-[10px] font-medium">Bon</span>
                      ) : rate >= 60 ? (
                        <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-[10px] font-medium">Partiel</span>
                      ) : (
                        <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full text-[10px] font-medium">Critique</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-slate-200 bg-slate-50">
                <td className="py-2.5 px-3 font-bold text-slate-800">Total {currentYear}</td>
                <td className="py-2.5 px-3 text-right font-bold text-slate-700">
                  {formatXAF(payments.filter(p => p.period_year === currentYear).reduce((s, p) => s + (p.expected_amount || p.amount || 0), 0))}
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-emerald-700">{formatXAF(totalCollectedYear)}</td>
                <td className="py-2.5 px-3 text-right font-bold text-red-600">
                  {formatXAF(payments.filter(p => p.period_year === currentYear && (p.status === "late" || p.status === "pending")).reduce((s, p) => s + (p.expected_amount || p.amount || 0), 0))}
                </td>
                <td className="py-2.5 px-3 text-right font-bold">
                  <span className={`${collectionRate >= 80 ? "text-emerald-600" : "text-red-600"}`}>{collectionRate}%</span>
                </td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {/* Projection annuelle */}
      <Card className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="font-semibold text-slate-800 text-sm">Projection vs Encaissements réels — {currentYear}</h3>
            <p className="text-xs text-slate-400">Basé sur {annualProjection.activeLeases} bail(s) actif(s) • Mensuel projeté : {formatXAF(annualProjection.monthlyRevenue)} XAF</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-500">Projection annuelle totale</p>
            <p className="font-bold text-emerald-700 text-lg">{formatXAF(annualProjection.annualProjected)} XAF</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={annualProjection.realByMonth} margin={{ top: 4, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
            <Tooltip formatter={(v) => `${formatXAF(v)} XAF`} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line type="monotone" dataKey="projeté" stroke="#94a3b8" strokeDasharray="6 3" strokeWidth={2} dot={false} name="Projection" />
            <Line type="monotone" dataKey="collecté" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} name="Encaissé" />
          </LineChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}