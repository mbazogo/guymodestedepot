import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, PieChart, TrendingUp, AlertCircle, Printer } from "lucide-react";
import { PieChart as RechartsPie, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const MONTHS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(Math.round(v || 0));}

const DEFAULT_ACCOUNTS = [
{ name: "Compte Courant", percentage: 65, color: "#0f2b4c" },
{ name: "Épargne", percentage: 30, color: "#10b981" },
{ name: "Urgence", percentage: 4, color: "#f59e0b" },
{ name: "Maintenance / Concession", percentage: 1, color: "#ef4444" }];


const COLORS = ["#0f2b4c", "#10b981", "#f59e0b", "#ef4444", "#6366f1", "#ec4899", "#14b8a6", "#8b5cf6"];
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth();

export default function RevenueAllocation() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const qc = useQueryClient();

  const { data: accounts = [], isLoading: loadingAccounts } = useQuery({
    queryKey: ["revenueAllocation"],
    queryFn: () => base44.entities.RevenueAllocation.list("order")
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["payments"],
    queryFn: () => base44.entities.Payment.list()
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId ?
    base44.entities.RevenueAllocation.update(editingId, data) :
    base44.entities.RevenueAllocation.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["revenueAllocation"] });setDialogOpen(false);}
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RevenueAllocation.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["revenueAllocation"] })
  });

  // Seed defaults if empty
  useEffect(() => {
    if (!loadingAccounts && accounts.length === 0) {
      DEFAULT_ACCOUNTS.forEach((a, i) => base44.entities.RevenueAllocation.create({ ...a, order: i }));
      setTimeout(() => qc.invalidateQueries({ queryKey: ["revenueAllocation"] }), 800);
    }
  }, [loadingAccounts, accounts.length]);

  const openNew = () => {
    setForm({ name: "", percentage: 0, color: COLORS[accounts.length % COLORS.length], order: accounts.length });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (a) => {setForm({ ...a });setEditingId(a.id);setDialogOpen(true);};

  const totalPct = accounts.reduce((s, a) => s + (a.percentage || 0), 0);

  // Monthly revenue per month for selected year
  const monthlyRevenues = Array.from({ length: 12 }, (_, mi) => {
    const monthPayments = payments.filter((p) =>
    (p.status === "paid" || p.status === "partial") &&
    p.period_year === selectedYear &&
    p.period_month === mi + 1
    );
    return monthPayments.reduce((s, p) => s + (p.amount || 0), 0);
  });

  const yearTotal = monthlyRevenues.reduce((s, v) => s + v, 0);

  const pieData = accounts.map((acc) => ({
    name: acc.name,
    value: acc.percentage,
    amount: yearTotal * (acc.percentage / 100),
    color: acc.color || "#0f2b4c"
  }));

  const handlePrint = () => {
    const today = new Date().toLocaleDateString("fr-FR");
    const rows = MONTHS_FR.map((month, mi) => {
      const rev = monthlyRevenues[mi];
      const cols = accounts.map((acc) => `<td style="text-align:right;padding:6px 12px;color:${rev > 0 ? acc.color : "#cbd5e1"}">${rev > 0 ? formatXAF(rev * acc.percentage / 100) : "—"}</td>`).join("");
      return `<tr style="border-bottom:1px solid #f1f5f9;${mi === currentMonth && selectedYear === currentYear ? "background:#f0fdf4;" : ""}">
        <td style="padding:6px 12px;font-weight:500">${month}${mi === currentMonth && selectedYear === currentYear ? ' <span style="background:#d1fae5;color:#065f46;font-size:9px;padding:1px 6px;border-radius:99px">En cours</span>' : ""}</td>
        <td style="text-align:right;padding:6px 12px;font-weight:700">${rev > 0 ? formatXAF(rev) : "—"}</td>
        ${cols}
      </tr>`;
    }).join("");
    const totalCols = accounts.map((acc) => `<td style="text-align:right;padding:8px 12px;">${formatXAF(yearTotal * acc.percentage / 100)}</td>`).join("");
    const pieRows = accounts.map((acc) => `<tr><td style="padding:4px 8px"><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${acc.color};margin-right:6px;vertical-align:middle"></span>${acc.name}</td><td style="padding:4px 8px;text-align:right;font-weight:700">${acc.percentage}%</td><td style="padding:4px 8px;text-align:right">${formatXAF(yearTotal * acc.percentage / 100)} XAF</td></tr>`).join("");
    const html = `<html><head><title>Répartition ${selectedYear}</title>
    <style>body{font-family:Arial,sans-serif;padding:40px;color:#1e293b;font-size:11pt}
    h1{color:#0f2b4c;font-size:18px;border-bottom:2px solid #0f2b4c;padding-bottom:8px}
    table{width:100%;border-collapse:collapse;font-size:10pt}
    thead th{background:#0f2b4c;color:#fff;padding:8px 12px;text-align:right}
    thead th:first-child{text-align:left}
    tfoot td{background:#0f2b4c;color:#fff;font-weight:700;padding:8px 12px;text-align:right}
    tfoot td:first-child{text-align:left}
    @media print{body{padding:20px}}</style></head><body>
    <h1>Répartition des revenus — ${selectedYear}</h1>
    <p style="color:#64748b;font-size:10pt;margin-bottom:20px">Généré le ${today}</p>
    <h3 style="color:#475569;font-size:12px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Comptes de répartition</h3>
    <table style="margin-bottom:24px;width:auto"><thead><tr><th style="text-align:left;padding:6px 12px">Compte</th><th style="padding:6px 12px">%</th><th style="padding:6px 12px">Total annuel</th></tr></thead><tbody>${pieRows}</tbody></table>
    <h3 style="color:#475569;font-size:12px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Tableau mensuel</h3>
    <table><thead><tr><th style="text-align:left">Mois</th><th>Revenus</th>${accounts.map((a) => `<th style="color:#fff">${a.name} (${a.percentage}%)</th>`).join("")}</tr></thead>
    <tbody>${rows}</tbody>
    <tfoot><tr><td>TOTAL ${selectedYear}</td><td style="text-align:right">${formatXAF(yearTotal)}</td>${totalCols}</tr></tfoot></table>
    </body></html>`;
    const w = window.open("", "_blank");
    w.document.write(html);
    w.document.close();
    w.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Répartition des revenus</h1>
          <p className="text-sm text-slate-500">Allocation automatique par compte selon vos pourcentages</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="border border-slate-200 rounded-lg px-3 py-2 text-sm bg-white">
            {[currentYear - 1, currentYear, currentYear + 1].map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <Button variant="outline" onClick={handlePrint} className="gap-2">
            <Printer className="w-4 h-4" /> Imprimer
          </Button>
          <Button onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
            <Plus className="w-4 h-4 mr-2" /> Nouveau compte
          </Button>
        </div>
      </div>

      {/* Total pct warning */}
      {Math.abs(totalPct - 100) > 0.1 &&
      <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm text-amber-700">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>La somme des pourcentages est de <strong>{totalPct}%</strong> — elle devrait être égale à 100%.</span>
        </div>
      }

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {accounts.map((acc) =>
        <Card key={acc.id} className="bg-lime-50 text-card-foreground p-4 rounded-xl border shadow relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full rounded-l-xl" style={{ background: acc.color || "#0f2b4c" }} />
            <div className="pl-2">
              <p className="text-slate-500 text-sm font-medium">{acc.name}</p>
              <p className="mt-1 text-base font-bold" style={{ color: acc.color || "#0f2b4c" }}>{acc.percentage}%</p>
              <p className="text-xs text-slate-400 mt-0.5">{formatXAF(yearTotal * (acc.percentage / 100))} XAF / an</p>
            </div>
            <div className="absolute top-2 right-2 flex gap-0.5">
              <button onClick={() => openEdit(acc)} className="p-1 hover:bg-slate-100 rounded"><Pencil className="w-3 h-3 text-slate-400" /></button>
              <button onClick={() => {if (confirm("Supprimer ce compte ?")) deleteMutation.mutate(acc.id);}} className="p-1 hover:bg-red-50 rounded"><Trash2 className="w-3 h-3 text-red-400" /></button>
            </div>
          </Card>
        )}
      </div>

      {/* Pie chart + year summary */}
      {yearTotal > 0 &&
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <Card className="bg-card text-card-foreground px-8 py-5 rounded-xl border shadow">
            <h2 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-slate-400" /> Répartition graphique — {selectedYear}
            </h2>
            <ResponsiveContainer width="100%" height={220}>
              <RechartsPie>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={85} label={({ name, value }) => `${value}%`} labelLine={false}>
                  {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip formatter={(value, name, props) => [`${value}% — ${formatXAF(props.payload.amount)} XAF`, name]} />
                <Legend />
              </RechartsPie>
            </ResponsiveContainer>
          </Card>

          <Card className="p-5">
            <h2 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-400" /> Bilan annuel — {selectedYear}
            </h2>
            <div className="space-y-3">
              <div className="flex justify-between text-sm font-semibold text-slate-700 border-b pb-2 mb-2">
                <span>Total encaissé</span>
                <span className="text-emerald-600">{formatXAF(yearTotal)} XAF</span>
              </div>
              {accounts.map((acc) => {
              const amt = yearTotal * acc.percentage / 100;
              const pct = acc.percentage;
              return (
                <div key={acc.id}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium text-slate-700">{acc.name}</span>
                      <span className="font-bold" style={{ color: acc.color }}>{formatXAF(amt)} XAF</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: acc.color }} />
                    </div>
                  </div>);

            })}
            </div>
          </Card>
        </div>
      }

      {/* Monthly table */}
      <Card className="overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-slate-500" />
          <h2 className="font-semibold text-slate-800">Tableau mensuel {selectedYear}</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="text-left px-4 py-3 text-slate-500 font-semibold">Mois</th>
                <th className="text-right px-4 py-3 text-slate-500 font-semibold">Revenus</th>
                {accounts.map((acc) =>
                <th key={acc.id} className="text-right px-4 py-3 font-semibold whitespace-nowrap" style={{ color: acc.color || "#0f2b4c" }}>
                    {acc.name} ({acc.percentage}%)
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {MONTHS_FR.map((month, mi) => {
                const rev = monthlyRevenues[mi];
                const isCurrent = mi === currentMonth && selectedYear === currentYear;
                return (
                  <tr key={mi} className={`border-b border-slate-50 transition-colors ${isCurrent ? "bg-emerald-50" : "hover:bg-slate-50"}`}>
                    <td className="px-4 py-3 font-medium text-slate-700">
                      {month}
                      {isCurrent && <span className="ml-2 text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full">En cours</span>}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-slate-800">
                      {rev > 0 ? formatXAF(rev) : <span className="text-slate-300">—</span>}
                    </td>
                    {accounts.map((acc) =>
                    <td key={acc.id} className="px-4 py-3 text-right font-medium" style={{ color: rev > 0 ? acc.color || "#0f2b4c" : "#cbd5e1" }}>
                        {rev > 0 ? formatXAF(rev * (acc.percentage / 100)) : "—"}
                      </td>
                    )}
                  </tr>);

              })}
            </tbody>
            <tfoot>
              <tr className="bg-slate-800 text-white">
                <td className="px-4 py-3 font-bold">TOTAL {selectedYear}</td>
                <td className="px-4 py-3 text-right font-bold">{formatXAF(yearTotal)}</td>
                {accounts.map((acc) =>
                <td key={acc.id} className="px-4 py-3 text-right font-bold">
                    {formatXAF(yearTotal * (acc.percentage / 100))}
                  </td>
                )}
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le compte" : "Nouveau compte"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nom du compte *</Label>
              <Input value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex: Compte courant" />
            </div>
            <div>
              <Label>Pourcentage (%) *</Label>
              <Input type="number" min="0" max="100" step="0.1" value={form.percentage ?? ""} onChange={(e) => setForm({ ...form, percentage: Number(e.target.value) })} />
              <p className="text-xs text-slate-400 mt-1">Total actuel : {totalPct}% {editingId ? `→ ${(totalPct - (accounts.find((a) => a.id === editingId)?.percentage || 0) + Number(form.percentage || 0)).toFixed(1)}%` : `→ ${(totalPct + Number(form.percentage || 0)).toFixed(1)}%`}</p>
            </div>
            <div>
              <Label>Couleur</Label>
              <div className="flex gap-2 flex-wrap mt-1">
                {COLORS.map((c) =>
                <button key={c} onClick={() => setForm({ ...form, color: c })}
                className={`w-7 h-7 rounded-full border-2 transition-transform ${form.color === c ? "border-slate-800 scale-125" : "border-transparent"}`}
                style={{ background: c }} />
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending || !form.name} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}