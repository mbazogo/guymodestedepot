import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Upload, Search, Filter, FolderOpen, FileText, Loader2, Trash2, RefreshCw } from "lucide-react";
import DocumentCard from "../components/documents/DocumentCard";
import DocumentUploadModal from "../components/documents/DocumentUploadModal";
import DocumentPreviewModal from "../components/documents/DocumentPreviewModal";
import { Skeleton } from "@/components/ui/skeleton";

const TYPE_OPTIONS = [
  { value: "all", label: "Tous les types" },
  { value: "bail", label: "Bail / Contrat" },
  { value: "quittance", label: "Quittance" },
  { value: "avis_echeance", label: "Avis d'échéance" },
  { value: "courrier", label: "Courrier" },
  { value: "attestation", label: "Attestation" },
  { value: "relance", label: "Relance" },
  { value: "autre", label: "Autre" },
];

const CATEGORY_OPTIONS = [
  { value: "all", label: "Toutes catégories" },
  { value: "administratif", label: "Administratif" },
  { value: "financier", label: "Financier" },
  { value: "juridique", label: "Juridique" },
  { value: "communication", label: "Communication" },
  { value: "autre", label: "Autre" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tous statuts" },
  { value: "draft", label: "Brouillon" },
  { value: "sent", label: "Envoyé" },
  { value: "signed", label: "Signé" },
];

export default function Documents() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterTenant, setFilterTenant] = useState("all");
  const [filterProperty, setFilterProperty] = useState("all");
  const [showUpload, setShowUpload] = useState(false);
  const [previewDoc, setPreviewDoc] = useState(null);

  const { data: documents = [], isLoading: loadingDocs } = useQuery({
    queryKey: ["documents"],
    queryFn: () => base44.entities.Document.list("-created_date"),
  });

  const { data: tenants = [] } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list(),
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Document.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["documents"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Document.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["documents"] }),
  });

  const handleDelete = (doc) => {
    if (window.confirm(`Supprimer définitivement « ${doc.name} » ?`)) {
      deleteMutation.mutate(doc.id);
    }
  };

  const filtered = useMemo(() => {
    return documents.filter(doc => {
      if (search && !doc.name?.toLowerCase().includes(search.toLowerCase()) && !doc.tenant_name?.toLowerCase().includes(search.toLowerCase()) && !doc.property_name?.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterType && filterType !== "all" && doc.type !== filterType) return false;
      if (filterCategory && filterCategory !== "all" && doc.category !== filterCategory) return false;
      if (filterStatus && filterStatus !== "all" && doc.status !== filterStatus) return false;
      if (filterTenant && filterTenant !== "all" && doc.tenant_id !== filterTenant) return false;
      if (filterProperty && filterProperty !== "all" && doc.property_id !== filterProperty) return false;
      return true;
    });
  }, [documents, search, filterType, filterCategory, filterStatus, filterTenant, filterProperty]);

  const stats = useMemo(() => ({
    total: documents.length,
    signed: documents.filter(d => d.status === "signed").length,
    draft: documents.filter(d => d.status === "draft").length,
    sent: documents.filter(d => d.status === "sent").length,
  }), [documents]);

  const resetFilters = () => {
    setSearch(""); setFilterType("all"); setFilterCategory("all");
    setFilterStatus("all"); setFilterTenant("all"); setFilterProperty("all");
  };

  const hasFilters = search || (filterType && filterType !== "all") || (filterCategory && filterCategory !== "all") || (filterStatus && filterStatus !== "all") || (filterTenant && filterTenant !== "all") || (filterProperty && filterProperty !== "all");

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <FolderOpen className="w-6 h-6 text-indigo-500" /> GED — Gestion des documents
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">Stockez, classez et retrouvez tous vos fichiers</p>
        </div>
        <Button onClick={() => setShowUpload(true)} className="bg-indigo-600 hover:bg-indigo-700 gap-2">
          <Upload className="w-4 h-4" /> Ajouter un document
        </Button>
      </div>

      {/* Stats strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total", value: stats.total, color: "text-slate-700", bg: "bg-slate-50" },
          { label: "Signés", value: stats.signed, color: "text-emerald-700", bg: "bg-emerald-50" },
          { label: "Envoyés", value: stats.sent, color: "text-blue-700", bg: "bg-blue-50" },
          { label: "Brouillons", value: stats.draft, color: "text-slate-600", bg: "bg-slate-50" },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-xl border border-slate-100 px-4 py-3 text-center`}>
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un document, locataire, bien..." className="pl-9 text-sm" />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Type" /></SelectTrigger>
            <SelectContent>{TYPE_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Catégorie" /></SelectTrigger>
            <SelectContent>{CATEGORY_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Statut" /></SelectTrigger>
            <SelectContent>{STATUS_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterTenant} onValueChange={setFilterTenant}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Locataire" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les locataires</SelectItem>
              {tenants.map(t => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterProperty} onValueChange={setFilterProperty}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Bien immobilier" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les biens</SelectItem>
              {properties.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
            </SelectContent>
          </Select>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={resetFilters} className="gap-1 text-slate-500">
              <RefreshCw className="w-3.5 h-3.5" /> Réinitialiser
            </Button>
          )}
          <span className="text-xs text-slate-400 ml-auto">{filtered.length} document(s)</span>
        </div>
      </div>

      {/* Document grid */}
      {loadingDocs ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-52 rounded-xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <FileText className="w-16 h-16 opacity-20 mb-3" />
          <p className="text-sm font-medium">{hasFilters ? "Aucun document ne correspond aux filtres" : "Aucun document pour l'instant"}</p>
          {!hasFilters && (
            <Button onClick={() => setShowUpload(true)} className="mt-4 bg-indigo-600 hover:bg-indigo-700 gap-2">
              <Upload className="w-4 h-4" /> Ajouter le premier document
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(doc => (
            <DocumentCard key={doc.id} doc={doc} onPreview={setPreviewDoc} onDelete={handleDelete} />
          ))}
        </div>
      )}

      <DocumentUploadModal
        open={showUpload}
        onClose={() => setShowUpload(false)}
        onSave={createMutation.mutateAsync}
        tenants={tenants}
        properties={properties}
      />

      <DocumentPreviewModal
        open={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        document={previewDoc}
      />
    </div>
  );
}