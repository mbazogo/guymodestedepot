import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Bell, Plus, Pencil, Trash2, Send, CheckCircle2, AlertTriangle, Clock,
  CalendarClock, FileText, ShieldAlert, Wallet, RefreshCw, X
} from "lucide-react";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }
function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
  return diff;
}

const TYPE_CONFIG = {
  fin_bail: { label: "Fin de bail", icon: FileText, color: "text-red-600", bg: "bg-red-50", badge: "bg-red-100 text-red-700" },
  echeance_loyer: { label: "Échéance de loyer", icon: Wallet, color: "text-amber-600", bg: "bg-amber-50", badge: "bg-amber-100 text-amber-700" },
  renouvellement_assurance: { label: "Renouvellement assurance", icon: ShieldAlert, color: "text-blue-600", bg: "bg-blue-50", badge: "bg-blue-100 text-blue-700" },
  renouvellement_cni: { label: "Renouvellement CNI", icon: FileText, color: "text-violet-600", bg: "bg-violet-50", badge: "bg-violet-100 text-violet-700" },
  autre: { label: "Autre", icon: Bell, color: "text-slate-600", bg: "bg-slate-50", badge: "bg-slate-100 text-slate-700" },
};

const STATUS_CONFIG = {
  active: { label: "Actif", className: "bg-emerald-100 text-emerald-700" },
  sent: { label: "Envoyé", className: "bg-blue-100 text-blue-700" },
  dismissed: { label: "Ignoré", className: "bg-slate-100 text-slate-500" },
};

const DEFAULT_FORM = {
  type: "fin_bail", tenant_id: "", event_date: "", days_before: 30,
  recipient_email: "", notify_tenant: true, notify_owner: true,
  status: "active", notes: ""
};

export default function Reminders() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(DEFAULT_FORM);
  const [filter, setFilter] = useState("all");
  const [sendingId, setSendingId] = useState(null);
  const qc = useQueryClient();

  const { data: reminders = [], isLoading } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list("-event_date"),
  });
  const { data: tenants = [] } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list(),
  });
  const { data: leases = [] } = useQuery({
    queryKey: ["leases"],
    queryFn: () => base44.entities.Lease.list(),
  });
  const { data: settingsList = [] } = useQuery({
    queryKey: ["settings"],
    queryFn: () => base44.entities.AppSettings.list(),
  });
  const settings = settingsList[0];

  const saveMutation = useMutation({
    mutationFn: (data) => editingId
      ? base44.entities.Reminder.update(editingId, data)
      : base44.entities.Reminder.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["reminders"] }); setDialogOpen(false); }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Reminder.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reminders"] })
  });

  const dismissMutation = useMutation({
    mutationFn: (id) => base44.entities.Reminder.update(id, { status: "dismissed" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reminders"] })
  });

  // Auto-generate reminders from leases
  const autoGenerateFromLeases = async () => {
    const existing = reminders.map(r => r.tenant_id + r.type);
    let created = 0;
    for (const lease of leases.filter(l => l.status === "active" && l.end_date)) {
      const key = lease.tenant_id + "fin_bail";
      if (!existing.includes(key)) {
        const tenant = tenants.find(t => t.id === lease.tenant_id);
        await base44.entities.Reminder.create({
          type: "fin_bail",
          tenant_id: lease.tenant_id,
          tenant_name: lease.tenant_name,
          property_id: lease.property_id,
          property_name: lease.property_name,
          event_date: lease.end_date,
          days_before: 60,
          recipient_email: tenant?.email || "",
          notify_tenant: true,
          notify_owner: true,
          status: "active",
        });
        created++;
      }
    }
    qc.invalidateQueries({ queryKey: ["reminders"] });
    alert(`${created} rappel(s) de fin de bail générés.`);
  };

  const handleSend = async (reminder) => {
    setSendingId(reminder.id);
    const tenant = tenants.find(t => t.id === reminder.tenant_id);
    const typeLabel = TYPE_CONFIG[reminder.type]?.label || reminder.type;
    const d = daysUntil(reminder.event_date);
    const subject = `Rappel : ${typeLabel} — ${reminder.tenant_name}`;
    const body = `Bonjour,\n\nCeci est un rappel automatique concernant : ${typeLabel}\n\nLocataire : ${reminder.tenant_name}\nBien : ${reminder.property_name || "—"}\nDate de l'événement : ${new Date(reminder.event_date).toLocaleDateString("fr-FR")}\n${d !== null ? `Délai : ${d > 0 ? `Dans ${d} jour(s)` : d === 0 ? "Aujourd'hui !" : `Dépassé de ${Math.abs(d)} jour(s)`}` : ""}\n\n${reminder.notes ? `Note : ${reminder.notes}\n\n` : ""}Cordialement,\n${settings?.owner_name || settings?.company_name || "Votre gestionnaire"}`;

    const emails = [];
    if (reminder.notify_tenant && tenant?.email) emails.push(tenant.email);
    if (reminder.notify_owner && settings?.owner_email) emails.push(settings.owner_email);
    if (reminder.recipient_email && !emails.includes(reminder.recipient_email)) emails.push(reminder.recipient_email);

    for (const email of emails) {
      await base44.integrations.Core.SendEmail({ to: email, subject, body });
    }
    await base44.entities.Reminder.update(reminder.id, { status: "sent", last_sent: new Date().toISOString().split("T")[0] });
    qc.invalidateQueries({ queryKey: ["reminders"] });
    setSendingId(null);
    alert(`Rappel envoyé à : ${emails.join(", ") || "aucun destinataire configuré"}`);
  };

  const openNew = () => {
    setForm({ ...DEFAULT_FORM, recipient_email: settings?.owner_email || "" });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (r) => {
    setForm({ ...r });
    setEditingId(r.id);
    setDialogOpen(true);
  };

  const handleSave = () => {
    const tenant = tenants.find(t => t.id === form.tenant_id);
    saveMutation.mutate({
      ...form,
      tenant_name: tenant ? `${tenant.first_name} ${tenant.last_name}` : form.tenant_name,
      property_id: tenant?.property_id || "",
      property_name: tenant?.property_name || "",
      days_before: Number(form.days_before) || 30,
    });
  };

  // Stats
  const today = new Date();
  const urgent = reminders.filter(r => r.status === "active" && daysUntil(r.event_date) !== null && daysUntil(r.event_date) <= 7);
  const upcoming = reminders.filter(r => r.status === "active" && daysUntil(r.event_date) !== null && daysUntil(r.event_date) > 7 && daysUntil(r.event_date) <= 30);
  const overdue = reminders.filter(r => r.status === "active" && daysUntil(r.event_date) !== null && daysUntil(r.event_date) < 0);

  const filtered = reminders.filter(r => {
    if (filter === "urgent") return daysUntil(r.event_date) !== null && daysUntil(r.event_date) <= 7 && r.status === "active";
    if (filter === "upcoming") return daysUntil(r.event_date) !== null && daysUntil(r.event_date) > 7 && r.status === "active";
    if (filter === "sent") return r.status === "sent";
    if (filter === "dismissed") return r.status === "dismissed";
    return true;
  });

  const getDaysLabel = (days) => {
    if (days === null) return "—";
    if (days < 0) return `Dépassé de ${Math.abs(days)}j`;
    if (days === 0) return "Aujourd'hui !";
    if (days === 1) return "Demain";
    return `Dans ${days} jours`;
  };

  const getDaysColor = (days, status) => {
    if (status !== "active") return "text-slate-400";
    if (days === null) return "text-slate-400";
    if (days < 0) return "text-red-600 font-bold";
    if (days <= 7) return "text-red-500 font-semibold";
    if (days <= 30) return "text-amber-600 font-medium";
    return "text-emerald-600";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-amber-600 text-xl font-bold">Rappels & Alertes</h1>
          <p className="text-sm text-slate-500">Gestion des rappels automatiques pour les événements clés</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={autoGenerateFromLeases} className="gap-2 text-sm">
            <RefreshCw className="w-4 h-4" /> Générer depuis les baux
          </Button>
          <Button onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
            <Plus className="w-4 h-4 mr-2" /> Nouveau rappel
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 bg-red-50 border-red-100">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <div>
              <p className="text-2xl font-bold text-red-700">{urgent.length + overdue.length}</p>
              <p className="text-xs text-red-600">Urgents / Dépassés</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-amber-50 border-amber-100">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-2xl font-bold text-amber-700">{upcoming.length}</p>
              <p className="text-xs text-amber-600">À venir (30j)</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-emerald-50 border-emerald-100">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <div>
              <p className="text-2xl font-bold text-emerald-700">{reminders.filter(r => r.status === "sent").length}</p>
              <p className="text-xs text-emerald-600">Envoyés</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 border-b border-slate-200">
        {[
          { key: "all", label: `Tous (${reminders.length})` },
          { key: "urgent", label: `Urgents (${urgent.length + overdue.length})` },
          { key: "upcoming", label: `À venir (${upcoming.length})` },
          { key: "sent", label: `Envoyés (${reminders.filter(r => r.status === "sent").length})` },
          { key: "dismissed", label: `Ignorés` },
        ].map(tab => (
          <button key={tab.key} onClick={() => setFilter(tab.key)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${filter === tab.key ? "border-amber-500 text-amber-700" : "border-transparent text-slate-500 hover:text-slate-700"}`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {isLoading && [1, 2, 3].map(i => <div key={i} className="h-20 bg-slate-100 rounded-xl animate-pulse" />)}

        {!isLoading && filtered.length === 0 && (
          <div className="text-center py-16 text-slate-400">
            <Bell className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>Aucun rappel dans cette catégorie</p>
          </div>
        )}

        {filtered.map(reminder => {
          const conf = TYPE_CONFIG[reminder.type] || TYPE_CONFIG.autre;
          const IconComp = conf.icon;
          const days = daysUntil(reminder.event_date);
          const isOverdue = days !== null && days < 0 && reminder.status === "active";
          return (
            <Card key={reminder.id} className={`p-4 ${isOverdue ? "border-red-200 bg-red-50/30" : ""}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-lg ${conf.bg} flex items-center justify-center shrink-0 mt-0.5`}>
                    <IconComp className={`w-4 h-4 ${conf.color}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-slate-800">{reminder.tenant_name}</span>
                      <Badge className={`${conf.badge} text-[10px]`}>{conf.label}</Badge>
                      <Badge className={`${STATUS_CONFIG[reminder.status]?.className} text-[10px]`}>{STATUS_CONFIG[reminder.status]?.label}</Badge>
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      <span className="text-xs text-slate-500">{reminder.property_name || "—"}</span>
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <CalendarClock className="w-3 h-3" />
                        {reminder.event_date ? new Date(reminder.event_date).toLocaleDateString("fr-FR") : "—"}
                      </span>
                      <span className={`text-xs ${getDaysColor(days, reminder.status)}`}>{getDaysLabel(days)}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      Rappel : {reminder.days_before}j avant
                      {reminder.notify_tenant && " • Locataire notifié"}
                      {reminder.notify_owner && " • Propriétaire notifié"}
                      {reminder.recipient_email && ` • ${reminder.recipient_email}`}
                      {reminder.last_sent && ` • Dernier envoi : ${new Date(reminder.last_sent).toLocaleDateString("fr-FR")}`}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-wrap justify-end">
                  {reminder.status !== "dismissed" && (
                    <Button size="sm" variant="outline" className="text-blue-600 border-blue-200 h-8 px-3 text-xs gap-1"
                      disabled={sendingId === reminder.id}
                      onClick={() => handleSend(reminder)}>
                      <Send className="w-3 h-3" />
                      {sendingId === reminder.id ? "Envoi..." : "Envoyer"}
                    </Button>
                  )}
                  {reminder.status === "active" && (
                    <Button size="icon" variant="ghost" className="h-8 w-8" title="Ignorer" onClick={() => dismissMutation.mutate(reminder.id)}>
                      <X className="w-4 h-4 text-slate-400" />
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(reminder)}>
                    <Pencil className="w-4 h-4 text-slate-500" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { if (confirm("Supprimer ce rappel ?")) deleteMutation.mutate(reminder.id); }}>
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier le rappel" : "Nouveau rappel"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Type d'événement *</Label>
              <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(TYPE_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Locataire *</Label>
              <Select value={form.tenant_id} onValueChange={v => {
                const t = tenants.find(t => t.id === v);
                setForm({ ...form, tenant_id: v, recipient_email: form.recipient_email || t?.email || "" });
              }}>
                <SelectTrigger><SelectValue placeholder="Sélectionner un locataire" /></SelectTrigger>
                <SelectContent>
                  {tenants.map(t => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name} — {t.property_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Date de l'événement *</Label>
                <Input type="date" value={form.event_date} onChange={e => setForm({ ...form, event_date: e.target.value })} />
              </div>
              <div>
                <Label>Rappeler X jours avant</Label>
                <Input type="number" min={1} max={365} value={form.days_before} onChange={e => setForm({ ...form, days_before: Number(e.target.value) })} />
              </div>
            </div>

            <div>
              <Label>Email destinataire supplémentaire</Label>
              <Input type="email" value={form.recipient_email} onChange={e => setForm({ ...form, recipient_email: e.target.value })} placeholder="email@exemple.com" />
            </div>

            <div className="space-y-3">
              <Label>Destinataires</Label>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium">Notifier le locataire</p>
                  <p className="text-xs text-slate-400">Email du locataire</p>
                </div>
                <Switch checked={form.notify_tenant} onCheckedChange={v => setForm({ ...form, notify_tenant: v })} />
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium">Notifier le propriétaire</p>
                  <p className="text-xs text-slate-400">{settings?.owner_email || "Email non configuré (Paramètres)"}</p>
                </div>
                <Switch checked={form.notify_owner} onCheckedChange={v => setForm({ ...form, notify_owner: v })} />
              </div>
            </div>

            <div>
              <Label>Notes (optionnel)</Label>
              <Textarea value={form.notes || ""} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="Informations supplémentaires..." />
            </div>

            <div>
              <Label>Statut</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Actif</SelectItem>
                  <SelectItem value="sent">Envoyé</SelectItem>
                  <SelectItem value="dismissed">Ignoré</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending || !form.tenant_id || !form.event_date} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}