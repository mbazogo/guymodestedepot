import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Search, Users, Eye, Phone, Mail, Printer, FileText, Archive } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import ArchiveButton from "../components/archive/ArchiveButton";

function formatXAF(v) {
  return new Intl.NumberFormat("fr-FR").format(v || 0);
}

const statusColors = { active: "bg-emerald-100 text-emerald-700", inactive: "bg-slate-100 text-slate-600", pending: "bg-amber-100 text-amber-700" };
const statusLabels = { active: "Actif", inactive: "Inactif", pending: "En attente" };

export default function Tenants() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const qc = useQueryClient();

  const { data: tenants = [], isLoading } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list()
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list()
  });

  const saveMutation = useMutation({
    mutationFn: (data) =>
    editingId ? base44.entities.Tenant.update(editingId, data) : base44.entities.Tenant.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tenants"] });
      setDialogOpen(false);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Tenant.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tenants"] })
  });

  const [showArchived, setShowArchived] = useState(false);

  const archiveMutation = useMutation({
    mutationFn: ({ id, archived }) => base44.entities.Tenant.update(id, { archived }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tenants"] })
  });

  const openNew = () => {
    setForm({ civility: "M.", first_name: "", last_name: "", email: "", phone: "", id_number: "", property_id: "", rent_amount: "", deposit_amount: "", status: "active", notes: "" });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (t) => {
    setForm({ ...t });
    setEditingId(t.id);
    setDialogOpen(true);
  };

  const handleSave = () => {
    const prop = properties.find((p) => p.id === form.property_id);
    saveMutation.mutate({
      ...form,
      property_name: prop?.name || "",
      rent_amount: Number(form.rent_amount) || 0,
      deposit_amount: Number(form.deposit_amount) || 0
    });
  };

  const { data: documents = [] } = useQuery({
    queryKey: ["documents"],
    queryFn: () => base44.entities.Document.list()
  });

  const visibleTenants = tenants.filter((t) => showArchived ? t.archived : !t.archived);
  const filtered = visibleTenants.filter(
    (t) =>
    `${t.first_name} ${t.last_name}`.toLowerCase().includes(search.toLowerCase()) ||
    t.email?.toLowerCase().includes(search.toLowerCase()) ||
    t.property_name?.toLowerCase().includes(search.toLowerCase())
  );

  const printListing = () => {
    const rows = filtered.map((t) =>
      `<tr><td>${t.civility || ""} ${t.first_name} ${t.last_name}</td><td>${t.property_name || "—"}</td><td>${t.phone || "—"}</td><td>${t.email || "—"}</td><td>${new Intl.NumberFormat("fr-FR").format(t.rent_amount || 0)} XAF</td><td>${statusLabels[t.status] || t.status}</td></tr>`
    ).join("");
    const html = `<html><head><title>Liste des locataires</title><style>body{font-family:Arial,sans-serif;font-size:11px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:6px 8px}th{background:#f1f5f9;font-weight:600}tr:nth-child(even){background:#f8fafc}h2{margin-bottom:12px}</style></head><body><h2>Liste des locataires — ${new Date().toLocaleDateString("fr-FR")}</h2><table><thead><tr><th>Locataire</th><th>Bien</th><th>Téléphone</th><th>Email</th><th>Loyer</th><th>Statut</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
    const w = window.open("", "_blank"); w.document.write(html); w.document.close(); w.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Locataires</h1>
          <p className="text-sm text-slate-500">{tenants.length} locataire(s)</p>
        </div>
        <div className="flex gap-2">
          {!showArchived && (
            <Button variant="outline" onClick={printListing} title="Imprimer le listing">
              <Printer className="w-4 h-4 mr-2" /> Imprimer
            </Button>
          )}
          <Button variant="outline" onClick={() => setShowArchived(!showArchived)} className={showArchived ? "border-amber-300 text-amber-700 bg-amber-50" : ""}>
            <Archive className="w-4 h-4 mr-2" /> {showArchived ? "Vue archivés" : "Archives"}
          </Button>
          {!showArchived && (
            <Button onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              <Plus className="w-4 h-4 mr-2" /> Nouveau locataire
            </Button>
          )}
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      {isLoading ?
      <div className="grid gap-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
        </div> :

      <div className="space-y-3">
          {filtered.map((t) =>
        <Card key={t.id} className="p-4 hover:shadow-md transition-shadow">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#0f2b4c] flex items-center justify-center text-white font-semibold text-sm">
                    {t.first_name?.[0]}{t.last_name?.[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-900 text-sm">{t.first_name} {t.last_name}</h3>
                      <Badge className={`${statusColors[t.status]} text-[10px]`}>{statusLabels[t.status]}</Badge>
                    </div>
                    <div className="flex items-center gap-3 mt-0.5">
                      <p className="text-xs text-slate-500">{t.property_name || "—"}</p>
                      {t.phone &&
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                          <Phone className="w-3 h-3" />{t.phone}
                        </span>
                  }
                      {t.email &&
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                          <Mail className="w-3 h-3" />{t.email}
                        </span>
                  }
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap justify-end">
                  <span className="text-sm font-bold text-slate-900">{formatXAF(t.rent_amount)} XAF</span>
                  {t.status === "active" && (() => {
                    const tenantDocs = documents.filter((d) => d.tenant_id === t.id);
                    return tenantDocs.length > 0 ? (
                      <Button size="sm" variant="outline" className="text-blue-600 border-blue-200 h-8 px-2 text-xs"
                        onClick={() => {
                          const docList = tenantDocs.map((d) => `• ${d.name} (${d.type})`).join("\n");
                          alert(`Documents de ${t.first_name} ${t.last_name} :\n\n${docList}\n\nAccédez à la page Courriers pour les consulter.`);
                        }}>
                        <FileText className="w-3.5 h-3.5 mr-1" /> {tenantDocs.length} doc(s)
                      </Button>
                    ) : null;
                  })()}
                  {!t.archived && (
                    <Link to={createPageUrl("TenantDetail") + `?id=${t.id}`}>
                      <Button size="icon" variant="ghost"><Eye className="w-4 h-4 text-slate-500" /></Button>
                    </Link>
                  )}
                  {!t.archived && (
                    <Button size="icon" variant="ghost" onClick={() => openEdit(t)}>
                      <Pencil className="w-4 h-4 text-slate-500" />
                    </Button>
                  )}
                  <ArchiveButton item={t} onArchive={(id, archived) => archiveMutation.mutate({ id, archived })} />
                  {!t.archived && (
                    <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ?")) deleteMutation.mutate(t.id);}}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
        )}
          {filtered.length === 0 &&
        <div className="text-center py-16 text-slate-400">
              <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun locataire trouvé</p>
            </div>
        }
        </div>
      }

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? "Modifier le locataire" : "Nouveau locataire"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Civilité</Label>
              <Select value={form.civility || "M."} onValueChange={(v) => setForm({ ...form, civility: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="M.">M.</SelectItem>
                  <SelectItem value="Mme">Mme</SelectItem>
                  <SelectItem value="Mlle">Mlle</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Prénom *</Label><Input value={form.first_name || ""} onChange={(e) => setForm({ ...form, first_name: e.target.value })} /></div>
              <div><Label>Nom *</Label><Input value={form.last_name || ""} onChange={(e) => setForm({ ...form, last_name: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Email</Label><Input type="email" value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Téléphone</Label><Input value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            </div>
            <div>
              <Label>Bien *</Label>
              <Select value={form.property_id || ""} onValueChange={(v) => setForm({ ...form, property_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner un bien" /></SelectTrigger>
                <SelectContent>
                  {properties.map((p) =>
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Loyer (XAF)</Label><Input type="number" value={form.rent_amount || ""} onChange={(e) => setForm({ ...form, rent_amount: e.target.value })} /></div>
              <div><Label>Dépôt de garantie (XAF)</Label><Input type="number" value={form.deposit_amount || ""} onChange={(e) => setForm({ ...form, deposit_amount: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>N° pièce d'identité</Label><Input value={form.id_number || ""} onChange={(e) => setForm({ ...form, id_number: e.target.value })} /></div>
              <div>
                <Label>Statut</Label>
                <Select value={form.status || "active"} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Actif</SelectItem>
                    <SelectItem value="inactive">Inactif</SelectItem>
                    <SelectItem value="pending">En attente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Notes</Label><Input value={form.notes || ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}