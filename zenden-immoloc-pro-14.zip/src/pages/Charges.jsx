import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Search, CreditCard, Printer, FileSpreadsheet } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

const categoryLabels = {
  maintenance: "Maintenance", plomberie: "Plomberie", peinture: "Peinture", electricite: "Électricité",
  menuiserie: "Menuiserie", serrurerie: "Serrurerie", gardiennage: "Gardiennage", nettoyage: "Nettoyage",
  poubelles: "Poubelles", assurance: "Assurance", taxe_fonciere: "Taxe foncière", eau: "Eau",
  electricite_commune: "Élec. commune", autre: "Autre"
};

const globalCategories = ["gardiennage", "nettoyage", "poubelles"];

export default function Charges() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [view, setView] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterProperty, setFilterProperty] = useState("all");
  const qc = useQueryClient();

  const [commonDialogOpen, setCommonDialogOpen] = useState(false);
  const [commonForm, setCommonForm] = useState({ category: "gardiennage", description: "", amount: "", date: new Date().toISOString().slice(0, 10), supplier: "", is_deductible: true });
  const [commonSaving, setCommonSaving] = useState(false);

  const { data: charges = [], isLoading } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId ? base44.entities.Charge.update(editingId, data) : base44.entities.Charge.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["charges"] });setDialogOpen(false);}
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Charge.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["charges"] })
  });

  const openNew = () => {
    setForm({ property_id: "", category: "maintenance", description: "", amount: "", date: new Date().toISOString().slice(0, 10), is_global: false, is_deductible: true, tva_amount: 0, supplier: "", status: "paid" });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (c) => {setForm({ ...c });setEditingId(c.id);setDialogOpen(true);};

  const activeTenants = tenants.filter((t) => t.status === "active");
  const sharePerTenant = activeTenants.length > 0 && commonForm.amount ? Math.round(Number(commonForm.amount) / activeTenants.length) : 0;

  const handleCommonSave = async () => {
    if (!commonForm.amount || activeTenants.length === 0) return;
    setCommonSaving(true);
    const totalAmount = Number(commonForm.amount);
    const perTenant = totalAmount / activeTenants.length;
    // Create one charge entry per tenant (linked to their property)
    await Promise.all(activeTenants.map((t) =>
    base44.entities.Charge.create({
      category: commonForm.category,
      description: `[Charge commune] ${commonForm.description || categoryLabels[commonForm.category]}`,
      amount: Math.round(perTenant),
      date: commonForm.date,
      supplier: commonForm.supplier,
      is_global: false,
      is_deductible: commonForm.is_deductible ?? true,
      tva_amount: 0,
      property_id: t.property_id || "",
      property_name: t.property_name || ""
    })
    ));
    qc.invalidateQueries({ queryKey: ["charges"] });
    setCommonSaving(false);
    setCommonDialogOpen(false);
  };

  const handleSave = () => {
    const prop = properties.find((p) => p.id === form.property_id);
    const isGlobal = globalCategories.includes(form.category) || form.is_global;
    saveMutation.mutate({
      ...form,
      property_name: isGlobal ? "Global" : prop?.name || "",
      is_global: isGlobal,
      amount: Number(form.amount) || 0,
      tva_amount: Number(form.tva_amount) || 0
    });
  };

  const filtered = charges.
  filter((c) => {
    if (view === "global") return c.is_global;
    if (view === "property") return !c.is_global;
    return true;
  }).
  filter((c) => filterCategory === "all" || c.category === filterCategory).
  filter((c) => filterProperty === "all" || c.property_id === filterProperty).
  filter((c) =>
  c.description?.toLowerCase().includes(search.toLowerCase()) ||
  c.property_name?.toLowerCase().includes(search.toLowerCase()) ||
  c.supplier?.toLowerCase().includes(search.toLowerCase()) ||
  c.category?.toLowerCase().includes(search.toLowerCase())
  ).
  sort((a, b) => new Date(b.date) - new Date(a.date));

  const totalCharges = filtered.reduce((sum, c) => sum + (c.amount || 0), 0);

  // Cumul par bien
  const chargesByProperty = {};
  charges.filter((c) => !c.is_global).forEach((c) => {
    const key = c.property_name || c.property_id || "Inconnu";
    chargesByProperty[key] = (chargesByProperty[key] || 0) + (c.amount || 0);
  });
  const chargesByPropertyArr = Object.entries(chargesByProperty).sort((a, b) => b[1] - a[1]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="bg-red-50 text-rose-600 text-xl font-bold">Charges d'exploitation</h1>
          <p className="text-sm text-slate-500">Total: {formatXAF(totalCharges)} XAF</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => {setCommonForm({ category: "gardiennage", description: "", amount: "", date: new Date().toISOString().slice(0, 10), supplier: "", is_deductible: true });setCommonDialogOpen(true);}} className="border-amber-300 text-amber-700 hover:bg-amber-50">
            <Plus className="w-4 h-4 mr-2" /> Charge commune
          </Button>
          <Button onClick={openNew} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
            <Plus className="w-4 h-4 mr-2" /> Nouvelle charge
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <div className="relative max-w-xs flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Tabs value={view} onValueChange={setView}>
          <TabsList>
            <TabsTrigger value="all">Toutes</TabsTrigger>
            <TabsTrigger value="property">Par bien</TabsTrigger>
            <TabsTrigger value="global">Globales</TabsTrigger>
          </TabsList>
        </Tabs>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Catégorie..." /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes catégories</SelectItem>
            {Object.entries(categoryLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterProperty} onValueChange={setFilterProperty}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Bien..." /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les biens</SelectItem>
            {properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {isLoading ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div> :

      <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-slate-50">
                  <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Date</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Catégorie</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Bien</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Description</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Fournisseur</th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Montant</th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((c) =>
              <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="py-3 px-4 text-slate-500">{c.date}</td>
                    <td className="py-3 px-4"><Badge variant="outline" className="text-[10px]">{categoryLabels[c.category] || c.category}</Badge></td>
                    <td className="py-3 px-4">{c.is_global ? <span className="text-slate-400">Global</span> : c.property_name}</td>
                    <td className="py-3 px-4 text-slate-500">{c.description || "—"}</td>
                    <td className="py-3 px-4 text-slate-500">{c.supplier || "—"}</td>
                    <td className="text-red-600 px-4 py-3 font-semibold text-right">{formatXAF(c.amount)} XAF</td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5 text-slate-500" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ?")) deleteMutation.mutate(c.id);}}><Trash2 className="w-3.5 h-3.5 text-red-500" /></Button>
                      </div>
                    </td>
                  </tr>
              )}
                {filtered.length === 0 &&
              <tr><td colSpan={7} className="text-center py-12 text-slate-400"><CreditCard className="w-10 h-10 mx-auto mb-2 text-slate-300" /><p>Aucune charge</p></td></tr>
              }
              </tbody>
            </table>
          </div>
        </Card>
      }

      {/* Cumul par bien */}
      {chargesByPropertyArr.length > 0 &&
      <Card className="p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Cumul des charges par bien</h3>
          <div className="space-y-2">
            {chargesByPropertyArr.map(([name, total], i) =>
          <div key={i} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="text-sm text-slate-700">{name}</span>
                </div>
                <span className="font-semibold text-red-600 text-sm">{formatXAF(total)} XAF</span>
              </div>
          )}
            <div className="flex items-center justify-between pt-3 mt-1 border-t-2 border-slate-200">
              <span className="text-sm font-semibold text-slate-800">Total charges directes</span>
              <span className="font-bold text-red-700">{formatXAF(chargesByPropertyArr.reduce((s, [, v]) => s + v, 0))} XAF</span>
            </div>
          </div>
        </Card>
      }

      {/* Common charge dialog */}
      <Dialog open={commonDialogOpen} onOpenChange={setCommonDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="text-amber-700">Charge commune — Répartition automatique</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm text-amber-800">
              Le montant saisi sera réparti <strong>équitablement</strong> entre les <strong>{activeTenants.length} locataires actifs</strong>.
            </div>
            <div>
              <Label>Catégorie *</Label>
              <Select value={commonForm.category} onValueChange={(v) => setCommonForm({ ...commonForm, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(categoryLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Description</Label><Textarea value={commonForm.description || ""} onChange={(e) => setCommonForm({ ...commonForm, description: e.target.value })} rows={2} placeholder="Ex: Frais de gardiennage mensuel" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Montant total (XAF) *</Label><Input type="number" value={commonForm.amount || ""} onChange={(e) => setCommonForm({ ...commonForm, amount: e.target.value })} placeholder="0" /></div>
              <div><Label>Date *</Label><Input type="date" value={commonForm.date || ""} onChange={(e) => setCommonForm({ ...commonForm, date: e.target.value })} /></div>
            </div>
            <div><Label>Fournisseur</Label><Input value={commonForm.supplier || ""} onChange={(e) => setCommonForm({ ...commonForm, supplier: e.target.value })} /></div>

            {/* Live preview */}
            {Number(commonForm.amount) > 0 && activeTenants.length > 0 &&
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                <p className="text-xs font-semibold text-slate-600 mb-2">Répartition prévisionnelle</p>
                <div className="space-y-1 max-h-36 overflow-y-auto">
                  {activeTenants.map((t) =>
                <div key={t.id} className="flex justify-between text-xs text-slate-700 py-0.5 border-b border-slate-100 last:border-0">
                      <span>{t.civility} {t.first_name} {t.last_name} — {t.property_name || "Bien non défini"}</span>
                      <span className="font-semibold text-red-600">{formatXAF(sharePerTenant)} XAF</span>
                    </div>
                )}
                </div>
                <div className="flex justify-between text-xs font-bold mt-2 pt-2 border-t border-slate-300">
                  <span>Total réparti</span>
                  <span className="text-red-700">{formatXAF(sharePerTenant * activeTenants.length)} XAF</span>
                </div>
              </div>
            }
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCommonDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleCommonSave} disabled={commonSaving || !commonForm.amount || activeTenants.length === 0} className="bg-amber-600 hover:bg-amber-700">
              {commonSaving ? "Enregistrement..." : `Répartir sur ${activeTenants.length} locataires`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "Modifier la charge" : "Nouvelle charge"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Catégorie *</Label>
              <Select value={form.category || "maintenance"} onValueChange={(v) => setForm({ ...form, category: v, is_global: globalCategories.includes(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(categoryLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {!form.is_global &&
            <div>
                <Label>Bien</Label>
                <Select value={form.property_id || ""} onValueChange={(v) => setForm({ ...form, property_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Sélectionner un bien" /></SelectTrigger>
                  <SelectContent>{properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            }
            <div><Label>Description</Label><Textarea value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Montant (XAF) *</Label><Input type="number" value={form.amount || ""} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
              <div><Label>Date *</Label><Input type="date" value={form.date || ""} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            </div>
            <div><Label>Fournisseur</Label><Input value={form.supplier || ""} onChange={(e) => setForm({ ...form, supplier: e.target.value })} /></div>
            <div className="flex items-center gap-3">
              <Switch checked={form.is_deductible ?? true} onCheckedChange={(v) => setForm({ ...form, is_deductible: v })} />
              <Label>Charge déductible</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}