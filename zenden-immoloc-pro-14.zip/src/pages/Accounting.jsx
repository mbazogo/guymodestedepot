import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { BookOpen, TrendingUp, TrendingDown, Scale, Building2, Printer, FileSpreadsheet } from "lucide-react";
import StatCard from "../components/dashboard/StatCard";
import { Skeleton } from "@/components/ui/skeleton";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}

export default function Accounting() {
  const currentYear = new Date().getFullYear();
  const [year, setYear] = useState(String(currentYear));
  const y = Number(year);

  const { data: payments = [], isLoading: lp } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: charges = [], isLoading: lc } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });

  const isLoading = lp || lc;

  const yearPayments = payments.filter((p) => p.period_year === y && (p.status === "paid" || p.status === "partial"));
  const yearCharges = charges.filter((c) => new Date(c.date).getFullYear() === y);

  const totalRevenue = yearPayments.reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpense = yearCharges.reduce((s, c) => s + (c.amount || 0), 0);
  const netResult = totalRevenue - totalExpense;
  const deductibleCharges = yearCharges.filter((c) => c.is_deductible).reduce((s, c) => s + (c.amount || 0), 0);
  const tvaCollected = yearPayments.reduce((s, p) => s + (p.amount || 0) * 0, 0); // TVA à configurer
  const tvaDeductible = yearCharges.reduce((s, c) => s + (c.tva_amount || 0), 0);

  // Grand Livre entries
  const entries = useMemo(() => {
    const all = [];
    yearPayments.forEach((p) => {
      all.push({ date: p.payment_date || p.created_date?.slice(0, 10), label: `Loyer ${p.tenant_name} - ${String(p.period_month).padStart(2, "0")}/${p.period_year}`, debit: 0, credit: p.amount || 0, type: "revenue", account: "706 - Revenus locatifs" });
    });
    yearCharges.forEach((c) => {
      all.push({ date: c.date, label: `${c.category?.replace(/_/g, " ")} - ${c.description || c.property_name || "Global"}`, debit: c.amount || 0, credit: 0, type: "expense", account: "6xx - Charges" });
    });
    return all.sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [yearPayments, yearCharges]);

  // Balance by property
  const propertyBalance = properties.map((p) => {
    const rev = yearPayments.filter((pay) => pay.property_id === p.id).reduce((s, pay) => s + (pay.amount || 0), 0);
    const exp = yearCharges.filter((c) => c.property_id === p.id).reduce((s, c) => s + (c.amount || 0), 0);
    return { name: p.name, revenue: rev, expense: exp, net: rev - exp };
  });

  if (isLoading) return <div className="space-y-4">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-emerald-600 text-xl font-bold">Comptabilité simplifiée</h1>
          <p className="text-sm text-slate-500">Vue d'ensemble comptable</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
            <SelectContent>
              {[currentYear, currentYear - 1, currentYear - 2].map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={() => {
            const rows = entries.map((e) => `<tr><td>${e.date}</td><td>${e.account}</td><td>${e.label}</td><td style="text-align:right;color:${e.debit > 0 ? '#dc2626' : ''};">${e.debit > 0 ? formatXAF(e.debit) + ' XAF' : '—'}</td><td style="text-align:right;color:${e.credit > 0 ? '#059669' : ''};">${e.credit > 0 ? formatXAF(e.credit) + ' XAF' : '—'}</td></tr>`).join("");
            const html = `<html><head><title>Grand Livre ${year}</title><style>body{font-family:Arial,sans-serif;font-size:11px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:5px 8px}th{background:#f1f5f9;font-weight:600}h2{margin-bottom:10px}</style></head><body><h2>Grand Livre — ${year}</h2><p>Total Revenus: <b>${formatXAF(totalRevenue)} XAF</b> | Total Charges: <b>${formatXAF(totalExpense)} XAF</b> | Net: <b>${formatXAF(netResult)} XAF</b></p><table><thead><tr><th>Date</th><th>Compte</th><th>Libellé</th><th>Débit</th><th>Crédit</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
            const w = window.open("", "_blank");w.document.write(html);w.document.close();w.print();
          }}>
            <Printer className="w-4 h-4 mr-1.5" /> Imprimer
          </Button>
          <Button variant="outline" size="sm" onClick={() => {
            const headers = ["Date", "Compte", "Libellé", "Débit (XAF)", "Crédit (XAF)"];
            const rows = entries.map((e) => [e.date, e.account, e.label, e.debit || 0, e.credit || 0]);
            const csv = [headers, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
            const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");a.href = url;a.download = `comptabilite_${year}.csv`;a.click();URL.revokeObjectURL(url);
          }}>
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-emerald-600" /> Excel
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total revenus" value={`${formatXAF(totalRevenue)} XAF`} icon={TrendingUp} color="emerald" />
        <StatCard title="Total charges" value={`${formatXAF(totalExpense)} XAF`} icon={TrendingDown} color="red" />
        <StatCard title="Résultat net" value={`${formatXAF(netResult)} XAF`} icon={Scale} color={netResult >= 0 ? "blue" : "red"} />
        <StatCard title="Charges déductibles" value={`${formatXAF(deductibleCharges)} XAF`} icon={BookOpen} color="violet" />
      </div>

      <Tabs defaultValue="grand_livre">
        <TabsList>
          <TabsTrigger value="grand_livre">Grand Livre</TabsTrigger>
          <TabsTrigger value="balance">Balance par bien</TabsTrigger>
          <TabsTrigger value="resultat">Compte de résultat</TabsTrigger>
          <TabsTrigger value="tva">TVA</TabsTrigger>
        </TabsList>

        <TabsContent value="grand_livre" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Date</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Compte</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Libellé</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Débit</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Crédit</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((e, i) =>
                  <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                      <td className="text-slate-500 px-3">{e.date}</td>
                      <td className="py-2.5 px-4"><Badge variant="outline" className="text-[10px] font-semibold rounded-md inline-flex items-center border transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2">{e.account}</Badge></td>
                      <td className="py-2.5 px-4">{e.label}</td>
                      <td className="mx-3 px-4 py-2.5 font-medium text-right">{e.debit > 0 ? <span className="text-red-600">{formatXAF(e.debit)}</span> : "—"}</td>
                      <td className="py-2.5 px-4 text-right font-medium">{e.credit > 0 ? <span className="text-emerald-600">{formatXAF(e.credit)}</span> : "—"}</td>
                    </tr>
                  )}
                  {entries.length === 0 && <tr><td colSpan={5} className="text-center py-8 text-slate-400">Aucune écriture</td></tr>}
                  <tr className="bg-slate-50 font-semibold">
                    <td colSpan={3} className="py-3 px-4">TOTAL</td>
                    <td className="py-3 px-4 text-right text-red-600">{formatXAF(entries.reduce((s, e) => s + e.debit, 0))}</td>
                    <td className="py-3 px-4 text-right text-emerald-600">{formatXAF(entries.reduce((s, e) => s + e.credit, 0))}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="balance" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left py-3 px-4 text-xs font-medium text-slate-500">Bien</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Revenus</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Dépenses</th>
                    <th className="text-right py-3 px-4 text-xs font-medium text-slate-500">Résultat net</th>
                  </tr>
                </thead>
                <tbody>
                  {propertyBalance.map((p, i) =>
                  <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                      <td className="py-2.5 px-4 font-medium flex items-center gap-2"><Building2 className="w-4 h-4 text-slate-400" />{p.name}</td>
                      <td className="py-2.5 px-4 text-right text-emerald-600 font-medium">{formatXAF(p.revenue)} XAF</td>
                      <td className="py-2.5 px-4 text-right text-red-600 font-medium">{formatXAF(p.expense)} XAF</td>
                      <td className={`py-2.5 px-4 text-right font-bold ${p.net >= 0 ? "text-emerald-600" : "text-red-600"}`}>{formatXAF(p.net)} XAF</td>
                    </tr>
                  )}
                  <tr className="bg-slate-50 font-semibold">
                    <td className="py-3 px-4">TOTAL</td>
                    <td className="py-3 px-4 text-right text-emerald-600">{formatXAF(totalRevenue)} XAF</td>
                    <td className="py-3 px-4 text-right text-red-600">{formatXAF(totalExpense)} XAF</td>
                    <td className={`py-3 px-4 text-right ${netResult >= 0 ? "text-emerald-600" : "text-red-600"}`}>{formatXAF(netResult)} XAF</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="resultat" className="mt-4">
          <Card className="p-6">
            <h3 className="text-base font-semibold mb-4">Compte de résultat — {year}</h3>
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 rounded-xl">
                <h4 className="text-sm font-semibold text-emerald-800 mb-2">Produits</h4>
                <div className="flex justify-between text-sm"><span>Revenus locatifs</span><span className="font-bold">{formatXAF(totalRevenue)} XAF</span></div>
              </div>
              <div className="p-4 bg-red-50 rounded-xl">
                <h4 className="text-sm font-semibold text-red-800 mb-2">Charges</h4>
                <div className="flex justify-between text-sm"><span>Total charges</span><span className="font-bold">{formatXAF(totalExpense)} XAF</span></div>
                <div className="flex justify-between text-sm mt-1 text-slate-500"><span>dont déductibles</span><span>{formatXAF(deductibleCharges)} XAF</span></div>
              </div>
              <div className={`p-4 rounded-xl ${netResult >= 0 ? "bg-blue-50" : "bg-red-50"}`}>
                <div className="flex justify-between text-base font-bold">
                  <span>Résultat net</span>
                  <span className={netResult >= 0 ? "text-emerald-600" : "text-red-600"}>{formatXAF(netResult)} XAF</span>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="tva" className="mt-4">
          <Card className="p-6">
            <h3 className="text-base font-semibold mb-4">TVA — {year}</h3>
            <div className="space-y-3">
              <div className="flex justify-between p-3 bg-slate-50 rounded-lg text-sm"><span>TVA collectée</span><span className="font-bold">{formatXAF(tvaCollected)} XAF</span></div>
              <div className="flex justify-between p-3 bg-slate-50 rounded-lg text-sm"><span>TVA déductible (sur charges)</span><span className="font-bold">{formatXAF(tvaDeductible)} XAF</span></div>
              <div className="flex justify-between p-3 bg-blue-50 rounded-lg text-sm font-bold">
                <span>TVA nette à déclarer</span>
                <span>{formatXAF(tvaCollected - tvaDeductible)} XAF</span>
              </div>
              <p className="text-xs text-slate-400 mt-2">* Configurez le taux de TVA dans les Paramètres pour activer le calcul automatique.</p>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

}