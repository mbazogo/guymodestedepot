import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Archive, ArchiveRestore, Building2, Users, FileText, MapPin, CheckCircle2, Loader2 } from "lucide-react";

function formatXAF(v) { return new Intl.NumberFormat("fr-FR").format(v || 0); }

const propertyStatusLabels = { occupied: "Occupé", vacant: "Vacant", maintenance: "En travaux" };
const tenantStatusLabels = { active: "Actif", inactive: "Inactif", pending: "En attente" };
const leaseStatusLabels = { active: "Actif", expired: "Expiré", terminated: "Résilié", draft: "Brouillon" };

export default function Archives() {
  const [tab, setTab] = useState("properties");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const qc = useQueryClient();

  const { data: properties = [], isLoading: lp } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list()
  });

  const { data: tenants = [], isLoading: lt } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => base44.entities.Tenant.list()
  });

  const { data: leases = [], isLoading: ll } = useQuery({
    queryKey: ["leases"],
    queryFn: () => base44.entities.Lease.list()
  });

  const restorePropertyMutation = useMutation({
    mutationFn: (id) => base44.entities.Property.update(id, { archived: false }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["properties"] })
  });

  const restoreTenantMutation = useMutation({
    mutationFn: (id) => base44.entities.Tenant.update(id, { archived: false }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tenants"] })
  });

  const restoreLeaseMutation = useMutation({
    mutationFn: (id) => base44.entities.Lease.update(id, { archived: false }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leases"] })
  });

  const bulkArchiveRestoreMutation = useMutation({
    mutationFn: ({ action, entityType, ids }) =>
      base44.functions.invoke('archiveOperations', { action, entityType, ids }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["properties"] });
      qc.invalidateQueries({ queryKey: ["tenants"] });
      qc.invalidateQueries({ queryKey: ["leases"] });
      setSelectedIds(new Set());
    }
  });

  const archivedProperties = properties.filter((p) => p.archived);
  const archivedTenants = tenants.filter((t) => t.archived);
  const archivedLeases = leases.filter((l) => l.archived);

  const totalArchived = archivedProperties.length + archivedTenants.length + archivedLeases.length;

  const toggleSelection = (id) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedIds(newSet);
  };

  const toggleAllSelection = (items) => {
    if (selectedIds.size === items.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(items.map(i => i.id)));
    }
  };

  const handleBulkRestore = () => {
    if (selectedIds.size === 0) return;
    const entityMap = { properties: 'Property', tenants: 'Tenant', leases: 'Lease' };
    bulkArchiveRestoreMutation.mutate({
      action: 'restore',
      entityType: entityMap[tab],
      ids: Array.from(selectedIds)
    });
  };

  const handleArchiveAll = () => {
    const items = tab === 'properties' ? archivedProperties.length === 0 ? properties.filter(p => !p.archived) : [] :
                  tab === 'tenants' ? archivedTenants.length === 0 ? tenants.filter(t => !t.archived) : [] :
                  archivedLeases.length === 0 ? leases.filter(l => !l.archived) : [];
    
    if (items.length === 0) return;
    if (!confirm(`Êtes-vous sûr d'archiver ${items.length} élément(s) ?`)) return;
    
    const entityMap = { properties: 'Property', tenants: 'Tenant', leases: 'Lease' };
    bulkArchiveRestoreMutation.mutate({
      action: 'archive',
      entityType: entityMap[tab],
      ids: items.map(i => i.id)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-slate-700 text-xl font-bold flex items-center gap-2">
            <Archive className="w-6 h-6 text-slate-500" /> Archives
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {totalArchived} élément(s) archivé(s) — historique conservé pour référence
          </p>
        </div>
        {(archivedProperties.length === 0 || archivedTenants.length === 0 || archivedLeases.length === 0) && (
          <Button
            size="sm"
            variant="outline"
            className="text-amber-600 border-amber-200 hover:bg-amber-50"
            onClick={handleArchiveAll}
          >
            <Archive className="w-3.5 h-3.5 mr-2" />
            Archiver tout
          </Button>
        )}
      </div>

      {selectedIds.size > 0 && (
        <Card className="p-4 bg-blue-50 border-blue-200 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-blue-900">{selectedIds.size} élément(s) sélectionné(s)</p>
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSelectedIds(new Set())}
            >
              Annuler
            </Button>
            <Button
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
              onClick={handleBulkRestore}
              disabled={bulkArchiveRestoreMutation.isPending}
            >
              {bulkArchiveRestoreMutation.isPending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <ArchiveRestore className="w-3.5 h-3.5" />
              )}
              Restaurer tout
            </Button>
          </div>
        </Card>
      )}

      <Tabs value={tab} onValueChange={(newTab) => { setTab(newTab); setSelectedIds(new Set()); }}>
        <TabsList>
          <TabsTrigger value="properties" className="flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5" /> Biens
            {archivedProperties.length > 0 && (
              <span className="ml-1 bg-slate-200 text-slate-700 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {archivedProperties.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="tenants" className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5" /> Locataires
            {archivedTenants.length > 0 && (
              <span className="ml-1 bg-slate-200 text-slate-700 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {archivedTenants.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="leases" className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> Baux
            {archivedLeases.length > 0 && (
              <span className="ml-1 bg-slate-200 text-slate-700 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {archivedLeases.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Archived Properties */}
      {tab === "properties" && (
        <div className="space-y-3">
          {archivedProperties.length > 0 && (
            <div className="flex gap-2 pb-2">
              <input
                type="checkbox"
                checked={selectedIds.size === archivedProperties.length}
                onChange={() => toggleAllSelection(archivedProperties)}
                className="rounded cursor-pointer"
              />
              <span className="text-sm text-slate-600">{selectedIds.size === archivedProperties.length ? "Désélectionner" : "Sélectionner"} tout</span>
            </div>
          )}
          {archivedProperties.length === 0 ? (
            <EmptyArchive icon={Building2} label="Aucun bien archivé" />
          ) : archivedProperties.map((p) => (
            <Card key={p.id} className={`p-4 bg-slate-50 border-slate-200 ${selectedIds.has(p.id) ? 'ring-2 ring-blue-500' : 'opacity-80'}`}>
              <div className="flex items-center justify-between gap-3">
                <input
                  type="checkbox"
                  checked={selectedIds.has(p.id)}
                  onChange={() => toggleSelection(p.id)}
                  className="rounded cursor-pointer mt-0.5"
                />
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-9 h-9 rounded-lg bg-slate-200 flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-slate-500" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-700 text-sm">{p.name}</h3>
                      <Badge className="bg-slate-100 text-slate-600 text-[10px]">{propertyStatusLabels[p.status]}</Badge>
                    </div>
                    {p.address && (
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3" />{p.address}{p.city ? `, ${p.city}` : ""}
                      </p>
                    )}
                    <p className="text-xs text-slate-400">{formatXAF(p.rent_amount)} XAF/mois</p>
                  </div>
                </div>
                <Button
                  size="sm" variant="outline"
                  className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                  onClick={() => restorePropertyMutation.mutate(p.id)}
                  disabled={restorePropertyMutation.isPending}
                >
                  <ArchiveRestore className="w-3.5 h-3.5 mr-1" /> Restaurer
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Archived Tenants */}
      {tab === "tenants" && (
        <div className="space-y-3">
          {archivedTenants.length > 0 && (
            <div className="flex gap-2 pb-2">
              <input
                type="checkbox"
                checked={selectedIds.size === archivedTenants.length}
                onChange={() => toggleAllSelection(archivedTenants)}
                className="rounded cursor-pointer"
              />
              <span className="text-sm text-slate-600">{selectedIds.size === archivedTenants.length ? "Désélectionner" : "Sélectionner"} tout</span>
            </div>
          )}
          {archivedTenants.length === 0 ? (
            <EmptyArchive icon={Users} label="Aucun locataire archivé" />
          ) : archivedTenants.map((t) => (
            <Card key={t.id} className={`p-4 bg-slate-50 border-slate-200 ${selectedIds.has(t.id) ? 'ring-2 ring-blue-500' : 'opacity-80'}`}>
              <div className="flex items-center justify-between gap-3">
                <input
                  type="checkbox"
                  checked={selectedIds.has(t.id)}
                  onChange={() => toggleSelection(t.id)}
                  className="rounded cursor-pointer mt-0.5"
                />
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-semibold text-sm">
                    {t.first_name?.[0]}{t.last_name?.[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-700 text-sm">{t.first_name} {t.last_name}</h3>
                      <Badge className="bg-slate-100 text-slate-600 text-[10px]">{tenantStatusLabels[t.status]}</Badge>
                    </div>
                    <p className="text-xs text-slate-400">{t.property_name || "—"} • {formatXAF(t.rent_amount)} XAF/mois</p>
                  </div>
                </div>
                <Button
                  size="sm" variant="outline"
                  className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                  onClick={() => restoreTenantMutation.mutate(t.id)}
                  disabled={restoreTenantMutation.isPending}
                >
                  <ArchiveRestore className="w-3.5 h-3.5 mr-1" /> Restaurer
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Archived Leases */}
      {tab === "leases" && (
        <div className="space-y-3">
          {archivedLeases.length > 0 && (
            <div className="flex gap-2 pb-2">
              <input
                type="checkbox"
                checked={selectedIds.size === archivedLeases.length}
                onChange={() => toggleAllSelection(archivedLeases)}
                className="rounded cursor-pointer"
              />
              <span className="text-sm text-slate-600">{selectedIds.size === archivedLeases.length ? "Désélectionner" : "Sélectionner"} tout</span>
            </div>
          )}
          {archivedLeases.length === 0 ? (
            <EmptyArchive icon={FileText} label="Aucun bail archivé" />
          ) : archivedLeases.map((l) => (
            <Card key={l.id} className={`p-4 bg-slate-50 border-slate-200 ${selectedIds.has(l.id) ? 'ring-2 ring-blue-500' : 'opacity-80'}`}>
              <div className="flex items-center justify-between gap-3">
                <input
                  type="checkbox"
                  checked={selectedIds.has(l.id)}
                  onChange={() => toggleSelection(l.id)}
                  className="rounded cursor-pointer mt-0.5"
                />
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-9 h-9 rounded-lg bg-slate-200 flex items-center justify-center">
                    <FileText className="w-4 h-4 text-slate-500" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-700 text-sm">{l.tenant_name || "—"}</h3>
                      <Badge className="bg-slate-100 text-slate-600 text-[10px]">{leaseStatusLabels[l.status]}</Badge>
                    </div>
                    <p className="text-xs text-slate-400">
                      {l.property_name} • {l.start_date} → {l.end_date || "Indéterminé"} • {formatXAF(l.rent_amount)} XAF/mois
                    </p>
                  </div>
                </div>
                <Button
                  size="sm" variant="outline"
                  className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                  onClick={() => restoreLeaseMutation.mutate(l.id)}
                  disabled={restoreLeaseMutation.isPending}
                >
                  <ArchiveRestore className="w-3.5 h-3.5 mr-1" /> Restaurer
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyArchive({ icon: Icon, label }) {
  return (
    <div className="text-center py-16 text-slate-400">
      <Archive className="w-12 h-12 mx-auto mb-3 text-slate-200" />
      <p>{label}</p>
    </div>
  );
}