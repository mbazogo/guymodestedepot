import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Phone, Mail, FileText, Wallet, User, Building2, Printer, Send, Eye, ClipboardList, MessageSquare, Download, Loader2, MessageCircle } from "lucide-react";
import { jsPDF } from "jspdf";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import LeaseContractModal from "../components/leases/LeaseContractModal";
import TenantInteractions from "../components/tenants/TenantInteractions";
import TenantLeaseAlerts from "../components/tenants/TenantLeaseAlerts";
import TenantPaymentHistory from "../components/tenants/TenantPaymentHistory";

function formatXAF(v) {return new Intl.NumberFormat("fr-FR").format(v || 0);}
const MONTHS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
const statusPayLabels = { paid: "Payé", partial: "Partiel", pending: "En attente", late: "En retard" };
const statusPayClasses = { paid: "bg-emerald-100 text-emerald-700", partial: "bg-amber-100 text-amber-700", pending: "bg-amber-100 text-amber-700", late: "bg-red-100 text-red-700" };
const docTypeLabels = { bail: "Bail", quittance: "Quittance", avis_echeance: "Avis d'échéance", courrier: "Courrier", attestation: "Attestation", relance: "Relance", autre: "Autre" };
const docStatusColors = { draft: "bg-slate-100 text-slate-600", sent: "bg-blue-100 text-blue-700", signed: "bg-emerald-100 text-emerald-700" };
const docStatusLabels = { draft: "Brouillon", sent: "Envoyé", signed: "Signé" };

function printDocument(doc, tenant, property, settings) {
  const ownerName = settings?.owner_name || "Le Propriétaire";
  const companyName = settings?.company_name || "Zenden ImmoLoc";
  const today = new Date().toLocaleDateString("fr-FR");
  const logoHtml = settings?.logo_url ? `<img src="${settings.logo_url}" style="height:48px;object-fit:contain;display:block;margin-bottom:8px;" />` : "";

  // Auto-replace placeholders
  let content = doc.content || "";
  if (tenant) {
    const fullName = `${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}`.trim();
    content = content.
    replace(/\[LOCATAIRE\]/g, fullName).
    replace(/\[LOYER\]/g, formatXAF(tenant.rent_amount)).
    replace(/\[CHARGES\]/g, formatXAF(property?.charges_amount || 0)).
    replace(/\[TOTAL\]/g, formatXAF((tenant.rent_amount || 0) + (property?.charges_amount || 0))).
    replace(/\[ADRESSE\]/g, property?.address || property?.name || "").
    replace(/\[VILLE\]/g, property?.city || "").
    replace(/\[DATE\]/g, today).
    replace(/\[DATE_FIN_BAIL\]/g, tenant.lease_end || "").
    replace(/\[DATE_ECHEANCE\]/g, `${settings?.payment_day || 1}/${new Date().getMonth() + 1}/${new Date().getFullYear()}`).
    replace(/\[MOIS\]/g, MONTHS_FR[new Date().getMonth()]).
    replace(/\[ANNÉE\]/g, String(new Date().getFullYear())).
    replace(/\[PROPRIÉTAIRE\]/g, ownerName).
    replace(/\[DÉBUT\]/g, tenant.lease_start || "").
    replace(/\[FIN\]/g, tenant.lease_end || "").
    replace(/\[ANCIEN_LOYER\]/g, formatXAF(tenant.rent_amount)).
    replace(/\[NOUVEAU_LOYER\]/g, formatXAF(tenant.rent_amount));
  }

  const html = `<html><head><title>${doc.name}</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 50px; color: #1e293b; font-size: 12pt; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f2b4c; padding-bottom: 16px; margin-bottom: 32px; }
    .company { font-size: 18px; font-weight: bold; color: #0f2b4c; }
    .sub { font-size: 9px; color: #64748b; text-transform: uppercase; letter-spacing: 2px; }
    .ref { text-align: right; font-size: 11px; color: #64748b; }
    .title { text-align: center; margin: 28px 0; }
    .title h1 { font-size: 18px; font-weight: bold; text-transform: uppercase; color: #0f2b4c; display: inline-block; border: 2px solid #0f2b4c; padding: 6px 20px; }
    .content { white-space: pre-wrap; font-size: 12pt; line-height: 1.8; margin: 24px 0; }
    .footer { margin-top: 60px; display: flex; justify-content: flex-end; }
    .sig { text-align: center; }
    .sig-line { border-top: 1px solid #1e293b; width: 200px; margin: 60px auto 8px; font-size: 11px; }
    .legal { text-align: center; font-size: 9px; color: #94a3b8; margin-top: 40px; }
    @media print { body { padding: 30px; } }
  </style></head><body>
  <div class="header">
    <div>${logoHtml}<div class="company">${companyName}</div><div class="sub">Gestion locative</div></div>
    <div class="ref">
      <div>Réf : ${doc.id?.slice(-6).toUpperCase() || ""}</div>
      <div>Date : ${today}</div>
      ${tenant ? `<div>Locataire : ${tenant.first_name} ${tenant.last_name}</div>` : ""}
    </div>
  </div>
  <div class="title"><h1>${doc.name}</h1></div>
  <div class="content">${content}</div>
  <div class="footer"><div class="sig"><div class="sig-line">${ownerName}</div></div></div>
  <div class="legal">Document généré par ${companyName} • ${today}</div>
  </body></html>`;

  const w = window.open("", "_blank");
  w.document.write(html);
  w.document.close();
  w.print();
}

const TABS = ["Informations", "Bail & Contrat", "Interactions", "Paiements", "Documents", "Charges"];

export default function TenantDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const tenantId = urlParams.get("id");
  const [tab, setTab] = useState("Informations");
  const [previewDoc, setPreviewDoc] = useState(null);
  const [contractLease, setContractLease] = useState(null);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [selectedPaymentId, setSelectedPaymentId] = useState(null);

  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: payments = [] } = useQuery({ queryKey: ["payments"], queryFn: () => base44.entities.Payment.list() });
  const { data: charges = [] } = useQuery({ queryKey: ["charges"], queryFn: () => base44.entities.Charge.list() });
  const { data: documents = [] } = useQuery({ queryKey: ["documents"], queryFn: () => base44.entities.Document.list() });
  const { data: leases = [] } = useQuery({ queryKey: ["leases"], queryFn: () => base44.entities.Lease.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const tenant = tenants.find((t) => t.id === tenantId);
  const tenantPayments = payments.filter((p) => p.tenant_id === tenantId);
  const tenantCharges = charges.filter((c) => c.property_id === tenant?.property_id);
  const tenantDocs = documents.filter((d) => d.tenant_id === tenantId);
  const tenantLease = leases.find((l) => l.tenant_id === tenantId);
  const property = properties.find((p) => p.id === tenant?.property_id);
  const totalPaid = tenantPayments.filter((p) => p.status === "paid" || p.status === "partial").reduce((s, p) => s + (p.amount || 0), 0);

  // Paiements payés uniquement (pour le sélecteur de mois)
  const paidPayments = tenantPayments.
  filter((p) => p.status === "paid" || p.status === "partial").
  sort((a, b) => b.period_year * 100 + b.period_month - (a.period_year * 100 + a.period_month));

  const fmtNum = (v) => {
    const n = Math.round(Number(v) || 0);
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  };

  const nombreEnLettres = (montant) => {
    let n = Math.round(montant || 0);
    if (n === 0) return "zéro";
    const u = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf",
    "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf"];
    const diz = ["", "dix", "vingt", "trente", "quarante", "cinquante", "soixante", "soixante", "quatre-vingt", "quatre-vingt"];
    const moinsDeCent = (x) => {
      if (x === 0) return "";
      if (x < 20) return u[x];
      const t = Math.floor(x / 10),r = x % 10;
      if (t === 7) return "soixante-" + u[10 + r];
      if (t === 8) return r === 0 ? "quatre-vingts" : "quatre-vingt-" + u[r];
      if (t === 9) return r === 0 ? "quatre-vingts" : "quatre-vingt-" + u[r];
      return diz[t] + (r === 1 && t !== 8 ? "-et-un" : r > 0 ? "-" + u[r] : "");
    };
    const moinsDeMille = (x) => {
      if (x === 0) return "";
      if (x < 100) return moinsDeCent(x);
      const c = Math.floor(x / 100),r = x % 100;
      const centStr = (c === 1 ? "" : u[c] + " ") + "cent" + (r === 0 && c > 1 ? "s" : "");
      return centStr + (r > 0 ? " " + moinsDeCent(r) : "");
    };
    let res = "";
    if (n >= 1000000) {
      const m = Math.floor(n / 1000000);
      res += moinsDeMille(m) + " million" + (m > 1 ? "s" : "") + " ";
      n %= 1000000;
    }
    if (n >= 1000) {
      const m = Math.floor(n / 1000);
      res += (m === 1 ? "" : moinsDeMille(m) + " ") + "mille" + (n % 1000 > 0 ? " " : "");
      n %= 1000;
    }
    if (n > 0) res += moinsDeMille(n);
    return res.trim();
  };

  const buildReceiptText = (payment) => {
    const tenantFullName = `${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}`.trim();
    const monthLabel = MONTHS_FR[(payment.period_month || 1) - 1];
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const methodLabels = { especes: "Especes", virement: "Virement bancaire", cheque: "Cheque", mobile_money: "Mobile Money", autre: "Autre" };
    return `Bonjour ${tenantFullName},\n\nVeuillez trouver ci-apres votre quittance de loyer.\n\nPeriode : ${monthLabel} ${payment.period_year}\nBien : ${tenant.property_name || ""}\nMontant : ${fmtNum(payment.amount)} XAF\nMode : ${methodLabels[payment.payment_method] || payment.payment_method || "-"}\n\nEmis par ${companyName}`;
  };

  const sendReceiptWhatsApp = (payment) => {
    const text = encodeURIComponent(buildReceiptText(payment));
    const phone = tenant.phone ? tenant.phone.replace(/\D/g, "") : "";
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  const printReceiptDirect = (payment) => {
    const tenantFullName = `${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}`.trim();
    const monthLabel = MONTHS_FR[(payment.period_month || 1) - 1];
    const companyName = settings?.company_name || "Zenden ImmoLoc";
    const ownerName = settings?.owner_name || "Le Proprietaire";
    const today = new Date().toLocaleDateString("fr-FR");
    const methodLabels = { especes: "Especes", virement: "Virement bancaire", cheque: "Cheque", mobile_money: "Mobile Money", autre: "Autre" };
    const amountLetters = nombreEnLettres(payment.amount || 0);
    const sigHtml = settings?.signature_url ? `<img src="${settings.signature_url}" style="height:60px;object-fit:contain;display:block;margin:0 auto 4px;" />` : `<div style="height:60px;"></div>`;
    const html = `<html><head><title>Quittance ${monthLabel} ${payment.period_year}</title>
    <style>body{font-family:Arial,sans-serif;padding:40px;color:#1e293b;font-size:12px;}
    .hdr{background:#0f2b4c;color:#fff;padding:14px 20px;display:flex;justify-content:space-between;border-radius:6px;margin-bottom:24px;}
    .title{text-align:center;font-size:18px;font-weight:bold;text-transform:uppercase;color:#0f2b4c;border:2px solid #0f2b4c;padding:6px 20px;display:inline-block;margin:0 auto;}
    .center{text-align:center;margin:12px 0;}.parties{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:16px 0;}
    .party{background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:6px;}
    .party-label{font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
    .amt{background:#0f2b4c;color:#fff;padding:16px;border-radius:8px;text-align:center;margin:16px 0;}
    .amt-v{font-size:24px;font-weight:bold;}.amt-l{font-size:11px;opacity:.8;margin-top:4px;font-style:italic;}
    .footer{margin-top:32px;border-top:1px solid #e2e8f0;padding-top:16px;display:flex;justify-content:space-between;align-items:flex-end;}
    .sig{text-align:center;}.sig-line{border-top:1px solid #1e293b;width:180px;margin:4px auto 4px;font-size:10px;}
    @media print{body{padding:20px;}}</style></head><body>
    <div class="hdr"><div><div style="font-size:16px;font-weight:bold;">${companyName}</div><div style="font-size:9px;opacity:.7;">GESTION LOCATIVE</div></div>
    <div style="text-align:right;font-size:11px;"><div>Emise le ${today}</div><div>N QTT-${(payment.id || "").slice(-6).toUpperCase()}</div></div></div>
    <div class="center"><div class="title">QUITTANCE DE LOYER</div><p style="color:#64748b;margin-top:8px;">Pour le mois de <strong>${monthLabel} ${payment.period_year}</strong></p></div>
    <div class="parties"><div class="party"><div class="party-label">Bailleur</div><strong>${ownerName}</strong>${settings?.owner_address ? `<div style="font-size:10px;color:#64748b;">${settings.owner_address}</div>` : ""}</div>
    <div class="party"><div class="party-label">Locataire</div><strong>${tenantFullName}</strong><div style="font-size:10px;color:#64748b;">${tenant.property_name || ""}</div></div></div>
    <div class="amt"><div class="amt-v">${fmtNum(payment.amount)} XAF</div><div class="amt-l">${amountLetters} francs CFA</div></div>
    <div class="footer"><div style="font-size:10px;color:#64748b;max-width:55%;">Le bailleur certifie avoir recu la somme de <strong>${fmtNum(payment.amount)} XAF</strong> (${amountLetters} francs CFA) en reglement du loyer - Mode : ${methodLabels[payment.payment_method] || "-"}</div>
    <div class="sig">${sigHtml}<div class="sig-line">${ownerName}</div></div></div>
    <div style="text-align:center;font-size:9px;color:#94a3b8;margin-top:20px;">Document genere par ${companyName}</div>
    </body></html>`;
    const w = window.open("", "_blank");
    w.document.write(html);
    w.document.close();
    w.print();
  };

  const generateReceiptPDF = async (payment) => {
    if (!tenant || !payment) return;
    setGeneratingPdf(true);

    const amount = payment.amount || 0;
    const paymentMethod = payment.payment_method || "especes";
    const companyName = (settings?.company_name || "Zenden ImmoLoc").replace(/[^\x00-\x7F]/g, (c) => c);
    const ownerName = settings?.owner_name || "Le Proprietaire";
    const tenantFullName = `${tenant.civility || ""} ${tenant.first_name} ${tenant.last_name}`.trim();
    const monthLabel = MONTHS_FR[(payment.period_month || 1) - 1];
    const today = new Date().toLocaleDateString("fr-FR");
    const methodLabels = { especes: "Especes", virement: "Virement bancaire", cheque: "Cheque", mobile_money: "Mobile Money", autre: "Autre" };

    const doc = new jsPDF({ unit: "mm", format: "a4" });
    const W = 210;
    const margin = 18;

    // Header bar
    doc.setFillColor(15, 43, 76);
    doc.rect(0, 0, W, 28, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text(companyName, margin, 13);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text("GESTION LOCATIVE", margin, 20);
    doc.setFontSize(9);
    doc.text(`Emise le ${today}`, W - margin, 13, { align: "right" });
    doc.text(`N QTT-${(payment.id || "XXXX").slice(-6).toUpperCase()}`, W - margin, 20, { align: "right" });

    // Title
    doc.setTextColor(15, 43, 76);
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text("QUITTANCE DE LOYER", W / 2, 44, { align: "center" });
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    doc.text(`Pour le mois de ${monthLabel} ${payment.period_year}`, W / 2, 52, { align: "center" });

    // Separator line
    doc.setDrawColor(15, 43, 76);
    doc.setLineWidth(0.5);
    doc.line(margin, 56, W - margin, 56);

    // Parties boxes
    const boxY = 62;
    const boxH = 28;
    const boxW = (W - margin * 2 - 6) / 2;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.roundedRect(margin, boxY, boxW, boxH, 3, 3, "FD");
    doc.roundedRect(margin + boxW + 6, boxY, boxW, boxH, 3, 3, "FD");

    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "bold");
    doc.text("BAILLEUR", margin + 5, boxY + 7);
    doc.text("LOCATAIRE", margin + boxW + 11, boxY + 7);

    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(10);
    doc.text(ownerName, margin + 5, boxY + 15);
    doc.text(tenantFullName, margin + boxW + 11, boxY + 15);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    if (settings?.owner_address) doc.text(settings.owner_address, margin + 5, boxY + 21, { maxWidth: boxW - 8 });
    doc.text(tenant.property_name || "", margin + boxW + 11, boxY + 21, { maxWidth: boxW - 8 });

    // Amount block
    const amtY = boxY + boxH + 10;
    doc.setFillColor(15, 43, 76);
    doc.roundedRect(margin, amtY, W - margin * 2, 30, 4, 4, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text(`${fmtNum(amount)} XAF`, W / 2, amtY + 11, { align: "center" });
    doc.setFontSize(9);
    doc.setFont("helvetica", "italic");
    doc.setTextColor(203, 213, 225);
    doc.text(`(${nombreEnLettres(amount)} francs CFA)`, W / 2, amtY + 18, { align: "center" });
    doc.setFont("helvetica", "normal");
    doc.text("Montant recu en reglement du loyer", W / 2, amtY + 24, { align: "center" });

    // Details grid
    const detY = amtY + 38;
    const colW = (W - margin * 2 - 8) / 3;
    const details = [
    { label: "Bien loue", value: tenant.property_name || "-" },
    { label: "Periode", value: `${monthLabel} ${payment.period_year}` },
    { label: "Mode de paiement", value: methodLabels[paymentMethod] || paymentMethod }];

    details.forEach((d, i) => {
      const x = margin + i * (colW + 4);
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.3);
      doc.roundedRect(x, detY, colW, 18, 2, 2, "FD");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.setFont("helvetica", "normal");
      doc.text(d.label.toUpperCase(), x + colW / 2, detY + 6, { align: "center" });
      doc.setFontSize(9);
      doc.setTextColor(30, 41, 59);
      doc.setFont("helvetica", "bold");
      doc.text(d.value, x + colW / 2, detY + 13, { align: "center", maxWidth: colW - 4 });
    });

    // Footer section
    const footerY = detY + 28;
    const footerText = settings?.receipt_footer_text ||
    `Le bailleur certifie avoir recu la somme de ${fmtNum(amount)} XAF en reglement du loyer du bien susmentionnne.`;
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.line(margin, footerY, W - margin, footerY);

    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "normal");
    doc.text(footerText, margin, footerY + 8, { maxWidth: 100 });

    // Signature image or line
    const sigX = W - margin - 55;
    const sigY = footerY + 5;
    if (settings?.signature_url) {
      try {
        doc.addImage(settings.signature_url, "PNG", sigX, sigY, 55, 22, undefined, "FAST");
      } catch {

        // fallback to line if image fails
      }}
    doc.setDrawColor(30, 41, 59);
    doc.setLineWidth(0.4);
    doc.line(sigX, sigY + 23, W - margin, sigY + 23);
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);
    doc.setFont("helvetica", "bold");
    doc.text(ownerName, sigX + 27.5, sigY + 29, { align: "center" });

    // Legal footer
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`Document genere par ${companyName} - Quittance valable comme recu de paiement`, W / 2, 285, { align: "center" });

    doc.save(`quittance-${tenant.last_name}-${monthLabel}-${payment.period_year}.pdf`);
    setGeneratingPdf(false);
    setShowReceiptModal(false);
  };

  if (!tenant) {
    return <div className="space-y-4"><Skeleton className="h-8 w-48" /><Skeleton className="h-64 w-full rounded-xl" /></div>;
  }

  return (
    <div className="space-y-5">
      {/* Back + Header */}
      <div className="flex items-center gap-3">
        <Link to={createPageUrl("Tenants")}>
          <Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button>
        </Link>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-slate-900">{tenant.civility} {tenant.first_name} {tenant.last_name}</h1>
          <p className="text-sm text-slate-500">{tenant.property_name}</p>
        </div>
        <Badge className={tenant.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}>
          {tenant.status === "active" ? "Actif" : tenant.status === "inactive" ? "Inactif" : "En attente"}
        </Badge>
        <Button
          onClick={() => setShowReceiptModal(true)}
          disabled={generatingPdf}
          size="sm"
          className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2">

          {generatingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
          {generatingPdf ? "Génération..." : "Quittance PDF"}
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-200 overflow-x-auto">
        {TABS.map((t) =>
        <button key={t} onClick={() => setTab(t)} className="text-cyan-600 px-4 py-2 text-sm font-bold capitalize whitespace-nowrap border-b-2 transition-colors border-transparent hover:text-slate-700">

            {t}
          </button>
        )}
      </div>

      {/* Alerts (lease end, anniversary) */}
      <TenantLeaseAlerts tenant={tenant} lease={tenantLease} />

      {/* TAB: Informations */}
      {tab === "Informations" &&
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3"><User className="w-4 h-4 text-blue-600" /><h3 className="font-semibold text-sm">Identité</h3></div>
            <div className="space-y-2 text-sm">
              <p className="text-slate-700 font-medium">{tenant.civility} {tenant.first_name} {tenant.last_name}</p>
              {tenant.id_number && <p className="text-slate-600">CNI/Passeport : {tenant.id_number}</p>}
              {tenant.phone && <p className="flex items-center gap-2 text-slate-600"><Phone className="w-3.5 h-3.5" />{tenant.phone}</p>}
              {tenant.email && <p className="flex items-center gap-2 text-slate-600"><Mail className="w-3.5 h-3.5" />{tenant.email}</p>}
              {tenant.emergency_contact && <p className="text-slate-600">Urgence : {tenant.emergency_contact}</p>}
              {tenant.notes && <p className="text-slate-500 italic text-xs mt-2">{tenant.notes}</p>}
            </div>
          </Card>
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3"><Wallet className="w-4 h-4 text-emerald-600" /><h3 className="font-semibold text-sm">Financier</h3></div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Loyer mensuel</span><span className="font-bold">{formatXAF(tenant.rent_amount)} XAF</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Dépôt de garantie</span><span className="font-semibold">{formatXAF(tenant.deposit_amount)} XAF</span></div>
              <div className="flex justify-between border-t pt-2"><span className="text-slate-500">Total encaissé</span><span className="font-bold text-emerald-600">{formatXAF(totalPaid)} XAF</span></div>
              {tenant.balance !== undefined &&
            <div className="flex justify-between"><span className="text-slate-500">Solde</span>
                  <span className={`font-bold ${tenant.balance >= 0 ? "text-emerald-600" : "text-red-600"}`}>{formatXAF(tenant.balance)} XAF</span>
                </div>
            }
            </div>
          </Card>
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3"><Building2 className="w-4 h-4 text-violet-600" /><h3 className="font-semibold text-sm">Bien loué</h3></div>
            <div className="space-y-2 text-sm">
              <p className="font-semibold text-slate-800">{tenant.property_name}</p>
              {property?.address && <p className="text-slate-600">{property.address}</p>}
              {property?.city && <p className="text-slate-600">{property.city}</p>}
              {property?.surface && <p className="text-slate-500">{property.surface} m²</p>}
              {property?.rooms && <p className="text-slate-500">{property.rooms} pièce(s)</p>}
              {tenant.lease_start && <div className="flex justify-between pt-1"><span className="text-slate-500">Début bail</span><span>{new Date(tenant.lease_start).toLocaleDateString("fr-FR")}</span></div>}
              {tenant.lease_end && <div className="flex justify-between"><span className="text-slate-500">Fin bail</span><span>{new Date(tenant.lease_end).toLocaleDateString("fr-FR")}</span></div>}
            </div>
          </Card>
        </div>
      }

      {/* TAB: Bail & Contrat */}
      {tab === "Bail & Contrat" &&
      <div className="space-y-4">
          {tenantLease ?
        <Card className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-emerald-600" /><h3 className="font-semibold">Contrat de bail</h3></div>
                <div className="flex gap-2">
                  <Badge className={tenantLease.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}>
                    {tenantLease.status === "active" ? "Actif" : tenantLease.status}
                  </Badge>
                  <Button size="sm" onClick={() => setContractLease(tenantLease)} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
                    <Printer className="w-3.5 h-3.5 mr-1" /> Imprimer le contrat
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div><span className="text-slate-500 text-xs block">Type</span><span className="font-medium">{tenantLease.type === "non_meuble" ? "Non meublé" : tenantLease.type === "meuble" ? "Meublé" : tenantLease.type}</span></div>
                <div><span className="text-slate-500 text-xs block">Début</span><span className="font-medium">{tenantLease.start_date ? new Date(tenantLease.start_date).toLocaleDateString("fr-FR") : "—"}</span></div>
                <div><span className="text-slate-500 text-xs block">Fin</span><span className="font-medium">{tenantLease.end_date ? new Date(tenantLease.end_date).toLocaleDateString("fr-FR") : "Indéterminé"}</span></div>
                <div><span className="text-slate-500 text-xs block">Jour paiement</span><span className="font-medium">{tenantLease.payment_day || 1}</span></div>
                <div><span className="text-slate-500 text-xs block">Loyer</span><span className="font-bold text-emerald-600">{formatXAF(tenantLease.rent_amount)} XAF</span></div>
                <div><span className="text-slate-500 text-xs block">Charges</span><span className="font-medium">{formatXAF(tenantLease.charges_amount)} XAF</span></div>
                <div><span className="text-slate-500 text-xs block">Dépôt garantie</span><span className="font-medium">{formatXAF(tenantLease.deposit_amount)} XAF</span></div>
                {tenantLease.tva_applicable && <div><span className="text-slate-500 text-xs block">TVA</span><span className="font-medium">{tenantLease.tva_rate}%</span></div>}
              </div>
              {tenantLease.clauses &&
          <div className="mt-4 bg-slate-50 rounded-lg p-3">
                  <span className="text-xs text-slate-500 block mb-1">Clauses particulières</span>
                  <p className="text-sm text-slate-700 whitespace-pre-wrap">{tenantLease.clauses}</p>
                </div>
          }
            </Card> :

        <div className="text-center py-16 text-slate-400">
              <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun bail trouvé pour ce locataire</p>
              <Link to={createPageUrl("Leases")} className="text-sm text-blue-600 hover:underline mt-2 block">Créer un bail →</Link>
            </div>
        }

          {/* Docs de type bail liés */}
          {tenantDocs.filter((d) => d.type === "bail").length > 0 &&
        <Card className="p-5">
              <h3 className="font-semibold text-sm mb-3">Documents de bail associés</h3>
              <div className="space-y-2">
                {tenantDocs.filter((d) => d.type === "bail").map((doc) =>
            <div key={doc.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-blue-500" />
                      <span className="text-sm font-medium">{doc.name}</span>
                      <Badge className={`${docStatusColors[doc.status]} text-[10px]`}>{docStatusLabels[doc.status]}</Badge>
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => setPreviewDoc(doc)}><Eye className="w-4 h-4 text-slate-500" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => printDocument(doc, tenant, property, settings)}><Printer className="w-4 h-4 text-slate-500" /></Button>
                    </div>
                  </div>
            )}
              </div>
            </Card>
        }
        </div>
      }

      {/* TAB: Interactions */}
      {tab === "Interactions" &&
      <TenantInteractions tenantId={tenantId} tenantName={`${tenant.first_name} ${tenant.last_name}`} />
      }

      {/* TAB: Paiements */}
      {tab === "Paiements" &&
      <TenantPaymentHistory
        tenant={tenant}
        payments={tenantPayments}
        lease={tenantLease}
        onPrintReceipt={printReceiptDirect}
        onWhatsAppReceipt={sendReceiptWhatsApp}
        onDownloadReceipt={(p) => {setSelectedPaymentId(p.id);generateReceiptPDF(p);}}
        generatingPdf={generatingPdf}
        selectedPaymentId={selectedPaymentId} />

      }

      {/* TAB: Documents */}
      {tab === "Documents" &&
      <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold text-slate-800">Tous les documents ({tenantDocs.length})</h3>
            <Link to={createPageUrl("Documents")}><Button size="sm" variant="outline">Gérer les documents →</Button></Link>
          </div>
          {tenantDocs.length === 0 ?
        <div className="text-center py-16 text-slate-400">
              <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun document associé à ce locataire</p>
            </div> :

        Object.entries(
          tenantDocs.reduce((acc, doc) => {const t = doc.type || "autre";if (!acc[t]) acc[t] = [];acc[t].push(doc);return acc;}, {})
        ).map(([type, docs]) =>
        <Card key={type} className="p-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">{docTypeLabels[type] || type}</h4>
                <div className="space-y-2">
                  {docs.map((doc) =>
            <div key={doc.id} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-500 shrink-0" />
                        <div>
                          <p className="text-sm font-medium">{doc.name}</p>
                          <p className="text-[10px] text-slate-400">{new Date(doc.created_date).toLocaleDateString("fr-FR")}</p>
                        </div>
                        <Badge className={`${docStatusColors[doc.status]} text-[10px]`}>{docStatusLabels[doc.status]}</Badge>
                      </div>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" title="Aperçu" onClick={() => setPreviewDoc(doc)}><Eye className="w-4 h-4 text-slate-500" /></Button>
                        <Button size="icon" variant="ghost" title="Imprimer" onClick={() => printDocument(doc, tenant, property, settings)}><Printer className="w-4 h-4 text-slate-500" /></Button>
                        {tenant?.email &&
                <Button size="icon" variant="ghost" title="Envoyer par email" onClick={async () => {
                  await base44.integrations.Core.SendEmail({ to: tenant.email, subject: doc.name, body: doc.content || "" });
                  alert("Email envoyé !");
                }}><Send className="w-4 h-4 text-blue-500" /></Button>
                }
                      </div>
                    </div>
            )}
                </div>
              </Card>
        )
        }
          {/* EDL liés */}
          <Link to={createPageUrl("InventoryReports")} className="block">
            <Card className="p-4 border-dashed border-teal-200 bg-teal-50 hover:bg-teal-100 transition-colors">
              <div className="flex items-center gap-2 text-teal-700">
                <ClipboardList className="w-4 h-4" />
                <span className="text-sm font-medium">Voir les états des lieux (EDL) de ce locataire →</span>
              </div>
            </Card>
          </Link>
        </div>
      }

      {/* TAB: Charges */}
      {tab === "Charges" &&
      <Card className="p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Charges liées au bien ({tenantCharges.length})</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="text-left py-2 text-slate-500 font-medium">Date</th>
                  <th className="text-left py-2 text-slate-500 font-medium">Catégorie</th>
                  <th className="text-left py-2 text-slate-500 font-medium">Description</th>
                  <th className="text-right py-2 text-slate-500 font-medium">Montant</th>
                </tr>
              </thead>
              <tbody>
                {tenantCharges.map((c) =>
              <tr key={c.id} className="border-b border-slate-50">
                    <td className="py-2.5">{c.date ? new Date(c.date).toLocaleDateString("fr-FR") : "—"}</td>
                    <td className="py-2.5 capitalize">{c.category?.replace(/_/g, " ")}</td>
                    <td className="py-2.5 text-slate-500">{c.description || "—"}</td>
                    <td className="py-2.5 text-right font-semibold">{formatXAF(c.amount)} XAF</td>
                  </tr>
              )}
                {tenantCharges.length === 0 && <tr><td colSpan={4} className="text-center py-6 text-slate-400">Aucune charge</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
      }

      {/* Preview Dialog */}
      <Dialog open={!!previewDoc} onOpenChange={() => setPreviewDoc(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{previewDoc?.name}</DialogTitle></DialogHeader>
          <pre className="whitespace-pre-wrap text-sm text-slate-700 bg-slate-50 p-6 rounded-lg border">{previewDoc?.content}</pre>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewDoc(null)}>Fermer</Button>
            <Button onClick={() => printDocument(previewDoc, tenant, property, settings)} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              <Printer className="w-4 h-4 mr-2" /> Imprimer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Receipt Month Picker Modal */}
      <Dialog open={showReceiptModal} onOpenChange={setShowReceiptModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              Quittance de loyer
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <p className="text-sm text-slate-500 mb-4">Sélectionnez le mois et l'action souhaitée :</p>
            {paidPayments.length === 0 ?
            <div className="text-center py-8 text-slate-400">
                <FileText className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                <p className="text-sm">Aucun paiement enregistré pour ce locataire.</p>
              </div> :

            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {paidPayments.map((p) =>
              <div key={p.id} className="p-3 rounded-lg border border-slate-200 bg-slate-50">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-semibold text-slate-800 text-sm">{MONTHS_FR[(p.period_month || 1) - 1]} {p.period_year}</p>
                        <p className="text-xs text-slate-500">{p.payment_method?.replace(/_/g, " ") || "—"}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-emerald-700 text-sm">{formatXAF(p.amount)} XAF</p>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusPayClasses[p.status] || "bg-slate-100 text-slate-600"}`}>
                          {statusPayLabels[p.status] || p.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <button
                    onClick={() => {setSelectedPaymentId(p.id);generateReceiptPDF(p);}}
                    disabled={generatingPdf && selectedPaymentId === p.id}
                    className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors">

                        {generatingPdf && selectedPaymentId === p.id ?
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> :
                    <Download className="w-3.5 h-3.5" />}
                        Télécharger PDF
                      </button>
                      <button
                    onClick={() => printReceiptDirect(p)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-md bg-slate-700 hover:bg-slate-800 text-white text-xs font-medium transition-colors">

                        <Printer className="w-3.5 h-3.5" />
                        Imprimer
                      </button>
                      <button
                    onClick={() => sendReceiptWhatsApp(p)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-md bg-green-500 hover:bg-green-600 text-white text-xs font-medium transition-colors">

                        <MessageCircle className="w-3.5 h-3.5" />
                        WhatsApp
                      </button>
                    </div>
                  </div>
              )}
              </div>
            }
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReceiptModal(false)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Lease Contract Modal */}
      {contractLease &&
      <LeaseContractModal
        lease={contractLease}
        tenant={tenant}
        property={property}
        settings={settings}
        onClose={() => setContractLease(null)} />

      }
    </div>);

}