import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, ClipboardList, Search, Printer, CheckCircle, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import InventoryPrintModal from "../components/inventory/InventoryPrintModal";

const HOUSING_TYPES = [
{ value: "appartement", label: "Appartement" },
{ value: "studio", label: "Studio" },
{ value: "maison", label: "Maison" },
{ value: "villa", label: "Villa" },
{ value: "local_commercial", label: "Local commercial" },
{ value: "autre", label: "Autre" }];


const ROOM_TEMPLATES = {
  appartement: ["Entrée / Couloir", "Salon", "Cuisine", "Chambre 1", "Chambre 2", "Salle de bain", "WC", "Balcon", "Parking"],
  studio: ["Pièce principale", "Coin cuisine", "Salle de bain / WC", "Entrée"],
  maison: ["Entrée", "Salon", "Salle à manger", "Cuisine", "Chambre 1", "Chambre 2", "Chambre 3", "Salle de bain", "WC", "Garage", "Jardin", "Terrasse"],
  villa: ["Entrée", "Salon", "Salle à manger", "Cuisine", "Chambre 1", "Chambre 2", "Chambre 3", "Chambre 4", "Salle de bain 1", "Salle de bain 2", "WC", "Garage", "Piscine", "Jardin"],
  local_commercial: ["Espace principal", "Réserve / Stockage", "Bureau", "WC", "Façade"],
  autre: ["Pièce 1", "Pièce 2"]
};

const CONDITION_OPTIONS = [
{ value: "bon", label: "Bon état" },
{ value: "moyen", label: "État moyen" },
{ value: "mauvais", label: "Mauvais état" },
{ value: "na", label: "N/A" }];


const CONDITION_COLORS = { bon: "bg-emerald-100 text-emerald-700", moyen: "bg-amber-100 text-amber-700", mauvais: "bg-red-100 text-red-700", na: "bg-slate-100 text-slate-500" };

function emptyRoom(name) {return { name, condition: "bon", notes: "" };}

export default function InventoryReports() {
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [printReport, setPrintReport] = useState(null);
  const [filterType, setFilterType] = useState("all");

  const { data: reports = [], isLoading } = useQuery({ queryKey: ["inventoryReports"], queryFn: () => base44.entities.InventoryReport.list() });
  const { data: tenants = [] } = useQuery({ queryKey: ["tenants"], queryFn: () => base44.entities.Tenant.list() });
  const { data: properties = [] } = useQuery({ queryKey: ["properties"], queryFn: () => base44.entities.Property.list() });
  const { data: settingsList = [] } = useQuery({ queryKey: ["settings"], queryFn: () => base44.entities.AppSettings.list() });
  const settings = settingsList[0];

  const saveMutation = useMutation({
    mutationFn: (data) => editingId ?
    base44.entities.InventoryReport.update(editingId, data) :
    base44.entities.InventoryReport.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["inventoryReports"] });setDialogOpen(false);}
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.InventoryReport.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["inventoryReports"] })
  });

  const openNew = () => {
    const today = new Date().toISOString().slice(0, 10);
    setForm({ type: "entree", tenant_id: "", property_id: "", date: today, housing_type: "appartement", meter_water: "", meter_electricity: "", keys_count: 1, rooms: ROOM_TEMPLATES.appartement.map(emptyRoom), general_condition: "bon", observations: "", status: "draft", deposit_returned: "", deposit_deduction: "", deduction_reason: "" });
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (r) => {setForm({ ...r, rooms: r.rooms || [] });setEditingId(r.id);setDialogOpen(true);};

  const handleTenantChange = (tenantId) => {
    const tenant = tenants.find((t) => t.id === tenantId);
    setForm((f) => ({ ...f, tenant_id: tenantId, property_id: tenant?.property_id || f.property_id }));
  };

  const handleHousingTypeChange = (ht) => {
    setForm((f) => ({ ...f, housing_type: ht, rooms: (ROOM_TEMPLATES[ht] || []).map(emptyRoom) }));
  };

  const updateRoom = (idx, field, value) => {
    setForm((f) => {
      const rooms = [...(f.rooms || [])];
      rooms[idx] = { ...rooms[idx], [field]: value };
      return { ...f, rooms };
    });
  };

  const addRoom = () => setForm((f) => ({ ...f, rooms: [...(f.rooms || []), emptyRoom("")] }));
  const removeRoom = (idx) => setForm((f) => ({ ...f, rooms: f.rooms.filter((_, i) => i !== idx) }));

  const handleSave = () => {
    const tenant = tenants.find((t) => t.id === form.tenant_id);
    const prop = properties.find((p) => p.id === form.property_id);
    saveMutation.mutate({
      ...form,
      tenant_name: tenant ? `${tenant.first_name} ${tenant.last_name}` : "",
      property_name: prop?.name || "",
      keys_count: Number(form.keys_count) || 1,
      deposit_deduction: Number(form.deposit_deduction) || 0,
      deposit_returned: Number(form.deposit_returned) || 0
    });
  };

  const filtered = reports.
  filter((r) => filterType === "all" || r.type === filterType).
  filter((r) => r.tenant_name?.toLowerCase().includes(search.toLowerCase()) || r.property_name?.toLowerCase().includes(search.toLowerCase())).
  sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-green-600 text-xl font-bold">États des Lieux (EDL)</h1>
          <p className="text-sm text-slate-500">{reports.length} état(s) des lieux</p>
        </div>
        <Button onClick={openNew} className="bg-[#413734] text-primary-foreground px-4 py-2 text-base font-extrabold rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 shadow h-9 hover:bg-[#1a3d6e]">
          <Plus className="w-4 h-4 mr-2" /> Nouvel EDL
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[180px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-2">
          {[{ v: "all", l: "Tous" }, { v: "entree", l: "Entrée" }, { v: "sortie", l: "Sortie" }].map(({ v, l }) =>
          <Button key={v} variant={filterType === v ? "default" : "outline"} size="sm"
          className={filterType === v ? "bg-[#0f2b4c]" : ""} onClick={() => setFilterType(v)}>{l}</Button>
          )}
        </div>
      </div>

      {isLoading ?
      <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div> :

      <div className="space-y-3">
          {filtered.map((r) => {
          const tenant = tenants.find((t) => t.id === r.tenant_id);
          const property = properties.find((p) => p.id === r.property_id);
          return (
            <Card key={r.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${r.type === "entree" ? "bg-emerald-50" : "bg-orange-50"}`}>
                      <ClipboardList className={`w-5 h-5 ${r.type === "entree" ? "text-emerald-600" : "text-orange-600"}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-sm">{r.tenant_name || "—"}</h3>
                        <Badge className={r.type === "entree" ? "bg-emerald-100 text-emerald-700 text-[10px]" : "bg-orange-100 text-orange-700 text-[10px]"}>
                          {r.type === "entree" ? "Entrée" : "Sortie"}
                        </Badge>
                        <Badge className={r.status === "signed" ? "bg-blue-100 text-blue-700 text-[10px]" : "bg-slate-100 text-slate-500 text-[10px]"}>
                          {r.status === "signed" ? "Signé" : "Brouillon"}
                        </Badge>
                        {r.general_condition && <Badge className={`${CONDITION_COLORS[r.general_condition]} text-[10px]`}>{CONDITION_OPTIONS.find((c) => c.value === r.general_condition)?.label}</Badge>}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{r.property_name} • {r.date ? new Date(r.date).toLocaleDateString("fr-FR") : "—"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => setPrintReport(r)} className="text-purple-700 border-purple-200 hover:bg-purple-50 text-xs">
                      <Printer className="w-3.5 h-3.5 mr-1" /> Imprimer
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => openEdit(r)}><Pencil className="w-4 h-4 text-slate-500" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => {if (confirm("Supprimer ?")) deleteMutation.mutate(r.id);}}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                  </div>
                </div>
              </Card>);

        })}
          {filtered.length === 0 &&
        <div className="text-center py-16 text-slate-400">
              <ClipboardList className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucun état des lieux</p>
            </div>
        }
        </div>
      }

      {/* Print modal */}
      {printReport &&
      <InventoryPrintModal
        report={printReport}
        tenant={tenants.find((t) => t.id === printReport.tenant_id)}
        property={properties.find((p) => p.id === printReport.property_id)}
        settings={settings}
        onClose={() => setPrintReport(null)} />

      }

      {/* Form dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? "Modifier l'EDL" : "Nouvel état des lieux"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-5">
            {/* Basic info */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type *</Label>
                <Select value={form.type || "entree"} onValueChange={(v) => setForm((f) => ({ ...f, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entree">Entrée dans les lieux</SelectItem>
                    <SelectItem value="sortie">Sortie des lieux</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date *</Label>
                <Input type="date" value={form.date || ""} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Locataire *</Label>
                <Select value={form.tenant_id || ""} onValueChange={handleTenantChange}>
                  <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                  <SelectContent>{tenants.map((t) => <SelectItem key={t.id} value={t.id}>{t.first_name} {t.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Bien *</Label>
                <Select value={form.property_id || ""} onValueChange={(v) => setForm((f) => ({ ...f, property_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                  <SelectContent>{properties.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type de logement</Label>
                <Select value={form.housing_type || "appartement"} onValueChange={handleHousingTypeChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{HOUSING_TYPES.map((h) => <SelectItem key={h.value} value={h.value}>{h.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Statut</Label>
                <Select value={form.status || "draft"} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Brouillon</SelectItem>
                    <SelectItem value="signed">Signé par les deux parties</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div><Label>Index compteur eau</Label><Input placeholder="ex: 1245" value={form.meter_water || ""} onChange={(e) => setForm((f) => ({ ...f, meter_water: e.target.value }))} /></div>
              <div><Label>Index compteur électricité</Label><Input placeholder="ex: 5890" value={form.meter_electricity || ""} onChange={(e) => setForm((f) => ({ ...f, meter_electricity: e.target.value }))} /></div>
              <div><Label>Nombre de clés</Label><Input type="number" min="1" value={form.keys_count || 1} onChange={(e) => setForm((f) => ({ ...f, keys_count: e.target.value }))} /></div>
            </div>

            {/* Rooms */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-sm font-semibold text-slate-700">État des pièces</Label>
                <Button type="button" variant="outline" size="sm" onClick={addRoom} className="text-xs gap-1">
                  <Plus className="w-3 h-3" /> Ajouter une pièce
                </Button>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-slate-100 grid grid-cols-12 px-3 py-2 text-xs font-semibold text-slate-600">
                  <span className="col-span-4">Pièce</span>
                  <span className="col-span-3">État</span>
                  <span className="col-span-4">Observations</span>
                  <span className="col-span-1"></span>
                </div>
                <div className="divide-y max-h-64 overflow-y-auto">
                  {(form.rooms || []).map((room, idx) =>
                  <div key={idx} className="grid grid-cols-12 gap-1.5 px-3 py-2 items-center">
                      <div className="col-span-4">
                        <Input value={room.name} onChange={(e) => updateRoom(idx, "name", e.target.value)} className="h-8 text-xs" placeholder="Nom de la pièce" />
                      </div>
                      <div className="col-span-3">
                        <Select value={room.condition || "bon"} onValueChange={(v) => updateRoom(idx, "condition", v)}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>{CONDITION_OPTIONS.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-4">
                        <Input value={room.notes || ""} onChange={(e) => updateRoom(idx, "notes", e.target.value)} className="h-8 text-xs" placeholder="Notes..." />
                      </div>
                      <div className="col-span-1 flex justify-center">
                        <button onClick={() => removeRoom(idx)} className="text-red-400 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>État général</Label>
                <Select value={form.general_condition || "bon"} onValueChange={(v) => setForm((f) => ({ ...f, general_condition: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CONDITION_OPTIONS.filter((c) => c.value !== "na").map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Observations générales</Label>
              <Textarea value={form.observations || ""} onChange={(e) => setForm((f) => ({ ...f, observations: e.target.value }))} rows={3} placeholder="Remarques, réserves, précisions..." />
            </div>

            {/* EDL Sortie : dépôt */}
            {form.type === "sortie" &&
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 space-y-3">
                <h3 className="text-sm font-semibold text-orange-800 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Régularisation du dépôt de garantie
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Retenue pour dégradations (XAF)</Label><Input type="number" value={form.deposit_deduction || ""} onChange={(e) => setForm((f) => ({ ...f, deposit_deduction: e.target.value }))} /></div>
                  <div><Label>Dépôt restitué (XAF)</Label><Input type="number" value={form.deposit_returned || ""} onChange={(e) => setForm((f) => ({ ...f, deposit_returned: e.target.value }))} /></div>
                </div>
                <div><Label>Motif de retenue</Label><Input value={form.deduction_reason || ""} onChange={(e) => setForm((f) => ({ ...f, deduction_reason: e.target.value }))} placeholder="Dégradations constatées..." /></div>
              </div>
            }
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-[#0f2b4c] hover:bg-[#1a3d6e]">
              {saveMutation.isPending ? "Enregistrement..." : "Enregistrer l'EDL"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}